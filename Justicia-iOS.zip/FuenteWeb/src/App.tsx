import React, { useState, useEffect } from 'react';
import { CasoJusticia } from './types/justicia';
import { CASO_EJEMPLO, CASO_EN_BLANCO } from './data/sampleCase';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidBottomNav, MainTab } from './components/AndroidBottomNav';
import { FiscaliaView } from './components/FiscaliaView';
import { PoderJudicialView } from './components/PoderJudicialView';
import { ResumenExpedienteModal } from './components/ResumenExpedienteModal';
import { SujetosProcesalesModal } from './components/SujetosProcesalesModal';
import { ExportarYAPKModal } from './components/ExportarYAPKModal';
import { sound } from './utils/audioFeedback';
import { RotateCcw, PlusCircle, Smartphone, Info } from 'lucide-react';

const STORAGE_KEY = 'justicia_expediente_v1';

export default function App() {
  // Load case from localStorage or use example
  const [caso, setCaso] = useState<CasoJusticia>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          return JSON.parse(saved);
        }
      } catch (e) {
        console.error('Error loading stored case:', e);
      }
    }
    return CASO_EJEMPLO;
  });

  // Current active main menu tab (Fiscalía vs Poder Judicial)
  const [currentTab, setCurrentTab] = useState<MainTab>('fiscalia');
  const [initialExpTab, setInitialExpTab] = useState<'datos' | 'linea_temporal' | 'sujetos'>('datos');
  function openExp(view: 'datos' | 'linea_temporal' | 'sujetos' = 'datos') { setInitialExpTab(view); setCurrentTab('expediente'); }
  React.useEffect(() => { window.handleBack = () => { if (currentTab === 'expediente') { setCurrentTab('fiscalia'); return true; } return false; }; }, [currentTab]);

  // Modals
  const [isResumenOpen, setIsResumenOpen] = useState(false);
  const [isSujetosOpen, setIsSujetosOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Phone frame simulation vs Fullscreen
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Auto-save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(caso));
    } catch (e) {
      console.error('Error saving case:', e);
    }
  }, [caso]);

  // Update case partial
  const handleUpdateCaso = (actualizado: Partial<CasoJusticia>) => {
    setCaso(prev => ({
      ...prev,
      ...actualizado,
    }));
  };

  // Reset to blank case or reload sample
  const handleResetBlank = () => {
    if (confirm('¿Deseas iniciar un expediente penal nuevo en blanco?')) {
      sound.playTap();
      setCaso(CASO_EN_BLANCO);
      setCurrentTab('fiscalia');
      openExp();
    }
  };

  const handleReloadSample = () => {
    if (confirm('¿Deseas recargar el caso de demostración ("Operación Sombra")?')) {
      sound.playTap();
      setCaso(CASO_EJEMPLO);
      setCurrentTab('fiscalia');
    }
  };

  // Calculate dynamic badges for bottom navigation
  const isJudicialized = ['acusacion_enviada', 'etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual);
  const isAcusacionReturned = caso.evaluacionAcusacionPJ?.decision === 'devolver';
  
  const fiscaliaBadge = isAcusacionReturned ? '!' : null;
  const pjBadge = caso.etapaActual === 'acusacion_enviada' && caso.evaluacionAcusacionPJ?.decision !== 'aceptar' ? '1' : null;

  // Etapa name readable for status bar
  const etapaNames: { [k: string]: string } = {
    investigacion_preliminar: 'Etapa 1: Inv. Preliminar',
    investigacion_preparatoria: 'Etapa 2: Inv. Preparatoria',
    acusacion_enviada: 'Control de Acusación',
    etapa_intermedia: 'Etapa 3: Etapa Intermedia (Subcasos)',
    juicio_oral: 'Etapa 4: Juicio Oral',
    sentencia_dictada: 'Sentencia Dictada (Vía Recursiva)',
    caso_resuelto_definitivo: 'Cosa Juzgada (Archivo Definitivo)',
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center sm:p-2">
      
      {/* Outer wrapper: Phone frame mode OR Full-screen mobile view */}
      <div
        className={`w-full flex flex-col bg-slate-950 transition-all duration-300 ${
          isPhoneFrame
            ? 'max-w-[430px] h-[92vh] max-h-[890px] rounded-[42px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden relative ring-1 ring-slate-700/60'
            : 'h-screen max-w-full overflow-hidden'
        }`}
      >
        
        {/* Notch / Dynamic Island simulation when phone frame is active */}
        {isPhoneFrame && (
          <div className="w-28 h-4 bg-slate-800 rounded-b-xl mx-auto z-50 shrink-0 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-700/80 mr-2" />
            <div className="w-2 h-2 rounded-full bg-slate-900/90" />
          </div>
        )}

        {/* Android Status Bar */}
        <AndroidStatusBar
          isPhoneFrame={isPhoneFrame}
          setIsPhoneFrame={setIsPhoneFrame}
          onOpenResumen={() => openExp()}
          onOpenSujetos={() => openExp('sujetos')}
          onOpenExport={() => setIsExportOpen(true)}
          soundEnabled={soundEnabled}
          setSoundEnabled={setSoundEnabled}
          numeroExpediente={caso.numeroExpediente}
          etapaNombre={etapaNames[caso.etapaActual] || caso.etapaActual}
        />

        {/* Dynamic Main Views: Fiscalía vs Poder Judicial */}
        <main className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
          {currentTab === 'expediente' ? (<ResumenExpedienteModal isOpen={true} embedded={true} initialTab={initialExpTab} onClose={() => setCurrentTab('fiscalia')} caso={caso} onUpdateCaso={handleUpdateCaso} isLockedByJudicialization={isJudicialized} />) : currentTab === 'fiscalia' ? (
            <FiscaliaView
              caso={caso}
              onUpdateCaso={handleUpdateCaso}
              onNavigateToPJ={() => {
                setCurrentTab('poder_judicial');
              }}
              onOpenResumen={() => openExp()}
            />
          ) : (
            <PoderJudicialView
              caso={caso}
              onUpdateCaso={handleUpdateCaso}
              onNavigateToFiscalia={() => {
                setCurrentTab('fiscalia');
              }}
              onOpenResumen={() => openExp()}
              onOpenSujetos={() => openExp('sujetos')}
            />
          )}
        </main>

        {/* Two-Menu Bottom Navigation Bar (Fiscalía & Poder Judicial + Shortcuts) */}
        <AndroidBottomNav
          currentTab={currentTab}
          onChangeTab={tab => setCurrentTab(tab)}
          onOpenResumen={() => openExp()}
          onOpenSujetos={() => openExp('sujetos')}
          fiscaliaBadge={fiscaliaBadge}
          pjBadge={pjBadge}
          etapaActual={caso.etapaActual}
        />

        {/* Android Home Bar Indicator */}
        <div className="w-full bg-slate-950 py-1 flex justify-center shrink-0">
          <div className="w-32 h-1 bg-slate-700 rounded-full" />
        </div>

      </div>

      {/* Floating Action Strip when in desktop or full view to switch demo case */}
      {!isPhoneFrame && (
        <div className="fixed top-2 right-2 z-30 hidden md:flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-800 p-1.5 rounded-xl shadow-lg text-[11px]">
          <button
            onClick={handleReloadSample}
            title="Recargar Caso de Prueba"
            className="android-touch px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3 text-amber-400" />
            <span>Recargar Demo</span>
          </button>

          <button
            onClick={handleResetBlank}
            title="Iniciar Caso Nuevo en Blanco"
            className="android-touch px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium flex items-center gap-1"
          >
            <PlusCircle className="w-3 h-3 text-emerald-400" />
            <span>Caso Nuevo</span>
          </button>
        </div>
      )}

      {/* MODAL 3: Exportar Expediente, Guía APK Android y WebAPK */}
      <ExportarYAPKModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        caso={caso}
        onImportCaso={casoImportado => {
          setCaso(casoImportado);
        }}
      />

    </div>
  );
}
