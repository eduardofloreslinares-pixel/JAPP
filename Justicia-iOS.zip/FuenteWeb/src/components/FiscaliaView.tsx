import React, { useState } from 'react';
import { 
  ShieldAlert, 
  FilePlus, 
  Send, 
  Lock, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  FolderPlus, 
  Plus, 
  Trash2, 
  FileText, 
  Scale, 
  Info,
  Clock,
  ArrowRight
} from 'lucide-react';
import { CasoJusticia, DiligenciaFiscal, PruebaElemento, ConductaImputada, PeticionFiscal } from '../types/justicia';
import { sound } from '../utils/audioFeedback';

interface FiscaliaViewProps {
  caso: CasoJusticia;
  onUpdateCaso: (actualizado: Partial<CasoJusticia>) => void;
  onNavigateToPJ: () => void;
  onOpenResumen: () => void;
}

export const FiscaliaView: React.FC<FiscaliaViewProps> = ({
  caso,
  onUpdateCaso,
  onNavigateToPJ,
  onOpenResumen,
}) => {
  const isJudicialized = ['acusacion_enviada', 'etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual);
  const isReturnedByPJ = caso.evaluacionAcusacionPJ?.decision === 'devolver';

  // Sub-tabs in fiscal view
  const [fiscalSubTab, setFiscalSubTab] = useState<'etapa' | 'pruebas' | 'conductas' | 'peticiones'>('etapa');

  // Form states for adding diligencia
  const [showAddDiligencia, setShowAddDiligencia] = useState(false);
  const [dilTitulo, setDilTitulo] = useState('');
  const [dilTipo, setDilTipo] = useState<DiligenciaFiscal['tipo']>('inspeccion');
  const [dilDetalles, setDilDetalles] = useState('');
  const [dilResultado, setDilResultado] = useState('');

  // Form states for adding prueba
  const [showAddPrueba, setShowAddPrueba] = useState(false);
  const [pruTitulo, setPruTitulo] = useState('');
  const [pruTipo, setPruTipo] = useState<PruebaElemento['tipo']>('documental');
  const [pruDesc, setPruDesc] = useState('');
  const [pruOrigen, setPruOrigen] = useState('');
  const [pruPertinencia, setPruPertinencia] = useState('');

  // Form states for adding conducta
  const [showAddConducta, setShowAddConducta] = useState(false);
  const [condImputado, setCondImputado] = useState(caso.presuntosResponsables[0] || '');
  const [condDesc, setCondDesc] = useState('');
  const [condTipoLegal, setCondTipoLegal] = useState('');
  const [condGravedad, setCondGravedad] = useState<'leve' | 'grave' | 'muy_grave'>('grave');
  const [condPruebasIds, setCondPruebasIds] = useState<string[]>([]);

  // Evaluation & Acusacion form state
  const [evalText, setEvalText] = useState(caso.evaluacionPreliminar);
  const [acusPretension, setAcusPretension] = useState(caso.acusacionFiscal?.pretensionPunitiva || '12 años de pena privativa de la libertad efectiva');
  const [acusReparacion, setAcusReparacion] = useState(caso.acusacionFiscal?.reparacionCivilSolicitada || 50000);
  const [acusFundamentos, setAcusFundamentos] = useState(
    caso.acusacionFiscal?.fundamentosAcusacion ||
    'Se encuentra fehacientemente acreditada la autoría de los imputados mediante prueba pericial dactiloscópica, peritaje balístico, filmaciones de seguridad y declaraciones coherentes.'
  );

  // New Peticion Fiscal state (in judicialized mode)
  const [showAddPeticion, setShowAddPeticion] = useState(false);
  const [petTipo, setPetTipo] = useState<PeticionFiscal['tipo']>('prision_preventiva');
  const [petTitulo, setPetTitulo] = useState('');
  const [petFundamentacion, setPetFundamentacion] = useState('');

  // If there are no facts registered yet
  const needsInitialFacts = !caso.queOcurrio.trim();

  // Handlers
  const handleAddDiligencia = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dilTitulo.trim()) return;
    sound.playTap();

    const nueva: DiligenciaFiscal = {
      id: 'dil-' + Date.now(),
      titulo: dilTitulo.trim(),
      tipo: dilTipo,
      fecha: new Date().toLocaleDateString(),
      detalles: dilDetalles.trim(),
      resultado: dilResultado.trim(),
      responsable: caso.sujetos.fiscalProvincial,
    };

    const targetList = caso.etapaActual === 'investigacion_preparatoria'
      ? [...caso.diligenciasPreparatorias, nueva]
      : [...caso.diligenciasPreliminares, nueva];

    const tlEvent = {
      id: 'tl-' + Date.now(),
      fecha: nueva.fecha,
      hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      titulo: `Diligencia: ${nueva.titulo}`,
      descripcion: nueva.resultado || nueva.detalles,
      tipo: 'diligencia' as const,
      autor: caso.sujetos.fiscalProvincial,
    };

    if (caso.etapaActual === 'investigacion_preparatoria') {
      onUpdateCaso({
        diligenciasPreparatorias: targetList,
        lineaTemporal: [...caso.lineaTemporal, tlEvent],
      });
    } else {
      onUpdateCaso({
        diligenciasPreliminares: targetList,
        lineaTemporal: [...caso.lineaTemporal, tlEvent],
      });
    }

    setDilTitulo('');
    setDilDetalles('');
    setDilResultado('');
    setShowAddDiligencia(false);
  };

  const handleAddPrueba = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pruTitulo.trim()) return;
    sound.playTap();

    const nueva: PruebaElemento = {
      id: 'pr-' + Date.now(),
      titulo: pruTitulo.trim(),
      tipo: pruTipo,
      descripcion: pruDesc.trim(),
      fechaRecabada: new Date().toLocaleDateString(),
      origen: pruOrigen.trim() || 'Actuación fiscal directa',
      pertinencia: pruPertinencia.trim() || 'Acredita elementos del tipo penal investigado',
    };

    onUpdateCaso({
      pruebasRecabadas: [...caso.pruebasRecabadas, nueva],
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: nueva.fechaRecabada,
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `Prueba Recabada: ${nueva.titulo}`,
          descripcion: nueva.descripcion,
          tipo: 'diligencia',
          autor: 'Ministerio Público',
        },
      ],
    });

    setPruTitulo('');
    setPruDesc('');
    setPruOrigen('');
    setPruPertinencia('');
    setShowAddPrueba(false);
  };

  const handleAddConducta = (e: React.FormEvent) => {
    e.preventDefault();
    if (!condDesc.trim()) return;
    sound.playTap();

    const nueva: ConductaImputada = {
      id: 'cond-' + Date.now(),
      imputadoNombre: condImputado || (caso.presuntosResponsables[0] ?? 'Imputado individualizado'),
      descripcionConducta: condDesc.trim(),
      tipificacionLegal: condTipoLegal.trim() || caso.delitoImputado,
      gravedad: condGravedad,
      pruebasAsociadasIds: condPruebasIds,
    };

    onUpdateCaso({
      conductas: [...caso.conductas, nueva],
    });

    setCondDesc('');
    setCondTipoLegal('');
    setCondPruebasIds([]);
    setShowAddConducta(false);
  };

  const handleDeleteConducta = (id: string) => {
    sound.playTap();
    onUpdateCaso({
      conductas: caso.conductas.filter(c => c.id !== id),
    });
  };

  const handleDecidirAbrirPreparatoria = () => {
    sound.playChime();
    sound.haptic();
    onUpdateCaso({
      etapaActual: 'investigacion_preparatoria',
      decisionPreliminar: 'abrir_preparatoria',
      evaluacionPreliminar: evalText,
      fundamentacionPreliminar: 'Concurren elementos de convicción suficientes que vinculan a los investigados. Se formaliza investigación preparatoria.',
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'Disposición de Formalización de Investigación Preparatoria',
          descripcion: 'Fiscalía concluye la preliminar y formaliza la investigación preparatoria con individualización de conductas.',
          tipo: 'resolucion',
          autor: caso.sujetos.fiscalProvincial,
        },
      ],
    });
  };

  const handleRemitirAcusacionAlPJ = () => {
    if (caso.conductas.length === 0) {
      alert('Debes identificar al menos una conducta ilícita individualizada antes de acusar.');
      return;
    }
    sound.playGavel();
    sound.haptic();

    onUpdateCaso({
      etapaActual: 'acusacion_enviada',
      acusacionFiscal: {
        fecha: new Date().toLocaleDateString(),
        pretensionPunitiva: acusPretension,
        reparacionCivilSolicitada: Number(acusReparacion),
        fundamentosAcusacion: acusFundamentos,
        fiscalEmisor: caso.sujetos.fiscalProvincial,
      },
      // Reset any previous return
      evaluacionAcusacionPJ: {
        fecha: new Date().toLocaleDateString(),
        decision: 'pendiente',
        juezEvaluador: caso.sujetos.juezInvestigacionPreparatoria,
      },
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'Requerimiento de Acusación Fiscal al Poder Judicial',
          descripcion: `Fiscalía formula acusación formal solicitando ${acusPretension} y reparación civil de S/ ${acusReparacion}. Pasa a control de acusación.`,
          tipo: 'resolucion',
          autor: caso.sujetos.fiscalProvincial,
        },
      ],
    });

    // Suggest switching to PJ view
    setTimeout(() => {
      onNavigateToPJ();
    }, 700);
  };

  const handleCrearPeticionFiscal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!petTitulo.trim() || !petFundamentacion.trim()) return;
    sound.playTap();

    const nuevaPet: PeticionFiscal = {
      id: 'pet-' + Date.now(),
      fecha: new Date().toLocaleDateString(),
      tipo: petTipo,
      titulo: petTitulo.trim(),
      fundamentacion: petFundamentacion.trim(),
      estado: 'pendiente',
    };

    onUpdateCaso({
      peticionesFiscales: [...caso.peticionesFiscales, nuevaPet],
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: nuevaPet.fecha,
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `Petición Fiscal en Juzgado: ${nuevaPet.titulo}`,
          descripcion: nuevaPet.fundamentacion,
          tipo: 'diligencia',
          autor: caso.sujetos.fiscalProvincial,
        },
      ],
    });

    setPetTitulo('');
    setPetFundamentacion('');
    setShowAddPeticion(false);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
      
      {/* Top Banner: Fiscalía Branding & Stage Status */}
      <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-rose-950/70 border-b border-rose-900/60 p-3.5 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-600/20 border border-rose-500/40 text-rose-400 flex items-center justify-center font-bold text-sm shadow-inner">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif-legal font-bold text-sm text-rose-100 tracking-wide">
                  MINISTERIO PÚBLICO
                </h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono-legal font-bold">
                  Fiscalía
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate max-w-[260px] sm:max-w-md">
                {caso.sujetos.fiscalProvincial}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onOpenResumen();
            }}
            className="android-touch flex items-center gap-1.5 bg-slate-900/90 hover:bg-slate-800 border border-rose-800/60 text-rose-200 px-3 py-1.5 rounded-lg text-xs font-medium"
          >
            <FileText className="w-3.5 h-3.5 text-rose-400" />
            <span>Ver Expediente</span>
          </button>
        </div>

        {/* Dynamic Stepper Bar for Fiscalía */}
        <div className="flex items-center gap-1 pt-1 text-[10px]">
          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'investigacion_preliminar'
                ? 'bg-rose-600 text-white shadow'
                : 'bg-slate-900/80 text-rose-300/80'
            }`}
          >
            <span>1. Inv. Preliminar</span>
            {caso.etapaActual !== 'investigacion_preliminar' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
          </div>

          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'investigacion_preparatoria'
                ? 'bg-rose-600 text-white shadow'
                : ['acusacion_enviada', 'etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual)
                ? 'bg-slate-900 text-rose-300/80'
                : 'bg-slate-900/40 text-slate-500'
            }`}
          >
            <span>2. Inv. Preparatoria</span>
            {['acusacion_enviada', 'etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual) && (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            )}
          </div>

          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              isJudicialized ? 'bg-amber-600 text-white shadow' : 'bg-slate-900/40 text-slate-500'
            }`}
          >
            <span>3. Acusación / PJ</span>
            {isJudicialized && <Scale className="w-3 h-3 text-amber-200" />}
          </div>
        </div>
      </div>

      {/* Notice banner if judicialized or returned */}
      {isJudicialized && !isReturnedByPJ && (
        <div className="bg-slate-900/90 border-b border-slate-800 p-2.5 px-4 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px]">
              <strong>Expediente en sede judicial:</strong> Hechos y acusación bajo control del Juez. En esta pantalla puedes formular peticiones o pedir incorporar nuevas pruebas.
            </span>
          </div>
          <button
            onClick={() => {
              sound.playTap();
              onNavigateToPJ();
            }}
            className="android-touch bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 shrink-0 ml-2"
          >
            <span>Ir al PJ</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Sub navigation within Fiscalía */}
      <div className="flex bg-slate-950 border-b border-slate-800 text-xs px-3">
        <button
          onClick={() => setFiscalSubTab('etapa')}
          className={`py-2 px-3 font-semibold border-b-2 transition ${
            fiscalSubTab === 'etapa'
              ? 'border-rose-500 text-rose-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {isReturnedByPJ ? 'Sede Judicializada' : caso.etapaActual === 'investigacion_preliminar'
            ? '1. Diligencias y Evaluación'
            : caso.etapaActual === 'investigacion_preparatoria'
            ? '2. Preparatoria y Acusación'
            : 'Sede Judicializada'}
        </button>

        <button
          onClick={() => setFiscalSubTab('pruebas')}
          className={`py-2 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 ${
            fiscalSubTab === 'pruebas'
              ? 'border-rose-500 text-rose-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Elementos de Prueba</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] text-slate-300 font-mono-legal">
            {caso.pruebasRecabadas.length}
          </span>
        </button>

        <button
          onClick={() => setFiscalSubTab('conductas')}
          className={`py-2 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 ${
            fiscalSubTab === 'conductas'
              ? 'border-rose-500 text-rose-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Conductas Imputadas</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] text-slate-300 font-mono-legal">
            {caso.conductas.length}
          </span>
        </button>

        {isJudicialized && (
          <button
            onClick={() => setFiscalSubTab('peticiones')}
            className={`py-2 px-3 font-semibold border-b-2 transition flex items-center gap-1.5 ${
              fiscalSubTab === 'peticiones'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Peticiones Fiscales</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-[10px] text-amber-300 font-mono-legal">
              {caso.peticionesFiscales.length}
            </span>
          </button>
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        
      {isReturnedByPJ && fiscalSubTab === 'etapa' && (
        <div className="return-in-stage bg-amber-950/60 border border-amber-800 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-200 animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="apk-return-pill">DEVUELTO</span>
            <span className="font-bold">⚠️ Acusación devuelta por el Juez de Investigación Preparatoria:</span>
            <p className="mt-0.5 text-slate-300 text-[11px]">
              "{caso.evaluacionAcusacionPJ?.motivoDevolucion || 'Se solicitó subsanar imprecisiones fácticas y precisar conductas.'}"
            </p>
            <p className="text-[10px] text-amber-400 mt-1">
              Fiscalía puede ajustar las conductas, corregir la pretensión y volver a remitir la Acusación al Poder Judicial.
            </p>
          </div>
        </div>
      )}


        {/* If no initial facts entered */}
        {needsInitialFacts && (
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-3">
            <Info className="w-8 h-8 text-amber-400 mx-auto" />
            <h3 className="text-sm font-bold text-slate-100">
              Expediente Nuevo sin Datos Iniciales
            </h3>
            <p className="text-slate-400 text-xs max-w-md mx-auto">
              Para iniciar el caso penal, registra los datos fácticos iniciales: qué ocurrió, cuándo, dónde, cómo, presuntos responsables y presunta víctima.
            </p>
            <button
              onClick={() => {
                sound.playTap();
                onOpenResumen();
              }}
              className="android-touch px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-2 shadow-lg"
            >
              <FilePlus className="w-4 h-4 text-slate-950" />
              Ingresar Datos del Caso Inicial
            </button>
          </div>
        )}

        {/* SUBTAB 1: ETAPA ACTUAL CONSECUTIVA */}
        {fiscalSubTab === 'etapa' && (
          <div className="space-y-4">
            
            {/* ETAPA 1: INVESTIGACIÓN PRELIMINAR */}
            {caso.etapaActual === 'investigacion_preliminar' && (
              <div className="space-y-4">
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                        Etapa 1: Investigación Preliminar
                      </h3>
                      <p className="text-slate-400 text-[11px]">
                        Diligencias urgentes e inaplazables para determinar la concurrencia de delito.
                      </p>
                    </div>

                    <button
                      onClick={() => setShowAddDiligencia(!showAddDiligencia)}
                      className="android-touch bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      {showAddDiligencia ? 'Cerrar' : 'Añadir Diligencia'}
                    </button>
                  </div>

                  {/* Form to add diligencia */}
                  {showAddDiligencia && (
                    <form
                      onSubmit={handleAddDiligencia}
                      className="p-3 rounded-lg bg-slate-950 border border-rose-500/40 space-y-2.5 animate-in fade-in"
                    >
                      <h4 className="font-semibold text-rose-300 text-xs">
                        Nueva Diligencia Fiscal Preliminar
                      </h4>
                      <div>
                        <label className="text-[10px] text-slate-400">Título de la diligencia</label>
                        <input
                          type="text"
                          required
                          value={dilTitulo}
                          onChange={e => setDilTitulo(e.target.value)}
                          placeholder="Ej: Inspección criminalística de balística"
                          className="w-full p-2 rounded bg-slate-900 border border-slate-700 text-white text-xs"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-400">Tipo de diligencia</label>
                          <select
                            value={dilTipo}
                            onChange={e => setDilTipo(e.target.value as DiligenciaFiscal['tipo'])}
                            className="w-full p-2 rounded bg-slate-900 border border-slate-700 text-white text-xs"
                          >
                            <option value="inspeccion">Inspección ocular / Escena</option>
                            <option value="declaracion">Toma de Declaración</option>
                            <option value="peritaje">Peritaje Técnico / Científico</option>
                            <option value="allanamiento">Allanamiento / Incautación</option>
                            <option value="informe">Informe de Inteligencia / Policial</option>
                            <option value="otro">Otra diligencia</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400">Resultado obtenido</label>
                          <input
                            type="text"
                            value={dilResultado}
                            onChange={e => setDilResultado(e.target.value)}
                            placeholder="Ej: Hallazgo positivo de huellas"
                            className="w-full p-2 rounded bg-slate-900 border border-slate-700 text-white text-xs"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400">Detalles de la actuación</label>
                        <textarea
                          rows={2}
                          value={dilDetalles}
                          onChange={e => setDilDetalles(e.target.value)}
                          placeholder="Descripción pormenorizada de lo actuado..."
                          className="w-full p-2 rounded bg-slate-900 border border-slate-700 text-white text-xs"
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="android-touch bg-rose-600 hover:bg-rose-500 text-white font-bold px-3 py-1.5 rounded text-xs"
                        >
                          Guardar Diligencia
                        </button>
                      </div>
                    </form>
                  )}

                  {/* List of preliminary diligencias */}
                  <div className="space-y-2">
                    <h4 className="text-[11px] font-semibold text-slate-300">
                      Diligencias Actuadas ({caso.diligenciasPreliminares.length})
                    </h4>
                    {caso.diligenciasPreliminares.length === 0 ? (
                      <p className="text-slate-500 italic p-3 text-center bg-slate-950/60 rounded-lg">
                        Sin diligencias preliminares registradas aún.
                      </p>
                    ) : (
                      caso.diligenciasPreliminares.map(dil => (
                        <div key={dil.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-semibold text-rose-300">{dil.titulo}</span>
                            <span className="font-mono-legal text-slate-500 text-[10px]">{dil.fecha}</span>
                          </div>
                          <p className="text-slate-300 text-[11px]">{dil.detalles}</p>
                          {dil.resultado && (
                            <div className="p-1.5 rounded bg-slate-900 text-emerald-400 text-[10px] font-medium flex items-center gap-1">
                              <span>Resultado:</span>
                              <span className="text-slate-200">{dil.resultado}</span>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Consecutive Evaluation & Decision */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 to-rose-950/30 border border-rose-900/60 space-y-3">
                  <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <Scale className="w-4 h-4 text-rose-400" />
                    Evaluación de Pruebas y Decisión Fiscal Consecutiva
                  </h3>
                  <p className="text-slate-300 text-[11px]">
                    El fiscal analiza las pruebas recabadas en la investigación preliminar y decide si formaliza la investigación preparatoria o archiva los actuados.
                  </p>

                  <div>
                    <label className="text-[11px] text-slate-300 font-semibold mb-1 block">
                      Fundamentación del Juicio de Imputación Preliminar:
                    </label>
                    <textarea
                      rows={3}
                      value={evalText}
                      onChange={e => setEvalText(e.target.value)}
                      placeholder="Indica si existen indicios reveladores de la existencia del delito e individualización de los presuntos autores..."
                      className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-200 focus:border-rose-500 focus:outline-none"
                    />
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-end">
                    <button
                      onClick={() => {
                        sound.playTap();
                        alert('Se ha dispuesto el archivo liminar provisional conforme al artículo 334 del Código Procesal Penal.');
                      }}
                      className="android-touch px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs"
                    >
                      Archivar Preliminarmente
                    </button>

                    <button
                      onClick={handleDecidirAbrirPreparatoria}
                      className="android-touch px-4 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Formalizar y Abrir Investigación Preparatoria</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ETAPA 2: INVESTIGACIÓN PREPARATORIA */}
            {(caso.etapaActual === 'investigacion_preparatoria' || isReturnedByPJ) && (
              <div className="space-y-4">
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                        Etapa 2: Investigación Preparatoria Formalizada
                      </h3>
                      <p className="text-slate-400 text-[11px]">
                        Todas las pruebas previas se mantienen. En esta etapa se identifican formalmente las conductas de cada imputado.
                      </p>
                    </div>

                    <button
                      onClick={() => setFiscalSubTab('conductas')}
                      className="android-touch bg-amber-600 hover:bg-amber-500 text-slate-950 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Identificar Conductas ({caso.conductas.length})
                    </button>
                  </div>

                  {/* Summary of Conductas identified */}
                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2">
                    <span className="text-[11px] font-bold text-slate-300">
                      Conductas Típicas Imputadas (Se convertirán en Subcasos en el PJ):
                    </span>
                    {caso.conductas.length === 0 ? (
                      <div className="p-3 text-center text-amber-300/80 bg-amber-500/10 rounded border border-amber-500/20 text-xs">
                        ⚠️ Aún no has individualizado conductas. Haz clic en "Identificar Conductas" para tipificar las acciones de los imputados.
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {caso.conductas.map((c, i) => (
                          <div key={c.id || i} className="p-2 rounded bg-slate-900 border border-slate-800 text-xs flex items-center justify-between">
                            <div>
                              <span className="font-bold text-rose-300">{c.imputadoNombre}: </span>
                              <span className="text-slate-200">{c.descripcionConducta}</span>
                              <div className="text-[10px] text-amber-400 font-mono-legal mt-0.5">
                                {c.tipificacionLegal} • {c.pruebasAsociadasIds.length} pruebas asociadas
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* FORMULAR ACUSACIÓN FISCAL */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-rose-950/30 to-amber-950/20 border border-amber-500/40 space-y-3.5 shadow-xl">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
                      📜
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-amber-200">
                        Requerimiento Acusatorio (Acusación Fiscal)
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Al enviar la acusación, se activa inmediatamente la interfaz del Poder Judicial para el control formal y sustancial.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="text-slate-300 font-semibold mb-1 block">
                        Pretensión Punitiva (Pena Privativa de Libertad Solicitada)
                      </label>
                      <input
                        type="text"
                        value={acusPretension}
                        onChange={e => setAcusPretension(e.target.value)}
                        placeholder="Ej: 15 años de pena privativa de libertad efectiva"
                        className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-amber-200 font-bold focus:border-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-semibold mb-1 block">
                        Reparación Civil Solicitada (en moneda nacional / USD)
                      </label>
                      <input
                        type="number"
                        value={acusReparacion}
                        onChange={e => setAcusReparacion(Number(e.target.value))}
                        className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono-legal focus:border-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 font-semibold mb-1 block">
                        Fundamentación Fáctica y Jurídica de la Acusación
                      </label>
                      <textarea
                        rows={3}
                        value={acusFundamentos}
                        onChange={e => setAcusFundamentos(e.target.value)}
                        placeholder="Detalla por qué los elementos de convicción son concluyentes y justifican juicio oral..."
                        className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-200 focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={handleRemitirAcusacionAlPJ}
                      className="android-touch w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-amber-950/60"
                    >
                      <Send className="w-4 h-4 text-slate-950" />
                      <span>Formular y Remitir Acusación al Poder Judicial</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* SEDE JUDICIALIZADA (MODO CONSULTA + PETICIONES) */}
            {isJudicialized && !isReturnedByPJ && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-amber-300 text-sm font-bold">
                    <Lock className="w-4 h-4" />
                    <span>Expediente bajo Competencia del Poder Judicial</span>
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Habiéndose remitido la acusación fiscal, la causa se encuentra radicada en el Juzgado de Investigación Preparatoria / Juzgado Penal. Los términos de la acusación han quedado fijados, garantizando la congruencia procesal.
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                      <span className="text-[10px] text-slate-400 block">Pena Solicitada:</span>
                      <span className="font-bold text-amber-300 text-xs">
                        {caso.acusacionFiscal?.pretensionPunitiva || 'En evaluación'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                      <span className="text-[10px] text-slate-400 block">Reparación Civil:</span>
                      <span className="font-bold text-emerald-400 text-xs font-mono-legal">
                        S/ {caso.acusacionFiscal?.reparacionCivilSolicitada.toLocaleString() || '0'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Quick actions for Fiscal in trial */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      sound.playTap();
                      setFiscalSubTab('peticiones');
                      setShowAddPeticion(true);
                    }}
                    className="android-touch p-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/80 text-rose-200 text-left flex items-start gap-2.5 transition"
                  >
                    <Plus className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-xs block">Hacer Petición Fiscal</span>
                      <span className="text-[11px] text-slate-400 block">
                        Requerir prisión preventiva, apercibimiento, reprogramación.
                      </span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      sound.playTap();
                      setFiscalSubTab('pruebas');
                      setShowAddPrueba(true);
                    }}
                    className="android-touch p-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/40 border border-amber-800/80 text-amber-200 text-left flex items-start gap-2.5 transition"
                  >
                    <FolderPlus className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-xs block">Pedir Añadir Prueba Sobrevenida</span>
                      <span className="text-[11px] text-slate-400 block">
                        Solicitar incorporación de nuevo elemento de convicción.
                      </span>
                    </div>
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* SUBTAB 2: ELEMENTOS DE PRUEBA */}
        {fiscalSubTab === 'pruebas' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                  <span>📂</span> Elementos de Prueba Acumulados ({caso.pruebasRecabadas.length})
                </h3>
                <p className="text-slate-400 text-[11px]">
                  Todos los datos probatorios recabados se mantienen consecutivos a lo largo de todo el proceso.
                </p>
              </div>

              <button
                onClick={() => setShowAddPrueba(!showAddPrueba)}
                className="android-touch bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                {showAddPrueba ? 'Cancelar' : 'Añadir Prueba'}
              </button>
            </div>

            {/* Form to add Prueba */}
            {showAddPrueba && (
              <form
                onSubmit={handleAddPrueba}
                className="p-3 rounded-xl bg-slate-900 border border-rose-500/40 space-y-2.5 animate-in fade-in"
              >
                <h4 className="font-semibold text-rose-300 text-xs">
                  {isJudicialized ? 'Solicitar Incorporación de Prueba Sobrevenida' : 'Recabar Nuevo Elemento Probatorio'}
                </h4>

                <div>
                  <label className="text-[10px] text-slate-400">Título descriptivo de la prueba</label>
                  <input
                    type="text"
                    required
                    value={pruTitulo}
                    onChange={e => setPruTitulo(e.target.value)}
                    placeholder="Ej: Dictamen Pericial Balístico Forense Nº 102"
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400">Tipo de prueba</label>
                    <select
                      value={pruTipo}
                      onChange={e => setPruTipo(e.target.value as PruebaElemento['tipo'])}
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    >
                      <option value="documental">Documental</option>
                      <option value="pericial">Pericial</option>
                      <option value="testimonial">Testimonial</option>
                      <option value="material">Material / Pieza de convicción</option>
                      <option value="digital">Digital / Informática</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400">Origen / Custodio</label>
                    <input
                      type="text"
                      value={pruOrigen}
                      onChange={e => setPruOrigen(e.target.value)}
                      placeholder="Ej: Laboratorio de Criminalística"
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400">Descripción detallada</label>
                  <textarea
                    rows={2}
                    value={pruDesc}
                    onChange={e => setPruDesc(e.target.value)}
                    placeholder="Contenido específico y conclusiones..."
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400">Pertinencia, Conducencia y Utilidad</label>
                  <input
                    type="text"
                    value={pruPertinencia}
                    onChange={e => setPruPertinencia(e.target.value)}
                    placeholder="Qué hecho concreto acredita..."
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="android-touch bg-rose-600 hover:bg-rose-500 text-white font-bold px-4 py-1.5 rounded text-xs"
                  >
                    Guardar Elemento de Prueba
                  </button>
                </div>
              </form>
            )}

            {/* Evidence List */}
            <div className="space-y-2.5">
              {caso.pruebasRecabadas.length === 0 ? (
                <p className="text-slate-500 italic p-4 text-center bg-slate-900 rounded-xl">
                  No hay elementos probatorios registrados.
                </p>
              ) : (
                caso.pruebasRecabadas.map(pr => {
                  const badgeType = {
                    documental: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
                    pericial: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
                    testimonial: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
                    material: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                    digital: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
                  }[pr.tipo];

                  return (
                    <div key={pr.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-200 text-xs">{pr.titulo}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${badgeType} uppercase font-semibold`}>
                          {pr.tipo}
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">{pr.descripcion}</p>
                      
                      <div className="pt-1 flex flex-wrap items-center gap-2 text-[10px] text-slate-400 border-t border-slate-800/80">
                        <span>Origen: <strong className="text-slate-300">{pr.origen}</strong></span>
                        <span>•</span>
                        <span>Pertinencia: <strong className="text-amber-300">{pr.pertinencia}</strong></span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 3: IDENTIFICACIÓN DE CONDUCTAS */}
        {fiscalSubTab === 'conductas' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                  <span>⚖️</span> Identificación de Conductas Típicas
                </h3>
                <p className="text-slate-400 text-[11px]">
                  Cada conducta individualizada se transformará en un <strong>Subcaso</strong> en el Poder Judicial.
                </p>
              </div>

              {!isJudicialized || isReturnedByPJ ? (
                <button
                  onClick={() => setShowAddConducta(!showAddConducta)}
                  className="android-touch bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {showAddConducta ? 'Cancelar' : 'Añadir Conducta'}
                </button>
              ) : null}
            </div>

            {/* Form to add Conducta */}
            {showAddConducta && (
              <form
                onSubmit={handleAddConducta}
                className="p-3.5 rounded-xl bg-slate-900 border border-rose-500/40 space-y-3 animate-in fade-in"
              >
                <h4 className="font-semibold text-rose-300 text-xs">
                  Individualizar Nueva Conducta Imputable
                </h4>

                <div>
                  <label className="text-[10px] text-slate-400 font-semibold block mb-1">
                    Imputado / Presunto Responsable
                  </label>
                  {caso.presuntosResponsables.length > 0 ? (
                    <select
                      value={condImputado}
                      onChange={e => setCondImputado(e.target.value)}
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    >
                      {caso.presuntosResponsables.map((r, i) => (
                        <option key={i} value={r}>
                          {r}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      required
                      value={condImputado}
                      onChange={e => setCondImputado(e.target.value)}
                      placeholder="Nombre del imputado"
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  )}
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 font-semibold block mb-1">
                    Descripción Circunstanciada de la Conducta (Qué hizo con exactitud)
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={condDesc}
                    onChange={e => setCondDesc(e.target.value)}
                    placeholder="Ej: Ingreso violento con arma de fuego al local comercial, reducción del custodio y amenazas..."
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 font-semibold block mb-1">
                      Tipificación Legal (Artículo penal)
                    </label>
                    <input
                      type="text"
                      value={condTipoLegal}
                      onChange={e => setCondTipoLegal(e.target.value)}
                      placeholder="Ej: Art. 189 del Código Penal"
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-semibold block mb-1">
                      Gravedad
                    </label>
                    <select
                      value={condGravedad}
                      onChange={e => setCondGravedad(e.target.value as 'leve' | 'grave' | 'muy_grave')}
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    >
                      <option value="muy_grave">Muy Grave</option>
                      <option value="grave">Grave</option>
                      <option value="leve">Leve</option>
                    </select>
                  </div>
                </div>

                {/* Evidence association checkboxes */}
                <div>
                  <label className="text-[10px] text-slate-400 font-semibold block mb-1">
                    Vincular Pruebas Recabadas a esta Conducta:
                  </label>
                  <div className="max-h-28 overflow-y-auto space-y-1 p-2 rounded bg-slate-950 border border-slate-800">
                    {caso.pruebasRecabadas.length === 0 ? (
                      <span className="text-[10px] text-slate-500 italic">No hay pruebas recabadas aún.</span>
                    ) : (
                      caso.pruebasRecabadas.map(pr => (
                        <label key={pr.id} className="flex items-center gap-2 text-[11px] text-slate-300 hover:text-white cursor-pointer">
                          <input
                            type="checkbox"
                            checked={condPruebasIds.includes(pr.id)}
                            onChange={e => {
                              if (e.target.checked) {
                                setCondPruebasIds([...condPruebasIds, pr.id]);
                              } else {
                                setCondPruebasIds(condPruebasIds.filter(id => id !== pr.id));
                              }
                            }}
                            className="rounded border-slate-700 text-rose-600 focus:ring-0"
                          />
                          <span className="truncate">{pr.titulo}</span>
                        </label>
                      ))
                    )}
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="android-touch bg-rose-600 hover:bg-rose-500 text-white font-bold px-4 py-1.5 rounded text-xs"
                  >
                    Registrar Conducta
                  </button>
                </div>
              </form>
            )}

            {/* List of Conductas */}
            <div className="space-y-3">
              {caso.conductas.length === 0 ? (
                <div className="p-4 rounded-xl bg-slate-900 text-center text-slate-400 text-xs">
                  No hay conductas individualizadas. Añade al menos una conducta para proceder a la acusación.
                </div>
              ) : (
                caso.conductas.map((cond, idx) => (
                  <div key={cond.id || idx} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 relative group">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-rose-300 text-xs flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-rose-400" />
                        {cond.imputadoNombre}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold font-mono-legal">
                          {cond.gravedad.toUpperCase()}
                        </span>
                        {(!isJudicialized || isReturnedByPJ) && (
                          <button
                            onClick={() => handleDeleteConducta(cond.id)}
                            className="text-slate-500 hover:text-rose-400 transition p-1"
                            title="Eliminar conducta"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-slate-200 text-xs leading-relaxed">{cond.descripcionConducta}</p>

                    <div className="pt-1.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] text-slate-400">
                      <span className="text-amber-400 font-medium font-mono-legal">{cond.tipificacionLegal}</span>
                      <span>{cond.pruebasAsociadasIds.length} pruebas vinculadas</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 4: PETICIONES FISCALES (En Sede Judicial) */}
        {fiscalSubTab === 'peticiones' && isJudicialized && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                  <span>📑</span> Peticiones Fiscales en Trámite ({caso.peticionesFiscales.length})
                </h3>
                <p className="text-slate-400 text-[11px]">
                  Requerimientos promovidos por Fiscalía para ser resueltos por el Juez de la causa.
                </p>
              </div>

              <button
                onClick={() => setShowAddPeticion(!showAddPeticion)}
                className="android-touch bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                {showAddPeticion ? 'Cerrar' : 'Nueva Petición'}
              </button>
            </div>

            {/* Form to add Petición */}
            {showAddPeticion && (
              <form
                onSubmit={handleCrearPeticionFiscal}
                className="p-3.5 rounded-xl bg-slate-900 border border-rose-500/40 space-y-2.5 animate-in fade-in"
              >
                <h4 className="font-semibold text-rose-300 text-xs">
                  Formular Petición ante el Juez
                </h4>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400">Tipo de Petición</label>
                    <select
                      value={petTipo}
                      onChange={e => setPetTipo(e.target.value as PeticionFiscal['tipo'])}
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    >
                      <option value="prision_preventiva">Prisión Preventiva</option>
                      <option value="incorporar_prueba">Incorporación de Prueba Sobrevenida</option>
                      <option value="apercibimiento">Apercibimiento a la Defensa</option>
                      <option value="reprogramacion">Reprogramación de Audiencia</option>
                      <option value="medida_cautelar">Medida Cautelar Real / Embargo</option>
                      <option value="otra">Otra Petición</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400">Título Breve</label>
                    <input
                      type="text"
                      required
                      value={petTitulo}
                      onChange={e => setPetTitulo(e.target.value)}
                      placeholder="Ej: Requerimiento de Prisión Preventiva por 9 meses"
                      className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400">Fundamentación Jurídica</label>
                  <textarea
                    rows={2}
                    required
                    value={petFundamentacion}
                    onChange={e => setPetFundamentacion(e.target.value)}
                    placeholder="Explica los presupuestos materiales, peligro procesal o urgencia..."
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="android-touch bg-rose-600 hover:bg-rose-500 text-white font-bold px-4 py-1.5 rounded text-xs"
                  >
                    Enviar Petición al Juez
                  </button>
                </div>
              </form>
            )}

            {/* List of Peticiones */}
            <div className="space-y-3">
              {caso.peticionesFiscales.length === 0 ? (
                <p className="text-slate-500 italic p-4 text-center bg-slate-900 rounded-xl">
                  No hay peticiones fiscales formuladas en esta etapa.
                </p>
              ) : (
                caso.peticionesFiscales.map(pet => (
                  <div key={pet.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-rose-300">{pet.titulo}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono-legal ${
                        pet.estado === 'admitida'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : pet.estado === 'rechazada'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                      }`}>
                        {pet.estado.toUpperCase()}
                      </span>
                    </div>

                    <p className="text-slate-300 text-xs">{pet.fundamentacion}</p>

                    {pet.respuestaJuez && (
                      <div className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] text-amber-200">
                        <strong className="text-amber-400">Resolución del Juez: </strong>
                        {pet.respuestaJuez}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
