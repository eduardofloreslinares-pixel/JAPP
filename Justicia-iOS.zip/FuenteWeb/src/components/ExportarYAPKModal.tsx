import React, { useState } from 'react';
import { X, Smartphone, Download, Upload, Copy, Check, FileCheck, Layers, Terminal } from 'lucide-react';
import { CasoJusticia } from '../types/justicia';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { sound } from '../utils/audioFeedback';

interface ExportarYAPKModalProps {
  isOpen: boolean;
  onClose: () => void;
  caso: CasoJusticia;
  onImportCaso: (casoImportado: CasoJusticia) => void;
}

export const ExportarYAPKModal: React.FC<ExportarYAPKModalProps> = ({
  isOpen,
  onClose,
  caso,
  onImportCaso,
}) => {
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);

  if (!isOpen) return null;

  const handleExportJSON = () => {
    sound.playTap();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(caso, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `Expediente_${caso.numeroExpediente.replace(/[^a-zA-Z0-9]/g, '_')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.numeroExpediente && parsed.etapaActual) {
          sound.playChime();
          onImportCaso(parsed);
          alert('¡Expediente importado exitosamente!');
          onClose();
        } else {
          alert('El archivo JSON no tiene la estructura de un expediente de Justicia.');
        }
      } catch {
        alert('Error al leer el archivo JSON.');
      }
    };
    reader.readAsText(file);
  };

  const capacitorCommands = `# ¡El proyecto nativo ya está generado y sincronizado en /android!
# 1. Abrir en Android Studio:
npx cap open android

# 2. O compilar APK directamente con Gradle:
cd android && ./gradlew assembleDebug

# 3. Ubicación del archivo APK generado:
# android/app/build/outputs/apk/debug/app-debug.apk`;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in">
      <div className="w-full sm:max-w-xl max-h-[90vh] bg-slate-900 border border-slate-700 sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-sm font-bold">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 font-serif-legal">
                Entrega Android (APK / WebAPK) y Respaldo
              </h3>
              <p className="text-[11px] text-emerald-400/90 font-medium">
                Instalación en tu móvil Android y exportación del expediente
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="android-touch p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          
          {/* Card 1: Instalar WebAPK en Android directamente */}
          <div className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-950/40 to-slate-950 border border-emerald-500/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-300 text-xs flex items-center gap-1.5">
                <span className="text-base">📲</span> Opción 1: Instalar como WebAPK en Android (Inmediato)
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                Recomendada
              </span>
            </div>

            <p className="text-slate-300 text-[11px] leading-relaxed">
              Google Chrome genera automáticamente un <strong>paquete APK nativo (WebAPK)</strong> firmado por Google Play Services. Al instalarlo, aparece en el cajón de aplicaciones de tu teléfono con icono propio, pantalla de bienvenida y ejecución independiente.
            </p>

            {isInstalled ? (
              <div className="p-2.5 rounded-lg bg-emerald-950/50 border border-emerald-800 text-emerald-300 text-[11px] flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>¡La aplicación ya se encuentra instalada en este dispositivo!</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={async () => {
                  sound.playTap();
                  await install();
                }}
                className="android-touch w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/40 text-xs"
              >
                <Download className="w-4 h-4 text-slate-950" />
                Instalar App "Justicia" en mi Android
              </button>
            ) : (
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 text-[11px] space-y-1">
                <p className="font-medium text-slate-200">
                  📱 Para instalar en Chrome / Brave / Edge en Android:
                </p>
                <p className="text-slate-400">
                  1. Pulsa el menú de <strong>tres puntos (⋮)</strong> arriba a la derecha en el navegador.<br />
                  2. Selecciona <strong>"Instalar aplicación"</strong> o <strong>"Añadir a pantalla principal"</strong>.
                </p>
                {isIOS && (
                  <p className="text-sky-300 text-[10px] pt-1">
                    En iPhone: Botón Compartir (flecha hacia arriba) &gt; "Añadir a la pantalla de inicio".
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Card 2: Proyecto Android Studio y Generación de APK (.apk) */}
          <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-400" />
                Opción 2: Proyecto Android Nativo para Generar APK (.apk)
              </span>
              <span className="text-[10px] text-amber-400 font-mono-legal bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                Capacitor + Gradle
              </span>
            </div>

            <p className="text-slate-300 text-[11px] leading-relaxed">
              El proyecto nativo de Android ya está generado con todos los archivos Gradle, `AndroidManifest.xml`, iconos y assets web sincronizados.
            </p>

            <a
              href="/android-justicia-project.zip"
              download="android-justicia-project.zip"
              className="android-touch w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center justify-center gap-2 shadow-lg shadow-amber-900/40 text-xs cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>Descargar Proyecto Android Completo (.zip)</span>
            </a>

            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300 space-y-1.5">
              <span className="font-bold text-slate-200 block">Pasos para compilar Justicia.apk en 1 minuto:</span>
              <ol className="list-decimal list-inside text-slate-400 space-y-1">
                <li>Descomprime el archivo descargado <code>android-justicia-project.zip</code>.</li>
                <li>Abre <strong>Android Studio</strong> y haz clic en <strong>Open</strong> &gt; selecciona la carpeta <code>android</code>.</li>
                <li>En el menú superior pulsa: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</li>
                <li>¡Listo! El archivo <code>app-debug.apk</code> queda generado para instalarlo en cualquier teléfono Android.</li>
              </ol>
            </div>

            <div className="relative">
              <pre className="p-2.5 rounded-lg bg-slate-900 text-[10px] font-mono-legal text-amber-200 overflow-x-auto border border-slate-800">
                {capacitorCommands}
              </pre>
              <button
                onClick={() => {
                  sound.playTap();
                  navigator.clipboard.writeText(capacitorCommands);
                  setCopiedCmd(true);
                  setTimeout(() => setCopiedCmd(false), 2000);
                }}
                className="absolute top-2 right-2 p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                title="Copiar comandos"
              >
                {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Card 3: Copia de Seguridad y Exportación del Expediente */}
          <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
            <span className="font-bold text-sky-300 text-xs flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-sky-400" />
              Gestión y Respaldo del Expediente Digital
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={handleExportJSON}
                className="android-touch p-2.5 rounded-lg bg-sky-950/40 hover:bg-sky-900/40 border border-sky-800 text-sky-200 flex items-center justify-center gap-2 font-medium"
              >
                <Download className="w-4 h-4 text-sky-400" />
                <span>Descargar Expediente (.json)</span>
              </button>

              <label className="android-touch cursor-pointer p-2.5 rounded-lg bg-purple-950/40 hover:bg-purple-900/40 border border-purple-800 text-purple-200 flex items-center justify-center gap-2 font-medium">
                <Upload className="w-4 h-4 text-purple-400" />
                <span>Restaurar Expediente (.json)</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportFile}
                  className="hidden"
                />
              </label>
            </div>

            <div className="flex justify-between items-center text-[10px] text-slate-400 pt-1">
              <span>Nº: {caso.numeroExpediente}</span>
              <button
                onClick={() => {
                  sound.playTap();
                  navigator.clipboard.writeText(JSON.stringify(caso, null, 2));
                  setCopiedJson(true);
                  setTimeout(() => setCopiedJson(false), 2000);
                }}
                className="text-slate-300 hover:text-amber-300 flex items-center gap-1"
              >
                {copiedJson ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                Copiar JSON al portapapeles
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="android-touch px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Entendido
          </button>
        </div>

      </div>
    </div>
  );
};
