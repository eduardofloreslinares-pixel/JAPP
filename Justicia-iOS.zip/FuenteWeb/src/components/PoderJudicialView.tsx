import React, { useState } from 'react';
import { 
  Scale, 
  Gavel, 
  FileCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ShieldCheck, 
  ArrowLeft, 
  Plus, 
  Clock, 
  Award, 
  Lock, 
  RotateCcw,
  Sparkles,
  Layers,
  ChevronDown,
  ChevronUp,
  MessageSquare
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  CasoJusticia, 
  SubcasoIntermedio, 
  AudienciaSubcaso, 
  SentenciaData, 
  ApelacionRecord, 
  SubcaseDecision 
} from '../types/justicia';
import { sound } from '../utils/audioFeedback';

interface PoderJudicialViewProps {
  caso: CasoJusticia;
  onUpdateCaso: (actualizado: Partial<CasoJusticia>) => void;
  onNavigateToFiscalia: () => void;
  onOpenResumen: () => void;
  onOpenSujetos: () => void;
}

export const PoderJudicialView: React.FC<PoderJudicialViewProps> = ({
  caso,
  onUpdateCaso,
  onNavigateToFiscalia,
  onOpenResumen,
  onOpenSujetos,
}) => {
  const isAcusacionSent = [
    'acusacion_enviada',
    'etapa_intermedia',
    'juicio_oral',
    'sentencia_dictada',
    'caso_resuelto_definitivo'
  ].includes(caso.etapaActual);

  // Active view inside PJ
  const [pjSubTab, setPjSubTab] = useState<'control' | 'subcasos' | 'juicio' | 'peticiones_pj'>('control');

  // Control de Acusacion modal/state
  const [showDevolverForm, setShowDevolverForm] = useState(false);
  const [motivoDevolucion, setMotivoDevolucion] = useState(
    'Se devuelven los actuados por imprecisión en la individualización de la conducta imputada a uno de los partícipes (falta de circunstanciación temporal precisa).'
  );
  const [fundamentoAceptacion, setFundamentoAceptacion] = useState(
    'Concurren los presupuestos del Art. 349 y 350 del CPP. La imputación fáctica es clara, existe suficiencia probatoria para debate contradictorio y se respetó el principio de congruencia.'
  );

  // Subcase detailed expansion
  const [expandedSubcaseId, setExpandedSubcaseId] = useState<string | null>(null);

  // New hearing in subcase state
  const [showAddHearingModal, setShowAddHearingModal] = useState<string | null>(null);
  const [hearingTipo, setHearingTipo] = useState<AudienciaSubcaso['tipo']>('alegatos');
  const [hearingFiscalia, setHearingFiscalia] = useState('');
  const [hearingDefensa, setHearingDefensa] = useState('');
  const [hearingConclusiones, setHearingConclusiones] = useState('');

  // Subcase decision state
  const [subcaseDecisionOption, setSubcaseDecisionOption] = useState<SubcaseDecision>('procede_juicio');
  const [subcaseDecisionMotivacion, setSubcaseDecisionMotivacion] = useState('');

  // Juicio Oral state
  const [alegAperturaFiscal, setAlegAperturaFiscal] = useState(
    'La Fiscalía demostrará más allá de toda duda razonable la responsabilidad penal de los acusados conforme a las pruebas periciales y testimoniales válidamente admitidas.'
  );
  const [alegAperturaDefensa, setAlegAperturaDefensa] = useState(
    'La defensa acreditará la insuficiencia probatoria y la falta de dolo directo en los hechos materia de juzgamiento.'
  );
  const [alegClausuraFiscal, setAlegClausuraFiscal] = useState(
    'Ha quedado plenamente probada la coautoría delictiva, solicitamos se dicte condena ejemplar y pago de reparación civil solidaria.'
  );
  const [alegClausuraDefensa, setAlegClausuraDefensa] = useState(
    'Se solicita la absolución por no haberse enervado el principio constitucional de presunción de inocencia.'
  );

  // Sentencia form state
  const [falloSentencia, setFalloSentencia] = useState<'condenatoria' | 'absolutoria' | 'mixta'>('condenatoria');
  const [fundamentoSentencia, setFundamentoSentencia] = useState(
    'El Tribunal, valorando conjuntamente las pruebas actuadas bajo las reglas de la sana crítica y máximas de la experiencia, arriba a la convicción de culpabilidad penal de los procesados.'
  );
  const [sentenciaReparacionMonto, setSentenciaReparacionMonto] = useState(caso.acusacionFiscal?.reparacionCivilSolicitada || 50000);
  const [penasIndividuales, setPenasIndividuales] = useState<{ [imputado: string]: number }>({});

  // Apelacion Modal state
  const [showApelacionModal, setShowApelacionModal] = useState(false);
  const [quienApela, setQuienApela] = useState<'defensa' | 'fiscalia' | 'ambas_partes'>('defensa');
  const [motivosAgravios, setMotivosAgravios] = useState(
    'Se apela por errónea valoración de la prueba pericial e indebida aplicación de agravantes cualificadas.'
  );
  const [admisibilidadUltima, setAdmisibilidadUltima] = useState<'admitida' | 'inadmisible'>('admitida');

  // Sync subtab with case stage
  React.useEffect(() => {
    if (caso.etapaActual === 'etapa_intermedia') {
      setPjSubTab('subcasos');
    } else if (caso.etapaActual === 'juicio_oral' || caso.etapaActual === 'sentencia_dictada' || caso.etapaActual === 'caso_resuelto_definitivo') {
      setPjSubTab('juicio');
    } else {
      setPjSubTab('control');
    }
  }, [caso.etapaActual]);

  // Init default penalties for defendants if empty
  React.useEffect(() => {
    const map: { [imputado: string]: number } = {};
    caso.presuntosResponsables.forEach(r => {
      map[r] = 12; // default 12 years
    });
    setPenasIndividuales(map);
  }, [caso.presuntosResponsables]);

  // Handler: Devolver Acusación a Fiscalía
  const handleDevolverAcusacion = () => {
    if (!motivoDevolucion.trim()) return;
    sound.playTap();

    onUpdateCaso({
      evaluacionAcusacionPJ: {
        fecha: new Date().toLocaleDateString(),
        decision: 'devolver',
        motivoDevolucion: motivoDevolucion.trim(),
        juezEvaluador: caso.sujetos.juezInvestigacionPreparatoria,
      },
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'Auto Judicial de Devolución de Acusación para Subsanación',
          descripcion: motivoDevolucion.trim(),
          tipo: 'resolucion',
          autor: caso.sujetos.juezInvestigacionPreparatoria,
        },
      ],
    });

    setShowDevolverForm(false);
    alert('La acusación ha sido devuelta al Ministerio Público con observaciones. Fiscalía debe subsanarla.');
    onNavigateToFiscalia();
  };

  // Handler: Aceptar Acusación y Generar Subcasos
  const handleAceptarAcusacion = () => {
    sound.playGavel();
    sound.haptic();

    // Convert each conduct established by fiscalía into a Subcaso
    const nuevosSubcasos: SubcasoIntermedio[] = caso.conductas.map((cond, idx) => {
      // Find associated evidence
      const pruebasAsoc = caso.pruebasRecabadas.filter(pr =>
        cond.pruebasAsociadasIds.includes(pr.id)
      );

      return {
        id: 'subcase-' + (idx + 1) + '-' + Date.now(),
        conductaId: cond.id,
        titulo: `Subcaso ${idx + 1}: ${cond.imputadoNombre}`,
        imputadoNombre: cond.imputadoNombre,
        conductaDescripcion: cond.descripcionConducta,
        tipificacionLegal: cond.tipificacionLegal,
        pruebasAsignadas: pruebasAsoc.length > 0 ? pruebasAsoc : caso.pruebasRecabadas,
        audiencias: [
          {
            id: 'aud-ini-' + idx,
            fecha: new Date().toLocaleDateString(),
            tipo: 'alegatos',
            alegatoFiscalia: 'Se imputa autoría directa con base en las evidencias recabadas.',
            alegatoDefensa: 'Se objeta la pertinencia y se solicita control sustancial.',
            conclusionesJuez: 'Se abre contradictorio para debate probatorio del subcaso.',
          },
        ],
        estado: 'pendiente',
      };
    });

    onUpdateCaso({
      etapaActual: 'etapa_intermedia',
      evaluacionAcusacionPJ: {
        fecha: new Date().toLocaleDateString(),
        decision: 'aceptar',
        fundamentacionAceptacion: fundamentoAceptacion,
        juezEvaluador: caso.sujetos.juezInvestigacionPreparatoria,
      },
      subcasos: nuevosSubcasos,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'Auto de Enjuiciamiento Admitido (Poder Judicial)',
          descripcion: `El Juez declara válida la acusación. Se abren ${nuevosSubcasos.length} subcasos para debate en Etapa Intermedia.`,
          tipo: 'resolucion',
          autor: caso.sujetos.juezInvestigacionPreparatoria,
        },
      ],
    });

    setPjSubTab('subcasos');
  };

  // Handler: Add Audiencia to Subcase
  const handleAddAudienciaSubcase = (subcaseId: string) => {
    if (!hearingFiscalia.trim() && !hearingDefensa.trim()) return;
    sound.playTap();

    const nuevaAud: AudienciaSubcaso = {
      id: 'aud-' + Date.now(),
      fecha: new Date().toLocaleDateString(),
      tipo: hearingTipo,
      alegatoFiscalia: hearingFiscalia.trim() || 'Se ratifican los términos de la acusación fiscal.',
      alegatoDefensa: hearingDefensa.trim() || 'Se formulan oposiciones y observaciones a las pruebas.',
      conclusionesJuez: hearingConclusiones.trim() || 'Debate analizado por el magistrado de garantías.',
    };

    const updatedSubcasos = caso.subcasos.map(sub => {
      if (sub.id === subcaseId) {
        return {
          ...sub,
          audiencias: [...sub.audiencias, nuevaAud],
        };
      }
      return sub;
    });

    onUpdateCaso({
      subcasos: updatedSubcasos,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: nuevaAud.fecha,
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `Audiencia en Subcaso: ${nuevaAud.tipo.toUpperCase()}`,
          descripcion: `Debate de pruebas y alegatos respecto a la conducta evaluada.`,
          tipo: 'audiencia',
          autor: caso.sujetos.juezInvestigacionPreparatoria,
        },
      ],
    });

    setShowAddHearingModal(null);
    setHearingFiscalia('');
    setHearingDefensa('');
    setHearingConclusiones('');
  };

  // Handler: Resolver Subcaso
  const handleResolverSubcaso = (subcaseId: string) => {
    sound.playGavel();
    sound.haptic();

    const updatedSubcasos = caso.subcasos.map(sub => {
      if (sub.id === subcaseId) {
        return {
          ...sub,
          estado: subcaseDecisionOption,
          motivacionDecision: subcaseDecisionMotivacion.trim() || 'Resolución fundada en el mérito de los autos y suficiencia probatoria.',
          fechaResolucion: new Date().toLocaleDateString(),
          juezResolutor: caso.sujetos.juezInvestigacionPreparatoria,
        };
      }
      return sub;
    });

    onUpdateCaso({
      subcasos: updatedSubcasos,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `Resolución de Subcaso: ${subcaseDecisionOption.toUpperCase()}`,
          descripcion: subcaseDecisionMotivacion.trim() || 'El Juez emite resolución respecto a la conducta procesada en este subcaso.',
          tipo: 'resolucion',
          autor: caso.sujetos.juezInvestigacionPreparatoria,
        },
      ],
    });

    setExpandedSubcaseId(null);
  };

  // Check if all subcases are completed
  const allSubcasesResolved = caso.subcasos.length > 0 && caso.subcasos.every(s => s.estado !== 'pendiente');
  const resolvedCount = caso.subcasos.filter(s => s.estado !== 'pendiente').length;

  // Handler: Avanzar a Juicio Oral
  const handleAvanzarJuicioOral = () => {
    if (!allSubcasesResolved) {
      alert('Debes resolver todos los subcasos en audiencia antes de avanzar a Juicio Oral.');
      return;
    }
    sound.playGavel();
    sound.haptic();

    onUpdateCaso({
      etapaActual: 'juicio_oral',
      alegatosApertura: {
        tipo: 'apertura',
        fiscalia: alegAperturaFiscal,
        defensa: alegAperturaDefensa,
        fecha: new Date().toLocaleDateString(),
      },
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'Instalación de Audiencia de Juicio Oral',
          descripcion: 'Concluidos los subcasos, se abre formalmente la etapa de juzgamiento oral contradictorio.',
          tipo: 'audiencia',
          autor: caso.sujetos.juezJuicioOral,
        },
      ],
    });

    setPjSubTab('juicio');
  };

  // Handler: Dictar Sentencia
  const handleDictarSentencia = () => {
    sound.playGavel();
    sound.haptic();

    const penasCalculadas = caso.presuntosResponsables.map(r => ({
      imputadoNombre: r,
      penaAnios: penasIndividuales[r] || 12,
      tipoPena: falloSentencia === 'absolutoria' ? 'Absuelto de los cargos' : 'Pena privativa de la libertad efectiva',
      inhabilitacionMeses: falloSentencia === 'absolutoria' ? 0 : 36,
    }));

    const sentenciaNueva: SentenciaData = {
      fecha: new Date().toLocaleDateString(),
      fallo: falloSentencia,
      penasImputados: penasCalculadas,
      reparacionCivilMonto: falloSentencia === 'absolutoria' ? 0 : Number(sentenciaReparacionMonto),
      reparacionCivilBeneficiario: caso.presuntaVictima,
      fundamentacionJuridica: fundamentoSentencia,
      juezSentenciador: caso.sujetos.juezJuicioOral,
    };

    onUpdateCaso({
      etapaActual: 'sentencia_dictada',
      alegatosClausura: {
        tipo: 'clausura',
        fiscalia: alegClausuraFiscal,
        defensa: alegClausuraDefensa,
        fecha: new Date().toLocaleDateString(),
      },
      sentencia: sentenciaNueva,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: sentenciaNueva.fecha,
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `SENTENCIA JUDICIAL: Fallo ${sentenciaNueva.fallo.toUpperCase()}`,
          descripcion: `El Juzgado Penal dicta sentencia con pena privativa de libertad y reparación civil de S/ ${sentenciaNueva.reparacionCivilMonto.toLocaleString()}.`,
          tipo: 'resolucion',
          autor: caso.sujetos.juezJuicioOral,
        },
      ],
    });
  };

  // Handler: Tramitar Apelación (hasta 3)
  const handleProcesarApelacion = () => {
    sound.playTap();
    const numApelacion = (caso.apelacionActualIndex + 1) as 1 | 2 | 3;

    // Determine judges for this appeal stage
    const juecesSala = numApelacion === 1
      ? caso.sujetos.juecesApelacionInstancia1
      : numApelacion === 2
      ? caso.sujetos.juecesApelacionInstancia2
      : caso.sujetos.juecesApelacionInstancia3;

    // Check if it's the 3rd and final appeal
    if (numApelacion === 3) {
      if (admisibilidadUltima === 'inadmisible') {
        // Closed case immediately!
        sound.playGavel();
        sound.haptic();
        try {
          confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
        } catch {}

        const apelacionRec: ApelacionRecord = {
          numeroApelacion: 3,
          fechaInterposicion: new Date().toLocaleDateString(),
          quienApela,
          motivosAgravios,
          juecesSalaApelaciones: juecesSala,
          admisibilidadUltima: 'inadmisible',
          estado: 'resuelta',
          resolucionSala: 'La Sala Penal Suprema declara INADMISIBLE el recurso de casación. Queda firme la sentencia previa.',
          falloApelacion: 'confirma',
        };

        onUpdateCaso({
          apelaciones: [...caso.apelaciones, apelacionRec],
          apelacionActualIndex: 3,
          casoCerradoDefinitivo: true,
          fechaCierreDefinitivo: new Date().toLocaleDateString(),
          etapaActual: 'caso_resuelto_definitivo',
          lineaTemporal: [
            ...caso.lineaTemporal,
            {
              id: 'tl-' + Date.now(),
              fecha: new Date().toLocaleDateString(),
              hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              titulo: 'AUTO SUPREMO DE INADMISIBILIDAD - COSA JUZGADA',
              descripcion: 'Se declara inadmisible la última apelación. El expediente queda cerrado y resuelto de forma definitiva.',
              tipo: 'apelacion',
              autor: 'Sala Penal Permanente Suprema',
            },
          ],
        });

        setShowApelacionModal(false);
        return;
      }
    }

    // Normal appeal or admitted 3rd appeal: Reopens the case from the subcasos/conductas with NEW judges!
    sound.playGavel();
    sound.haptic();

    // Reopen subcases for appellate review
    const subcasosReabiertos: SubcasoIntermedio[] = caso.subcasos.map(sub => ({
      ...sub,
      estado: 'pendiente',
      audiencias: [
        ...sub.audiencias,
        {
          id: 'aud-ap-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          tipo: 'alegatos',
          alegatoFiscalia: 'Fiscalía Superior solicita confirmar la sentencia recurrida en todos sus extremos.',
          alegatoDefensa: 'Defensa fundamenta los agravios expuestos en el recurso de apelación.',
          conclusionesJuez: `Vista de la causa ante la Sala de Apelaciones conformada por: ${juecesSala.join(', ')}.`,
        },
      ],
    }));

    const apelacionRec: ApelacionRecord = {
      numeroApelacion: numApelacion,
      fechaInterposicion: new Date().toLocaleDateString(),
      quienApela,
      motivosAgravios,
      juecesSalaApelaciones: juecesSala,
      admisibilidadUltima: numApelacion === 3 ? 'admitida' : undefined,
      estado: 'en_tramite',
      resolucionSala: `Admitida a trámite la apelación Nº ${numApelacion}. El caso se reabre en sus subcasos ante el nuevo tribunal colegiado.`,
    };

    onUpdateCaso({
      etapaActual: 'etapa_intermedia',
      subcasos: subcasosReabiertos,
      apelaciones: [...caso.apelaciones, apelacionRec],
      apelacionActualIndex: numApelacion,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `INTERPOSICIÓN DE APELACIÓN Nº ${numApelacion}`,
          descripcion: `Se reabre el juzgamiento de las conductas ante nuevos jueces superiores: ${juecesSala.join(', ')}. Motivo: ${motivosAgravios}`,
          tipo: 'apelacion',
          autor: quienApela.toUpperCase(),
        },
      ],
    });

    setShowApelacionModal(false);
    setPjSubTab('subcasos');
  };

  // Final Close Action (Cosa Juzgada manual button if last appeal resolved)
  const handleDeclararCosaJuzgada = () => {
    sound.playGavel();
    sound.haptic();
    try {
      confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
    } catch {}

    onUpdateCaso({
      casoCerradoDefinitivo: true,
      fechaCierreDefinitivo: new Date().toLocaleDateString(),
      etapaActual: 'caso_resuelto_definitivo',
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: 'DECLARACIÓN FORMAL DE COSA JUZGADA (ARCHIVO DEFINITIVO)',
          descripcion: 'El expediente penal ha agotado todas las instancias recursivas. Cierre inmutable y solo revisable.',
          tipo: 'resolucion',
          autor: 'Poder Judicial',
        },
      ],
    });
  };

  // Resolve fiscal petition by judge
  const handleResolverPeticionJuez = (peticionId: string, decision: 'admitida' | 'rechazada', respuesta: string) => {
    sound.playTap();
    const updated = caso.peticionesFiscales.map(p => {
      if (p.id === peticionId) {
        return {
          ...p,
          estado: decision,
          respuestaJuez: respuesta,
        };
      }
      return p;
    });

    onUpdateCaso({
      peticionesFiscales: updated,
      lineaTemporal: [
        ...caso.lineaTemporal,
        {
          id: 'tl-' + Date.now(),
          fecha: new Date().toLocaleDateString(),
          hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          titulo: `Resolución Judicial sobre Petición: ${decision.toUpperCase()}`,
          descripcion: respuesta,
          tipo: 'resolucion',
          autor: caso.sujetos.juezInvestigacionPreparatoria,
        },
      ],
    });
  };

  // Button text for appeal based on index
  const getApelacionButtonLabel = () => {
    if (caso.apelacionActualIndex === 0) return '⚖️ Apelar';
    if (caso.apelacionActualIndex === 1) return '⚖️ Segunda apelación';
    if (caso.apelacionActualIndex === 2) return '⚖️ Última apelación';
    return 'Apelación agotada';
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
      
      {/* Top Banner: Poder Judicial Branding */}
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/60 border-b border-amber-900/60 p-3.5 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold text-sm shadow-inner">
              <Scale className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif-legal font-bold text-sm text-amber-100 tracking-wide">
                  PODER JUDICIAL
                </h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono-legal font-bold">
                  Juzgados y Salas Penales
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate max-w-[260px] sm:max-w-md">
                {caso.etapaActual === 'juicio_oral' || caso.etapaActual === 'sentencia_dictada'
                  ? caso.sujetos.juezJuicioOral
                  : caso.sujetos.juezInvestigacionPreparatoria}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                sound.playTap();
                onOpenSujetos();
              }}
              title="Ver Magistrados del Caso"
              className="android-touch p-1.5 rounded-lg bg-slate-900 border border-amber-800/60 text-amber-300 hover:bg-slate-800 text-xs"
            >
              <span>🏛️ Jueces</span>
            </button>
            <button
              onClick={() => {
                sound.playTap();
                onOpenResumen();
              }}
              className="android-touch p-1.5 rounded-lg bg-slate-900 border border-amber-800/60 text-slate-200 hover:bg-slate-800 text-xs flex items-center gap-1"
            >
              <span>📋 Resumen</span>
            </button>
          </div>
        </div>

        {/* Dynamic Stepper Bar for Poder Judicial */}
        <div className="flex items-center gap-1 pt-1 text-[10px]">
          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'acusacion_enviada'
                ? 'bg-amber-600 text-slate-950 font-bold shadow'
                : ['etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual)
                ? 'bg-slate-900 text-amber-300'
                : 'bg-slate-900/40 text-slate-600'
            }`}
          >
            <span>1. Control Acusación</span>
            {['etapa_intermedia', 'juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual) && (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            )}
          </div>

          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'etapa_intermedia'
                ? 'bg-amber-600 text-slate-950 font-bold shadow'
                : ['juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual)
                ? 'bg-slate-900 text-amber-300'
                : 'bg-slate-900/40 text-slate-600'
            }`}
          >
            <span>2. Subcasos</span>
            {['juicio_oral', 'sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual) && (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            )}
          </div>

          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'juicio_oral'
                ? 'bg-amber-600 text-slate-950 font-bold shadow'
                : ['sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual)
                ? 'bg-slate-900 text-amber-300'
                : 'bg-slate-900/40 text-slate-600'
            }`}
          >
            <span>3. Juicio Oral</span>
            {['sentencia_dictada', 'caso_resuelto_definitivo'].includes(caso.etapaActual) && (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            )}
          </div>

          <div
            className={`flex-1 py-1 px-2 rounded flex items-center justify-center gap-1 font-semibold transition ${
              caso.etapaActual === 'sentencia_dictada' || caso.etapaActual === 'caso_resuelto_definitivo'
                ? 'bg-amber-500 text-slate-950 font-bold shadow'
                : 'bg-slate-900/40 text-slate-600'
            }`}
          >
            <span>4. Sentencia / Fallo</span>
            {caso.casoCerradoDefinitivo && <Award className="w-3 h-3 text-slate-950" />}
          </div>
        </div>
      </div>

      {/* Case Closed Seal (Cosa Juzgada) */}
      {caso.casoCerradoDefinitivo && (
        <div className="bg-gradient-to-r from-amber-900/60 via-amber-800/40 to-amber-900/60 border-b-2 border-amber-500 p-3 flex items-center justify-between text-xs text-amber-200">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400 animate-pulse" />
            <div>
              <span className="font-serif-legal font-bold tracking-wide text-amber-300 text-sm block">
                EXPEDIENTE RESUELTO CON CALIDAD DE COSA JUZGADA
              </span>
              <span className="text-[11px] text-slate-300">
                Instancias ordinarias y extraordinarias concluidas. El caso es definitivo y solo consultable.
              </span>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-[10px] font-mono-legal">
            ARCHIVADO DEFINITIVO
          </span>
        </div>
      )}

      {/* Sub navigation within Poder Judicial */}
      {isAcusacionSent && (
        <div className="flex bg-slate-950 border-b border-slate-800 text-xs px-3 overflow-x-auto">
          <button
            onClick={() => setPjSubTab('control')}
            className={`py-2 px-3 font-semibold border-b-2 whitespace-nowrap transition ${
              pjSubTab === 'control'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            1. Control de Acusación
          </button>

          <button
            onClick={() => setPjSubTab('subcasos')}
            className={`py-2 px-3 font-semibold border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              pjSubTab === 'subcasos'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>2. Subcasos ({resolvedCount}/{caso.subcasos.length})</span>
          </button>

          <button
            onClick={() => setPjSubTab('juicio')}
            className={`py-2 px-3 font-semibold border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
              pjSubTab === 'juicio'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>3. Juicio Oral y Sentencia</span>
            {caso.sentencia && <Award className="w-3 h-3 text-amber-400" />}
          </button>

          {caso.peticionesFiscales.length > 0 && (
            <button
              onClick={() => setPjSubTab('peticiones_pj')}
              className={`py-2 px-3 font-semibold border-b-2 whitespace-nowrap transition flex items-center gap-1.5 ${
                pjSubTab === 'peticiones_pj'
                  ? 'border-rose-500 text-rose-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Peticiones Fiscales</span>
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-[10px] text-rose-300 font-mono-legal font-bold">
                {caso.peticionesFiscales.length}
              </span>
            </button>
          )}
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        
        {/* CASE A: ACUSACIÓN HAS NOT BEEN TRANSMITTED YET */}
        {!isAcusacionSent && (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4 max-w-md mx-auto my-auto animate-in fade-in">
            <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-3xl shadow-xl">
              ⚖️
            </div>
            
            <div className="space-y-1.5">
              <h2 className="text-base font-bold text-slate-100 font-serif-legal">
                Juzgado en Espera de Acusación Fiscal
              </h2>
              <p className="text-slate-400 text-xs leading-relaxed">
                El sistema procesal acusatorio garantiza la separación de funciones: el Poder Judicial solo se activa cuando el Ministerio Público culmina su investigación preparatoria y formaliza el <strong>Requerimiento Acusatorio</strong>.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-left w-full space-y-2 text-[11px]">
              <div className="flex items-center justify-between text-slate-400">
                <span>Estado actual de la causa:</span>
                <span className="font-semibold text-rose-400 uppercase font-mono-legal">{caso.etapaActual.replace('_', ' ')}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Pruebas recabadas:</span>
                <span className="font-semibold text-slate-200">{caso.pruebasRecabadas.length} elementos</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Conductas imputadas:</span>
                <span className="font-semibold text-slate-200">{caso.conductas.length} individualizadas</span>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playTap();
                onNavigateToFiscalia();
              }}
              className="android-touch px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-950"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Ir a Fiscalía para Completar y Remitir Acusación</span>
            </button>
          </div>
        )}

        {/* CASE B: ACUSACIÓN IS SENT -> TAB 1: CONTROL DE ACUSACIÓN */}
        {isAcusacionSent && pjSubTab === 'control' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <FileCheck className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 font-serif-legal">
                      Audiencia de Control de Acusación
                    </h3>
                    <p className="text-slate-400 text-[11px]">
                      Juez de Investigación Preparatoria: {caso.sujetos.juezInvestigacionPreparatoria}
                    </p>
                  </div>
                </div>

                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono-legal ${
                  caso.evaluacionAcusacionPJ?.decision === 'aceptar'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : caso.evaluacionAcusacionPJ?.decision === 'devolver'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                }`}>
                  {caso.evaluacionAcusacionPJ?.decision?.toUpperCase() || 'EN EVALUACIÓN'}
                </span>
              </div>

              {/* Acusación details received from fiscalía */}
              <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-bold text-amber-300 text-xs">Pretensión Punitiva Fiscal:</span>
                  <span className="font-mono-legal text-rose-300 font-bold">
                    {caso.acusacionFiscal?.pretensionPunitiva || 'No indicada'}
                  </span>
                </div>

                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-bold text-amber-300 text-xs">Reparación Civil Pretendida:</span>
                  <span className="font-mono-legal text-emerald-300 font-bold">
                    S/ {caso.acusacionFiscal?.reparacionCivilSolicitada.toLocaleString() || '0'}
                  </span>
                </div>

                <div>
                  <span className="font-bold text-slate-300 text-[11px] block mb-1">
                    Fundamentación del Requerimiento Acusatorio:
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed bg-slate-900 p-2.5 rounded border border-slate-800">
                    {caso.acusacionFiscal?.fundamentosAcusacion || 'Sin fundamentos ingresados.'}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="font-bold text-slate-300 text-[11px] block mb-1">
                    Conductas y Delitos que pasarán a juicio ({caso.conductas.length}):
                  </span>
                  <div className="space-y-1">
                    {caso.conductas.map((cond, i) => (
                      <div key={cond.id || i} className="p-2 rounded bg-slate-900 text-[11px] flex justify-between items-center">
                        <div>
                          <strong className="text-rose-300">{cond.imputadoNombre}:</strong>{' '}
                          <span className="text-slate-200">{cond.descripcionConducta}</span>
                        </div>
                        <span className="text-[10px] text-amber-400 font-mono-legal shrink-0 ml-2">
                          {cond.tipificacionLegal}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Decisions for Juez */}
              {caso.evaluacionAcusacionPJ?.decision !== 'aceptar' && !caso.casoCerradoDefinitivo ? (
                <div className="pt-2 space-y-3">
                  <p className="text-slate-300 text-[11px] font-medium">
                    Pronunciamiento judicial del Juez de Investigación Preparatoria:
                  </p>

                  {/* Form if devolver is clicked */}
                  {showDevolverForm ? (
                    <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-900/60 space-y-2.5 animate-in fade-in">
                      <h4 className="font-bold text-rose-300 text-xs">
                        Fundamentar Motivo de Devolución de la Acusación
                      </h4>
                      <textarea
                        rows={2}
                        value={motivoDevolucion}
                        onChange={e => setMotivoDevolucion(e.target.value)}
                        placeholder="Detalla los defectos formales o sustanciales que la fiscalía debe corregir..."
                        className="w-full p-2.5 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setShowDevolverForm(false)}
                          className="android-touch px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handleDevolverAcusacion}
                          className="android-touch px-4 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
                        >
                          Emitir Auto de Devolución a Fiscalía
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        onClick={() => {
                          sound.playTap();
                          setShowDevolverForm(true);
                        }}
                        className="android-touch p-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/80 text-rose-300 flex items-center justify-center gap-2 font-bold text-xs transition"
                      >
                        <XCircle className="w-4 h-4 text-rose-400" />
                        <span>Devolver Acusación para Subsanación</span>
                      </button>

                      <button
                        onClick={handleAceptarAcusacion}
                        className="android-touch p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition"
                      >
                        <CheckCircle2 className="w-4 h-4 text-slate-950" />
                        <span>Aceptar Acusación y Abrir Subcasos</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span>
                      <strong>Acusación admitida:</strong> Auto de enjuiciamiento dictado con fecha {caso.evaluacionAcusacionPJ?.fecha}.
                    </span>
                  </div>
                  <button
                    onClick={() => setPjSubTab('subcasos')}
                    className="android-touch px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-500/40 font-bold text-xs"
                  >
                    Ver Subcasos
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CASE B: TAB 2: ETAPA INTERMEDIA Y SUBCASOS */}
        {isAcusacionSent && pjSubTab === 'subcasos' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    Etapa Intermedia: Gestión de Subcasos ({caso.subcasos.length})
                  </h3>
                  <p className="text-slate-400 text-[11px]">
                    Cada conducta imputada por fiscalía se procesa de forma individual en audiencias de análisis hasta su resolución.
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Progreso:</span>
                  <span className="font-bold font-mono-legal text-amber-300 text-xs">
                    {resolvedCount} de {caso.subcasos.length} Resueltos
                  </span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${caso.subcasos.length > 0 ? (resolvedCount / caso.subcasos.length) * 100 : 0}%`,
                  }}
                />
              </div>
            </div>

            {/* Subcases List */}
            <div className="space-y-3">
              {caso.subcasos.map((sub, idx) => {
                const isExpanded = expandedSubcaseId === sub.id;
                const statusBadge = {
                  pendiente: 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse',
                  procede_juicio: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
                  sobreseimiento: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
                  excluido_ilicitud: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
                }[sub.estado];

                return (
                  <div
                    key={sub.id || idx}
                    className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden transition-all shadow-md"
                  >
                    {/* Header */}
                    <div
                      onClick={() => {
                        sound.playTap();
                        setExpandedSubcaseId(isExpanded ? null : sub.id);
                      }}
                      className="p-3.5 bg-slate-900/90 hover:bg-slate-850 cursor-pointer flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-amber-200 text-xs">
                            {sub.titulo}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono-legal border ${statusBadge}`}>
                            {sub.estado.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                        <p className="text-slate-300 text-xs truncate max-w-sm sm:max-w-xl">
                          {sub.conductaDescripcion}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] text-slate-400 font-mono-legal">
                          {sub.pruebasAsignadas.length} pruebas
                        </span>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                      </div>
                    </div>

                    {/* Expanded details */}
                    {isExpanded && (
                      <div className="p-4 border-t border-slate-800 bg-slate-950/60 space-y-3.5 animate-in fade-in">
                        
                        {/* Legal classification */}
                        <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] flex justify-between items-center">
                          <span className="text-slate-400">Calificación Jurídica:</span>
                          <span className="text-amber-300 font-mono-legal font-bold">{sub.tipificacionLegal}</span>
                        </div>

                        {/* Associated evidence for this subcase */}
                        <div className="space-y-1.5">
                          <span className="font-bold text-slate-300 text-xs block">
                            Pruebas Recabadas Vinculadas al Subcaso ({sub.pruebasAsignadas.length}):
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {sub.pruebasAsignadas.map(pr => (
                              <div key={pr.id} className="p-2.5 rounded bg-slate-900 border border-slate-800 text-[11px]">
                                <div className="font-semibold text-slate-200 flex items-center justify-between">
                                  <span className="truncate">{pr.titulo}</span>
                                  <span className="text-[9px] uppercase px-1 rounded bg-slate-800 text-slate-400 font-mono-legal">
                                    {pr.tipo}
                                  </span>
                                </div>
                                <p className="text-slate-400 text-[10px] mt-1 line-clamp-2">{pr.descripcion}</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Audiencias of this subcase */}
                        <div className="space-y-2 pt-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-300 text-xs">
                              Audiencias de Análisis y Debate ({sub.audiencias.length}):
                            </span>
                            {!caso.casoCerradoDefinitivo && (
                              <button
                                onClick={() => setShowAddHearingModal(sub.id)}
                                className="android-touch px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-medium flex items-center gap-1"
                              >
                                <Plus className="w-3 h-3" />
                                <span>Nueva Audiencia</span>
                              </button>
                            )}
                          </div>

                          {/* Audiencias list */}
                          <div className="space-y-2">
                            {sub.audiencias.map((aud, aIdx) => (
                              <div key={aud.id || aIdx} className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5 text-[11px]">
                                <div className="flex items-center justify-between text-slate-400">
                                  <span className="font-semibold text-amber-300 uppercase">
                                    Audiencia de {aud.tipo}
                                  </span>
                                  <span className="font-mono-legal text-[10px]">{aud.fecha}</span>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                                  <div className="p-2 rounded bg-slate-950 border border-rose-950 text-slate-300">
                                    <strong className="text-rose-400 block mb-0.5">Fiscalía:</strong>
                                    {aud.alegatoFiscalia}
                                  </div>
                                  <div className="p-2 rounded bg-slate-950 border border-cyan-950 text-slate-300">
                                    <strong className="text-cyan-400 block mb-0.5">Defensa:</strong>
                                    {aud.alegatoDefensa}
                                  </div>
                                </div>
                                {aud.conclusionesJuez && (
                                  <p className="text-[10px] text-slate-400 italic pt-0.5">
                                    Juez: {aud.conclusionesJuez}
                                  </p>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Modal to add hearing */}
                        {showAddHearingModal === sub.id && (
                          <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/40 space-y-2.5 animate-in fade-in">
                            <h4 className="font-semibold text-amber-300 text-xs">
                              Registrar Audiencia de Análisis para {sub.imputadoNombre}
                            </h4>

                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-[10px] text-slate-400">Tipo de Audiencia</label>
                                <select
                                  value={hearingTipo}
                                  onChange={e => setHearingTipo(e.target.value as AudienciaSubcaso['tipo'])}
                                  className="w-full p-1.5 rounded bg-slate-950 border border-slate-700 text-xs text-white"
                                >
                                  <option value="alegatos">Alegatos y Supuestos Fácticos</option>
                                  <option value="debate_probatorio">Debate Probatorio y Exclusiones</option>
                                  <option value="supuestos">Control de Tipicidad</option>
                                  <option value="resolucion">Audiencia de Decisión</option>
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="text-[10px] text-slate-400">Alegato de Fiscalía</label>
                              <textarea
                                rows={2}
                                value={hearingFiscalia}
                                onChange={e => setHearingFiscalia(e.target.value)}
                                placeholder="Posición del fiscal sobre los hechos y pruebas..."
                                className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-xs text-white"
                              />
                            </div>

                            <div>
                              <label className="text-[10px] text-slate-400">Alegato de Defensa</label>
                              <textarea
                                rows={2}
                                value={hearingDefensa}
                                onChange={e => setHearingDefensa(e.target.value)}
                                placeholder="Refutación y excepciones de la defensa..."
                                className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-xs text-white"
                              />
                            </div>

                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => setShowAddHearingModal(null)}
                                className="android-touch px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                              >
                                Cancelar
                              </button>
                              <button
                                onClick={() => handleAddAudienciaSubcase(sub.id)}
                                className="android-touch px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs"
                              >
                                Guardar Audiencia
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Audiencia de Resolución del Subcaso */}
                        {!caso.casoCerradoDefinitivo && (
                          <div className="p-3.5 rounded-xl bg-gradient-to-br from-slate-900 to-amber-950/40 border border-amber-900/60 space-y-2.5">
                            <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                              <Gavel className="w-4 h-4 text-amber-400" />
                              Audiencia de Resolución de este Subcaso
                            </h4>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              <div>
                                <label className="text-[10px] text-slate-400">Decisión Judicial:</label>
                                <select
                                  value={subcaseDecisionOption}
                                  onChange={e => setSubcaseDecisionOption(e.target.value as SubcaseDecision)}
                                  className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-xs text-amber-300 font-bold"
                                >
                                  <option value="procede_juicio">Auto de Enjuiciamiento (Procede a Juicio Oral)</option>
                                  <option value="sobreseimiento">Auto de Sobreseimiento (Archivo)</option>
                                  <option value="excluido_ilicitud">Exclusión de Prueba Ilícita</option>
                                </select>
                              </div>

                              <div>
                                <label className="text-[10px] text-slate-400">Motivación del Juez:</label>
                                <input
                                  type="text"
                                  value={subcaseDecisionMotivacion}
                                  onChange={e => setSubcaseDecisionMotivacion(e.target.value)}
                                  placeholder="Fundamentos de la resolución..."
                                  className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-xs text-white"
                                />
                              </div>
                            </div>

                            <div className="flex justify-end pt-1">
                              <button
                                onClick={() => handleResolverSubcaso(sub.id)}
                                className="android-touch px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                              >
                                <Gavel className="w-3.5 h-3.5" />
                                Resolver este Subcaso
                              </button>
                            </div>
                          </div>
                        )}

                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Advance to Juicio Oral Button */}
            {!caso.casoCerradoDefinitivo && (
              <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-amber-950/40 border border-amber-500/40 space-y-2 text-center">
                <p className="text-slate-300 text-xs">
                  {allSubcasesResolved
                    ? '✅ ¡Todos los subcasos han sido resueltos! Procede abrir la etapa de Juicio Oral contradictorio.'
                    : '⏳ Se deben resolver todos los subcasos antes de habilitar el avance a Juicio Oral.'}
                </p>

                <button
                  disabled={!allSubcasesResolved}
                  onClick={handleAvanzarJuicioOral}
                  className={`android-touch px-6 py-3 rounded-xl font-bold text-xs inline-flex items-center gap-2 shadow-xl ${
                    allSubcasesResolved
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-950/60 cursor-pointer'
                      : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
                  }`}
                >
                  <Scale className="w-4 h-4" />
                  <span>Concluir Etapa Intermedia y Abrir Juicio Oral</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* CASE B: TAB 3: JUICIO ORAL Y SENTENCIA */}
        {isAcusacionSent && pjSubTab === 'juicio' && (
          <div className="space-y-4 animate-in fade-in">
            
            {/* JUICIO ORAL HEARINGS */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    ⚖️
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100 font-serif-legal">
                      Juicio Oral: Debate Contradictorio y Sentencia
                    </h3>
                    <p className="text-slate-400 text-[11px]">
                      Juez Penal de Juicio Oral: {caso.sujetos.juezJuicioOral}
                    </p>
                  </div>
                </div>

                {caso.sentencia && (
                  <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-mono-legal font-bold text-[10px] border border-amber-500/40">
                    SENTENCIA EMITIDA
                  </span>
                )}
              </div>

              {/* Alegatos de Apertura */}
              <div className="space-y-2">
                <span className="font-bold text-slate-300 text-xs block">
                  1. Alegatos de Apertura (Teoría del Caso):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-slate-950 border border-rose-900/50 space-y-1">
                    <span className="font-bold text-rose-400 text-[11px] block">Fiscalía:</span>
                    {caso.sentencia ? (
                      <p className="text-slate-300 text-[11px]">{caso.alegatosApertura?.fiscalia || alegAperturaFiscal}</p>
                    ) : (
                      <textarea
                        rows={2}
                        value={alegAperturaFiscal}
                        onChange={e => setAlegAperturaFiscal(e.target.value)}
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      />
                    )}
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-cyan-900/50 space-y-1">
                    <span className="font-bold text-cyan-400 text-[11px] block">Defensa:</span>
                    {caso.sentencia ? (
                      <p className="text-slate-300 text-[11px]">{caso.alegatosApertura?.defensa || alegAperturaDefensa}</p>
                    ) : (
                      <textarea
                        rows={2}
                        value={alegAperturaDefensa}
                        onChange={e => setAlegAperturaDefensa(e.target.value)}
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      />
                    )}
                  </div>
                </div>
              </div>

              {/* Alegatos de Clausura */}
              <div className="space-y-2">
                <span className="font-bold text-slate-300 text-xs block">
                  2. Alegatos de Clausura y Conclusiones Finales:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-slate-950 border border-rose-900/50 space-y-1">
                    <span className="font-bold text-rose-400 text-[11px] block">Fiscalía:</span>
                    {caso.sentencia ? (
                      <p className="text-slate-300 text-[11px]">{caso.alegatosClausura?.fiscalia || alegClausuraFiscal}</p>
                    ) : (
                      <textarea
                        rows={2}
                        value={alegClausuraFiscal}
                        onChange={e => setAlegClausuraFiscal(e.target.value)}
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      />
                    )}
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-cyan-900/50 space-y-1">
                    <span className="font-bold text-cyan-400 text-[11px] block">Defensa:</span>
                    {caso.sentencia ? (
                      <p className="text-slate-300 text-[11px]">{caso.alegatosClausura?.defensa || alegClausuraDefensa}</p>
                    ) : (
                      <textarea
                        rows={2}
                        value={alegClausuraDefensa}
                        onChange={e => setAlegClausuraDefensa(e.target.value)}
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* SENTENCIA SECTION */}
            {!caso.sentencia ? (
              <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-amber-950/20 to-slate-900 border border-amber-500/40 space-y-3.5 shadow-xl">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
                    📜
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-amber-200">
                      Deliberación y Dictado de Sentencia
                    </h3>
                    <p className="text-slate-400 text-[11px]">
                      Con base en los alegatos y pruebas actuadas, el Juez dicta sentencia definitiva de primera instancia.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-300 font-semibold mb-1 block">Sentido del Fallo</label>
                    <select
                      value={falloSentencia}
                      onChange={e => setFalloSentencia(e.target.value as 'condenatoria' | 'absolutoria' | 'mixta')}
                      className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-amber-300 font-bold"
                    >
                      <option value="condenatoria">Condenatoria (Culpabilidad probada)</option>
                      <option value="absolutoria">Absolutoria (In dubio pro reo / Inocencia)</option>
                      <option value="mixta">Mixta (Condena y absolución parcial)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold mb-1 block">Reparación Civil Fijada</label>
                    <input
                      type="number"
                      value={sentenciaReparacionMonto}
                      onChange={e => setSentenciaReparacionMonto(Number(e.target.value))}
                      className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono-legal"
                    />
                  </div>
                </div>

                {/* Individual penalties */}
                {falloSentencia !== 'absolutoria' && (
                  <div className="space-y-1.5">
                    <label className="text-slate-300 font-semibold block text-[11px]">
                      Individualización de Penas (Años de Prisión Efectiva):
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {caso.presuntosResponsables.map(resp => (
                        <div key={resp} className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px]">
                          <span className="text-slate-300 font-medium truncate block">{resp}</span>
                          <div className="flex items-center gap-1.5 mt-1">
                            <input
                              type="number"
                              min={1}
                              max={35}
                              value={penasIndividuales[resp] || 12}
                              onChange={e => {
                                setPenasIndividuales({
                                  ...penasIndividuales,
                                  [resp]: Number(e.target.value),
                                });
                              }}
                              className="w-16 p-1 rounded bg-slate-900 border border-slate-700 text-amber-300 font-bold font-mono-legal text-center text-xs"
                            />
                            <span className="text-slate-400 text-[10px]">años</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-slate-300 font-semibold mb-1 block text-[11px]">
                    Fundamentación Jurídica de la Sentencia
                  </label>
                  <textarea
                    rows={2}
                    value={fundamentoSentencia}
                    onChange={e => setFundamentoSentencia(e.target.value)}
                    className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-slate-200 text-xs"
                  />
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleDictarSentencia}
                    className="android-touch px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-xl shadow-amber-950/60"
                  >
                    <Gavel className="w-4 h-4 text-slate-950" />
                    <span>Dictar Sentencia Judicial</span>
                  </button>
                </div>
              </div>
            ) : (
              /* SENTENCIA ALREADY ISSUED DISPLAY */
              <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-amber-950/30 to-slate-900 border border-amber-500/60 space-y-3.5 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">⚖️</span>
                    <div>
                      <h3 className="font-bold text-sm text-amber-300 font-serif-legal">
                        Sentencia Judicial Dictada
                      </h3>
                      <p className="text-[10px] text-slate-400 font-mono-legal">
                        Fecha: {caso.sentencia.fecha} • Juez: {caso.sentencia.juezSentenciador}
                      </p>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-amber-500 text-slate-950 font-bold font-serif-legal text-xs tracking-wider">
                    {caso.sentencia.fallo.toUpperCase()}
                  </span>
                </div>

                {/* Sentencia penalties */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Penas Impuestas:
                    </span>
                    {caso.sentencia.penasImputados.map((p, i) => (
                      <div key={i} className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-300 font-medium">{p.imputadoNombre}</span>
                        <span className="font-bold text-amber-300 font-mono-legal">
                          {p.penaAnios > 0 ? `${p.penaAnios} años de prisión` : 'Absuelto'}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Reparación Civil Fijada:
                    </span>
                    <span className="text-base font-bold text-emerald-400 font-mono-legal block">
                      S/ {caso.sentencia.reparacionCivilMonto.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      En favor de: {caso.sentencia.reparacionCivilBeneficiario}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300 leading-relaxed">
                  <strong className="text-slate-200 block mb-1">Fundamentos del Fallo:</strong>
                  {caso.sentencia.fundamentacionJuridica}
                </div>

                {/* DYNAMIC APPEAL SYSTEM (APELAR / SEGUNDA APELACIÓN / ÚLTIMA APELACIÓN) */}
                {!caso.casoCerradoDefinitivo && (
                  <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="text-xs text-slate-400">
                      <span>Instancia recursiva actual: </span>
                      <strong className="text-amber-300 font-mono-legal">
                        {caso.apelacionActualIndex === 0
                          ? '1ª Instancia ordinaria'
                          : `Apelación ${caso.apelacionActualIndex} de 3`}
                      </strong>
                    </div>

                    <div className="flex items-center gap-2">
                      {caso.apelacionActualIndex < 3 && (
                        <button
                          onClick={() => {
                            sound.playTap();
                            setShowApelacionModal(true);
                          }}
                          className="android-touch px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-950"
                        >
                          <RotateCcw className="w-4 h-4" />
                          <span>{getApelacionButtonLabel()}</span>
                        </button>
                      )}

                      {caso.apelacionActualIndex === 3 && (
                        <button
                          onClick={handleDeclararCosaJuzgada}
                          className="android-touch px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-950"
                        >
                          <Award className="w-4 h-4" />
                          <span>Declarar Cosa Juzgada y Archivar</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Apelaciones History */}
            {caso.apelaciones.length > 0 && (
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <span className="font-bold text-xs text-purple-300 block">
                  Historial de Recursos de Apelación Interpuestos ({caso.apelaciones.length}):
                </span>
                <div className="space-y-2">
                  {caso.apelaciones.map((ap, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-purple-900/40 text-[11px] space-y-1">
                      <div className="flex justify-between items-center text-purple-400 font-bold">
                        <span>Recurso Nº {ap.numeroApelacion} • Interpuesto por {ap.quienApela.toUpperCase()}</span>
                        <span className="text-slate-400 font-mono-legal text-[10px]">{ap.fechaInterposicion}</span>
                      </div>
                      <p className="text-slate-300">{ap.motivosAgravios}</p>
                      <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                        <span>Jueces Superiores de la Sala: </span>
                        <strong className="text-purple-300">{ap.juecesSalaApelaciones.join(' • ')}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB 4: PETICIONES FISCALES IN PJ */}
        {isAcusacionSent && pjSubTab === 'peticiones_pj' && (
          <div className="space-y-4 animate-in fade-in">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <span>📋</span> Peticiones del Ministerio Público para Resolver
            </h3>

            <div className="space-y-3">
              {caso.peticionesFiscales.map(pet => (
                <div key={pet.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-300 text-xs">{pet.titulo}</span>
                    <span className="text-[10px] font-mono-legal text-slate-400">{pet.fecha}</span>
                  </div>

                  <p className="text-slate-300 text-xs leading-relaxed">{pet.fundamentacion}</p>

                  {pet.estado === 'pendiente' && !caso.casoCerradoDefinitivo ? (
                    <div className="pt-2 border-t border-slate-800 flex gap-2 justify-end">
                      <button
                        onClick={() => handleResolverPeticionJuez(pet.id, 'rechazada', 'El Juez declara infundada la petición por falta de peligro procesal.')}
                        className="android-touch px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-semibold"
                      >
                        Declarar Infundada
                      </button>

                      <button
                        onClick={() => handleResolverPeticionJuez(pet.id, 'admitida', 'El Juzgado declara fundada la petición promovida por el Ministerio Público conforme a ley.')}
                        className="android-touch px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-bold shadow"
                      >
                        Declarar Fundada
                      </button>
                    </div>
                  ) : (
                    <div className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] text-amber-200">
                      <strong>Resolución Judicial: </strong>
                      {pet.respuestaJuez || 'Petición resuelta.'}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* APELACIÓN MODAL */}
      {showApelacionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-purple-500/60 rounded-2xl shadow-2xl p-4 space-y-3.5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xl">⚖️</span>
                <h3 className="font-bold text-sm text-purple-200 font-serif-legal">
                  Interponer {getApelacionButtonLabel()}
                </h3>
              </div>
              <button
                onClick={() => setShowApelacionModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <p className="text-slate-300 text-[11px] leading-relaxed">
              La apelación devuelve los actuados a la etapa de subcasos para ser revisados por una <strong>nueva Sala Colegiada con otros jueces imparciales</strong>.
            </p>

            {/* If 3rd appeal: check admissibility */}
            {caso.apelacionActualIndex === 2 && (
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/80 space-y-2">
                <span className="font-bold text-amber-300 text-xs block">
                  Trámite Previo de Admisibilidad en Casación Suprema:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer text-xs">
                    <input
                      type="radio"
                      name="admisibilidad"
                      checked={admisibilidadUltima === 'admitida'}
                      onChange={() => setAdmisibilidadUltima('admitida')}
                    />
                    <span className="text-emerald-300 font-semibold">Admitir a Trámite</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer text-xs">
                    <input
                      type="radio"
                      name="admisibilidad"
                      checked={admisibilidadUltima === 'inadmisible'}
                      onChange={() => setAdmisibilidadUltima('inadmisible')}
                    />
                    <span className="text-rose-300 font-semibold">Declarar Inadmisible (Cerrar)</span>
                  </label>
                </div>
              </div>
            )}

            <div className="space-y-2 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Parte Recurrente</label>
                <select
                  value={quienApela}
                  onChange={e => setQuienApela(e.target.value as 'defensa' | 'fiscalia' | 'ambas_partes')}
                  className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-white text-xs"
                >
                  <option value="defensa">Defensa Técnica de los Imputados</option>
                  <option value="fiscalia">Ministerio Público (Fiscalía Superior)</option>
                  <option value="ambas_partes">Ambas Partes Procesales</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Expresión y Motivación de Agravios
                </label>
                <textarea
                  rows={3}
                  value={motivosAgravios}
                  onChange={e => setMotivosAgravios(e.target.value)}
                  placeholder="Detalla los errores de hecho o de derecho incurridos en la sentencia impugnada..."
                  className="w-full p-2.5 rounded bg-slate-950 border border-slate-700 text-slate-100 text-xs"
                />
              </div>

              <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-slate-400">
                <span>Magistrados Superiores que revisarán esta apelación: </span>
                <strong className="text-purple-300 block mt-0.5">
                  {caso.apelacionActualIndex === 0
                    ? caso.sujetos.juecesApelacionInstancia1.join(', ')
                    : caso.apelacionActualIndex === 1
                    ? caso.sujetos.juecesApelacionInstancia2.join(', ')
                    : caso.sujetos.juecesApelacionInstancia3.join(', ')}
                </strong>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowApelacionModal(false)}
                className="android-touch px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
              >
                Cancelar
              </button>
              <button
                onClick={handleProcesarApelacion}
                className="android-touch px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
              >
                Elevar Recurso y Reabrir en Subcasos
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
