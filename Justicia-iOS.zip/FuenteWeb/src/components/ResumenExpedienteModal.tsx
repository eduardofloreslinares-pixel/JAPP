import React, { useState } from 'react';
import { X, Calendar, MapPin, AlertTriangle, Users, UserCheck, Clock, Plus, Trash2, CheckCircle2, Lock, FileText } from 'lucide-react';
import { CasoJusticia, TimelineEvent } from '../types/justicia';
import { SujetosProcesalesModal } from './SujetosProcesalesModal';
import { sound } from '../utils/audioFeedback';

interface ResumenExpedienteModalProps {
  isOpen: boolean;
  embedded?: boolean;
  initialTab?: 'datos' | 'linea_temporal' | 'sujetos';
  onClose: () => void;
  caso: CasoJusticia;
  onUpdateCaso: (actualizado: Partial<CasoJusticia>) => void;
  isLockedByJudicialization: boolean;
}

export const ResumenExpedienteModal: React.FC<ResumenExpedienteModalProps> = ({
  isOpen, embedded = false, initialTab = 'datos',
  onClose,
  caso,
  onUpdateCaso,
  isLockedByJudicialization,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'datos' | 'linea_temporal' | 'sujetos'>(initialTab);
  
  React.useEffect(() => { setActiveSubTab(initialTab); }, [initialTab]);
  // State for new timeline event
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEventFecha, setNewEventFecha] = useState('');
  const [newEventHora, setNewEventHora] = useState('');
  const [newEventTitulo, setNewEventTitulo] = useState('');
  const [newEventDesc, setNewEventDesc] = useState('');
  const [newEventTipo, setNewEventTipo] = useState<TimelineEvent['tipo']>('diligencia');
  const [newEventAutor, setNewEventAutor] = useState('');

  // Editable fields for when not locked
  const [editQue, setEditQue] = useState(caso.queOcurrio);
  const [editCuando, setEditCuando] = useState(caso.cuando);
  const [editDonde, setEditDonde] = useState(caso.donde);
  const [editComo, setEditComo] = useState(caso.como);
  const [editDelito, setEditDelito] = useState(caso.delitoImputado);
  const [editVictima, setEditVictima] = useState(caso.presuntaVictima);
  const [editDesc, setEditDesc] = useState(caso.descripcionHechos);
  const [editResponsables, setEditResponsables] = useState(caso.presuntosResponsables.join(', '));

  React.useEffect(() => {
    setEditQue(caso.queOcurrio);
    setEditCuando(caso.cuando);
    setEditDonde(caso.donde);
    setEditComo(caso.como);
    setEditDelito(caso.delitoImputado);
    setEditVictima(caso.presuntaVictima);
    setEditDesc(caso.descripcionHechos);
    setEditResponsables(caso.presuntosResponsables.join(', '));
  }, [caso]);

  if (!isOpen) return null;

  const handleSaveFacts = () => {
    sound.playTap();
    const arrayResp = editResponsables
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    onUpdateCaso({
      queOcurrio: editQue,
      cuando: editCuando,
      donde: editDonde,
      como: editComo,
      delitoImputado: editDelito,
      presuntaVictima: editVictima,
      descripcionHechos: editDesc,
      presuntosResponsables: arrayResp,
    });
  };

  const handleAddTimelineEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitulo.trim()) return;

    sound.playTap();
    const nuevo: TimelineEvent = {
      id: 'tl-' + Date.now(),
      fecha: newEventFecha || new Date().toLocaleDateString(),
      hora: newEventHora || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      titulo: newEventTitulo.trim(),
      descripcion: newEventDesc.trim(),
      tipo: newEventTipo,
      autor: newEventAutor.trim() || undefined,
    };

    const actualizada = [...caso.lineaTemporal, nuevo];
    onUpdateCaso({ lineaTemporal: actualizada });

    // reset
    setNewEventTitulo('');
    setNewEventDesc('');
    setNewEventFecha('');
    setNewEventHora('');
    setNewEventAutor('');
    setShowAddEvent(false);
  };

  const handleDeleteTimelineEvent = (id: string) => {
    sound.playTap();
    const filtrada = caso.lineaTemporal.filter(ev => ev.id !== id);
    onUpdateCaso({ lineaTemporal: filtrada });
  };

  return (
    <div className={embedded ? "exp-inline" : "fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200"}>
      <div className={embedded ? "exp-sheet bg-slate-950 flex flex-col overflow-hidden" : "w-full sm:max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-700 sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col overflow-hidden"}>
        
        {/* Android Sheet Header & Handle */}
        <div className="exp-handle sm:hidden w-12 h-1 bg-slate-700 rounded-full mx-auto mt-2.5 mb-1" />
        
        <div className="exp-heading px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-sm font-bold">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100 font-serif-legal">
                Expediente
              </h2>
              <p className="text-[11px] text-amber-400/90 font-medium">
                {caso.numeroExpediente}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="exp-close android-touch p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Lock indicator if in judicial stage */}
        {isLockedByJudicialization && (
          <div className="bg-amber-950/40 border-b border-amber-900/40 px-4 py-1.5 flex items-center gap-2 text-[11px] text-amber-300">
            <Lock className="w-3.5 h-3.5 shrink-0 text-amber-400" />
            <span>
              <strong>Expediente bajo fuero judicial:</strong> Los hechos imputados son inmutables conforme al principio acusatorio.
            </span>
          </div>
        )}

        {/* Tabs: Datos Fácticos / Línea Temporal */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-3">
          <button
            onClick={() => setActiveSubTab('datos')}
            className={`py-2 px-3 text-xs font-semibold border-b-2 transition ${
              activeSubTab === 'datos'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Hechos y calificación
          </button>
          <button
            onClick={() => setActiveSubTab('linea_temporal')}
            className={`py-2 px-3 text-xs font-semibold border-b-2 transition flex items-center gap-1.5 ${
              activeSubTab === 'linea_temporal'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Cronología ({caso.lineaTemporal.length})
          </button>
          <button onClick={() => setActiveSubTab('sujetos')} className={`py-2 px-3 text-xs font-semibold border-b-2 ${activeSubTab === 'sujetos' ? 'border-purple-500 text-purple-400' : 'border-transparent text-slate-400'}`}>Sujetos</button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          
          {activeSubTab === 'sujetos' && <SujetosProcesalesModal isOpen={true} embedded={true} onClose={() => setActiveSubTab('datos')} sujetos={caso.sujetos} onSaveSujetos={sujetos => onUpdateCaso({ sujetos })} />}
          {/* TAB 1: DATOS FÁCTICOS */}
          {activeSubTab === 'datos' && (
            <div className="space-y-3.5">
              
              {/* ¿QUÉ OCURRIÓ? */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  ¿Qué ocurrió? (Hecho principal)
                </label>
                {isLockedByJudicialization ? (
                  <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-slate-200 leading-relaxed">
                    {caso.queOcurrio || 'No especificado'}
                  </div>
                ) : (
                  <textarea
                    rows={2}
                    value={editQue}
                    onChange={e => setEditQue(e.target.value)}
                    placeholder="Describe qué ocurrió de forma concisa..."
                    className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500/50"
                  />
                )}
              </div>

              {/* CUÁNDO Y DÓNDE (2 COLS) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold flex items-center gap-1 text-[11px] uppercase tracking-wider">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                    ¿Cuándo? (Fecha y hora)
                  </label>
                  {isLockedByJudicialization ? (
                    <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-slate-200">
                      {caso.cuando || 'No especificado'}
                    </div>
                  ) : (
                    <input
                      type="text"
                      value={editCuando}
                      onChange={e => setEditCuando(e.target.value)}
                      placeholder="Ej: 14 de Septiembre 2026, 18:45 hrs"
                      className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                    />
                  )}
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold flex items-center gap-1 text-[11px] uppercase tracking-wider">
                    <MapPin className="w-3.5 h-3.5 text-rose-400" />
                    ¿Dónde? (Lugar / Jurisdicción)
                  </label>
                  {isLockedByJudicialization ? (
                    <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-slate-200">
                      {caso.donde || 'No especificado'}
                    </div>
                  ) : (
                    <input
                      type="text"
                      value={editDonde}
                      onChange={e => setEditDonde(e.target.value)}
                      placeholder="Ej: Joyería El Diamante, Av. Central 450"
                      className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                    />
                  )}
                </div>
              </div>

              {/* ¿CÓMO OCURRIÓ? */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  ¿Cómo ocurrió? (Modus Operandi)
                </label>
                {isLockedByJudicialization ? (
                  <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-slate-200 leading-relaxed">
                    {caso.como || 'No especificado'}
                  </div>
                ) : (
                  <textarea
                    rows={2}
                    value={editComo}
                    onChange={e => setEditComo(e.target.value)}
                    placeholder="Describe el modus operandi y circunstancias..."
                    className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                  />
                )}
              </div>

              {/* DELITO IMPUTADO */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  ¿Qué se imputa? (Calificación Jurídica)
                </label>
                {isLockedByJudicialization ? (
                  <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-900/60 text-amber-200 font-semibold">
                    {caso.delitoImputado || 'Sin tipificación legal aún'}
                  </div>
                ) : (
                  <input
                    type="text"
                    value={editDelito}
                    onChange={e => setEditDelito(e.target.value)}
                    placeholder="Ej: Robo Agravado en banda (Art. 189 del Código Penal)"
                    className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-amber-300 font-medium focus:border-amber-500 focus:outline-none"
                  />
                )}
              </div>

              {/* RESPONSABLES Y VÍCTIMA */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold flex items-center gap-1 text-[11px] uppercase tracking-wider">
                    <Users className="w-3.5 h-3.5 text-rose-400" />
                    Presuntos Responsables (Imputados)
                  </label>
                  {isLockedByJudicialization ? (
                    <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-wrap gap-1">
                      {caso.presuntosResponsables.length > 0 ? (
                        caso.presuntosResponsables.map((r, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800/80 text-rose-200 text-[11px]"
                          >
                            {r}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-500">Sin individualizar</span>
                      )}
                    </div>
                  ) : (
                    <div>
                      <input
                        type="text"
                        value={editResponsables}
                        onChange={e => setEditResponsables(e.target.value)}
                        placeholder="Separa los nombres con comas (,)"
                        className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none text-[11px]"
                      />
                      <span className="text-[10px] text-slate-400">Separa cada persona imputada con comas.</span>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold flex items-center gap-1 text-[11px] uppercase tracking-wider">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Presunta Víctima (Agraviado)
                  </label>
                  {isLockedByJudicialization ? (
                    <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-emerald-200">
                      {caso.presuntaVictima || 'No especificada'}
                    </div>
                  ) : (
                    <input
                      type="text"
                      value={editVictima}
                      onChange={e => setEditVictima(e.target.value)}
                      placeholder="Nombre de la víctima o empresa"
                      className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                    />
                  )}
                </div>
              </div>

              {/* DESCRIPCIÓN CIRCUNSTANCIADA */}
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  Descripción Circunstanciada de los Hechos
                </label>
                {isLockedByJudicialization ? (
                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 text-slate-300 leading-relaxed whitespace-pre-line">
                    {caso.descripcionHechos || 'Sin descripción detallada.'}
                  </div>
                ) : (
                  <textarea
                    rows={3}
                    value={editDesc}
                    onChange={e => setEditDesc(e.target.value)}
                    placeholder="Relato cronológico y descriptivo exhaustivo..."
                    className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none leading-relaxed"
                  />
                )}
              </div>

              {/* Botón Guardar si no está bloqueado */}
              {!isLockedByJudicialization && (
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleSaveFacts}
                    className="android-touch bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-lg flex items-center gap-1.5 text-xs shadow-md shadow-amber-900/30"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Guardar Cambios en los Hechos
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: LÍNEA TEMPORAL */}
          {activeSubTab === 'linea_temporal' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-slate-300 text-[11px]">
                  Hitos cronológicos del suceso y del procedimiento penal:
                </p>
                <button
                  onClick={() => setShowAddEvent(!showAddEvent)}
                  className="android-touch flex items-center gap-1 bg-cyan-600 hover:bg-cyan-700 text-white px-2.5 py-1.5 rounded-lg text-[11px] font-semibold"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {showAddEvent ? 'Cancelar' : 'Añadir Hito'}
                </button>
              </div>

              {/* Add event form */}
              {showAddEvent && (
                <form
                  onSubmit={handleAddTimelineEvent}
                  className="p-3 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-2.5 animate-in fade-in"
                >
                  <h4 className="font-semibold text-cyan-300 text-xs flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Nuevo Hito en la Línea de Tiempo
                  </h4>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400">Fecha</label>
                      <input
                        type="text"
                        value={newEventFecha}
                        onChange={e => setNewEventFecha(e.target.value)}
                        placeholder="DD/MM/AAAA"
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400">Hora (opcional)</label>
                      <input
                        type="text"
                        value={newEventHora}
                        onChange={e => setNewEventHora(e.target.value)}
                        placeholder="HH:MM"
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400">Título del hito</label>
                    <input
                      type="text"
                      required
                      value={newEventTitulo}
                      onChange={e => setNewEventTitulo(e.target.value)}
                      placeholder="Ej: Allanamiento del almacén central"
                      className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400">Descripción</label>
                    <textarea
                      rows={2}
                      value={newEventDesc}
                      onChange={e => setNewEventDesc(e.target.value)}
                      placeholder="Qué ocurrió con exactitud en este hito..."
                      className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400">Tipo de Hito</label>
                      <select
                        value={newEventTipo}
                        onChange={e => setNewEventTipo(e.target.value as TimelineEvent['tipo'])}
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                      >
                        <option value="hecho">Hecho delictivo</option>
                        <option value="diligencia">Diligencia / Prueba</option>
                        <option value="resolucion">Disposición / Resolución</option>
                        <option value="audiencia">Audiencia Judicial</option>
                        <option value="apelacion">Recurso de Apelación</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400">Autor / Entidad</label>
                      <input
                        type="text"
                        value={newEventAutor}
                        onChange={e => setNewEventAutor(e.target.value)}
                        placeholder="Ej: Policía, Fiscal, Juez"
                        className="w-full p-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      className="android-touch bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-3 py-1.5 rounded text-xs"
                    >
                      Registrar Hito
                    </button>
                  </div>
                </form>
              )}

              {/* Timeline Items List */}
              <div className="relative pl-6 border-l-2 border-slate-800 space-y-4 my-2">
                {caso.lineaTemporal.length === 0 ? (
                  <p className="text-slate-500 italic text-center py-4">
                    No hay eventos registrados en la línea temporal.
                  </p>
                ) : (
                  caso.lineaTemporal.map((ev, idx) => {
                    const badgeColors = {
                      hecho: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
                      diligencia: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
                      resolucion: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                      audiencia: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
                      apelacion: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
                    }[ev.tipo];

                    return (
                      <div key={ev.id || idx} className="relative group">
                        {/* Timeline Node Icon */}
                        <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-slate-900 border-2 border-amber-500 flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        </div>

                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="font-mono-legal text-[11px] font-bold text-amber-400">
                              {ev.fecha} {ev.hora ? `• ${ev.hora}` : ''}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className={`text-[10px] px-2 py-0.5 rounded-full border ${badgeColors} capitalize`}>
                                {ev.tipo}
                              </span>
                              <button
                                onClick={() => handleDeleteTimelineEvent(ev.id)}
                                title="Eliminar hito"
                                className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 transition"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <h4 className="text-slate-100 font-semibold text-xs mb-1">
                            {ev.titulo}
                          </h4>
                          <p className="text-slate-300 text-[11px] leading-relaxed">
                            {ev.descripcion}
                          </p>

                          {ev.autor && (
                            <div className="mt-1.5 pt-1.5 border-t border-slate-800/80 text-[10px] text-slate-400 flex items-center gap-1">
                              <span>Actuado por:</span>
                              <span className="text-slate-300 font-medium">{ev.autor}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="exp-footer px-4 py-2.5 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
          <span>{caso.presuntosResponsables.length} imputados individualizados</span>
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="android-touch px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
          >
            Cerrar Vista
          </button>
        </div>

      </div>
    </div>
  );
};
