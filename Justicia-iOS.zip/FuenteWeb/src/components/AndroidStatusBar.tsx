import React from 'react';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor, Volume2, VolumeX, FileText, Users, Download } from 'lucide-react';
import { sound } from '../utils/audioFeedback';

interface AndroidStatusBarProps {
  isPhoneFrame: boolean;
  setIsPhoneFrame: (val: boolean) => void;
  onOpenResumen: () => void;
  onOpenSujetos: () => void;
  onOpenExport: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  numeroExpediente: string;
  etapaNombre: string;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({
  isPhoneFrame,
  setIsPhoneFrame,
  onOpenResumen,
  onOpenSujetos,
  onOpenExport,
  soundEnabled,
  setSoundEnabled,
  numeroExpediente,
  etapaNombre,
}) => {
  const [time, setTime] = React.useState('12:00');

  React.useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-slate-950 border-b border-slate-800/80 text-xs text-slate-300 select-none">
      {/* Android System Status Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 text-slate-400 font-mono-legal text-[11px]">
        <div className="flex items-center gap-1.5 font-semibold text-slate-200">
          <span>{time}</span>
          <span className="text-[10px] text-amber-400/90 font-sans tracking-wide uppercase px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
            Android 15
          </span>
        </div>

        <div className="flex items-center gap-3">
          <Signal className="w-3.5 h-3.5 text-slate-300" />
          <Wifi className="w-3.5 h-3.5 text-slate-300" />
          <div className="flex items-center gap-1">
            <span className="text-[10px]">98%</span>
            <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* App Toolbar / Action Strip */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-900/90 backdrop-blur-md border-t border-slate-800/60">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-600 to-amber-700 p-0.5 shadow-md shadow-amber-900/30 flex items-center justify-center shrink-0">
            <img src="/justicia-icon.svg" alt="" className="w-8 h-8" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-serif-legal font-bold text-slate-100 text-sm tracking-wide">
                JUSTICIA
              </span>
              <span className="text-[10px] font-mono-legal text-amber-300 truncate max-w-[130px] sm:max-w-[200px]">
                {numeroExpediente}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 truncate flex items-center gap-1">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <span className="truncate">{etapaNombre}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {/* Quick Resumen Button */}
          <button
            onClick={() => {
              sound.playTap();
              onOpenResumen();
            }}
            title="Ver Resumen y Línea Temporal"
            className="android-touch flex items-center gap-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 px-2.5 py-1 rounded-md text-[11px] font-medium transition"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Resumen</span>
          </button>

          {/* Sujetos procesales */}
          <button
            onClick={() => {
              sound.playTap();
              onOpenSujetos();
            }}
            title="Fiscales y Jueces"
            className="android-touch p-1.5 rounded-md hover:bg-slate-800 text-slate-300 transition"
          >
            <Users className="w-4 h-4 text-sky-400" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              sound.enabled = !soundEnabled;
              setSoundEnabled(!soundEnabled);
              sound.playTap();
            }}
            title={soundEnabled ? 'Sonidos activados' : 'Sonidos desactivados'}
            className="android-touch p-1.5 rounded-md hover:bg-slate-800 text-slate-300 transition"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* Phone Frame Toggle */}
          <button
            onClick={() => {
              sound.playTap();
              setIsPhoneFrame(!isPhoneFrame);
            }}
            title={isPhoneFrame ? 'Cambiar a Pantalla Completa' : 'Cambiar a Marco Móvil Android'}
            className="android-touch p-1.5 rounded-md hover:bg-slate-800 text-slate-300 transition"
          >
            {isPhoneFrame ? (
              <Monitor className="w-4 h-4 text-amber-400" />
            ) : (
              <Smartphone className="w-4 h-4 text-amber-400" />
            )}
          </button>

          {/* Export APK / Case */}
          <button
            onClick={() => {
              sound.playTap();
              onOpenExport();
            }}
            title="Exportar Expediente / APK Android"
            className="android-touch p-1.5 rounded-md hover:bg-slate-800 text-slate-300 transition"
          >
            <Download className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
