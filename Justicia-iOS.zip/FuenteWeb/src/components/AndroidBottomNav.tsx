import React from 'react';
import { ShieldAlert, Scale, Clock, Users, FileText } from 'lucide-react';
import { sound } from '../utils/audioFeedback';

export type MainTab = 'fiscalia' | 'poder_judicial' | 'expediente';

interface AndroidBottomNavProps {
  currentTab: MainTab;
  onChangeTab: (tab: MainTab) => void;
  onOpenResumen: () => void;
  onOpenSujetos: () => void;
  fiscaliaBadge?: number | string | null;
  pjBadge?: number | string | null;
  etapaActual: string;
}

export const AndroidBottomNav: React.FC<AndroidBottomNavProps> = ({
  currentTab,
  onChangeTab,
  onOpenResumen,
  onOpenSujetos,
  fiscaliaBadge,
  pjBadge,
}) => {
  return (
    <nav className="w-full bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1.5 pb-2.5 z-40 select-none shadow-2xl">
      <div className="max-w-md mx-auto grid grid-cols-3 items-center gap-1">
        
        {/* TAB 1: FISCALÍA */}
        <button
          onClick={() => {
            sound.playTap();
            sound.haptic();
            onChangeTab('fiscalia');
          }}
          className={`android-touch relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${
            currentTab === 'fiscalia'
              ? 'bg-rose-950/40 text-rose-300 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          {fiscaliaBadge && (
            <span className="absolute top-1 right-2 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-bold flex items-center justify-center animate-bounce">
              {fiscaliaBadge}
            </span>
          )}
          <div
            className={`p-1.5 rounded-lg transition-transform ${
              currentTab === 'fiscalia' ? 'scale-110 bg-rose-500/20 text-rose-400' : ''
            }`}
          >
            <ShieldAlert className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Fiscalía</span>
          <span className="text-[9px] text-slate-500 font-mono-legal -mt-0.5">Min. Público</span>
          {currentTab === 'fiscalia' && (
            <span className="w-8 h-1 rounded-full bg-rose-500 mt-1" />
          )}
        </button>

        {/* TAB 2: PODER JUDICIAL */}
        <button
          onClick={() => {
            sound.playTap();
            sound.haptic();
            onChangeTab('poder_judicial');
          }}
          className={`android-touch relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${
            currentTab === 'poder_judicial'
              ? 'bg-amber-950/40 text-amber-300 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          {pjBadge && (
            <span className="absolute top-1 right-2 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[9px] font-bold flex items-center justify-center animate-bounce">
              {pjBadge}
            </span>
          )}
          <div
            className={`p-1.5 rounded-lg transition-transform ${
              currentTab === 'poder_judicial' ? 'scale-110 bg-amber-500/20 text-amber-400' : ''
            }`}
          >
            <Scale className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Poder Judicial</span>
          <span className="text-[9px] text-slate-500 font-mono-legal -mt-0.5">Juzgados y Salas</span>
          {currentTab === 'poder_judicial' && (
            <span className="w-8 h-1 rounded-full bg-amber-500 mt-1" />
          )}
        </button>

        {/* TAB 3: RESUMEN Y LÍNEA TEMPORAL */}
        <button
          onClick={() => {
            sound.playTap();
            onOpenResumen();
          }}
          className={`android-touch flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${currentTab === 'expediente' ? 'bg-cyan-500/20 text-cyan-400 font-semibold' : 'text-slate-400 hover:text-cyan-300'}`}
        >
          <div className="p-1.5 rounded-lg text-cyan-400">
            <FileText className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Expediente</span>
          <span className="text-[9px] text-slate-500 font-mono-legal -mt-0.5">Resumen</span>
        </button>


      </div>
    </nav>
  );
};
