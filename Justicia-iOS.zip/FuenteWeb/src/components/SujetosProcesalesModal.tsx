import React, { useState } from 'react';
import { X, Users, ShieldAlert, Scale, Check, UserPlus } from 'lucide-react';
import { SujetosProcesales } from '../types/justicia';
import { sound } from '../utils/audioFeedback';

interface SujetosProcesalesModalProps {
  isOpen: boolean;
  embedded?: boolean;
  onClose: () => void;
  sujetos: SujetosProcesales;
  onSaveSujetos: (nuevosSujetos: SujetosProcesales) => void;
}

export const SujetosProcesalesModal: React.FC<SujetosProcesalesModalProps> = ({
  isOpen, embedded = false,
  onClose,
  sujetos,
  onSaveSujetos,
}) => {
  const [formData, setFormData] = useState<SujetosProcesales>({ ...sujetos });
  const [activeTab, setActiveTab] = useState<'fiscalia' | 'jueces_1ra' | 'jueces_apelacion' | 'otros'>('fiscalia');

  React.useEffect(() => {
    setFormData({ ...sujetos });
  }, [sujetos]);

  if (!isOpen) return null;

  const handleSave = () => {
    sound.playTap();
    onSaveSujetos(formData);
    onClose();
  };

  const handleUpdateJuecesApelacion = (
    instancia: 1 | 2 | 3,
    index: number,
    value: string
  ) => {
    if (instancia === 1) {
      const copy = [...formData.juecesApelacionInstancia1];
      copy[index] = value;
      setFormData({ ...formData, juecesApelacionInstancia1: copy });
    } else if (instancia === 2) {
      const copy = [...formData.juecesApelacionInstancia2];
      copy[index] = value;
      setFormData({ ...formData, juecesApelacionInstancia2: copy });
    } else {
      const copy = [...formData.juecesApelacionInstancia3];
      copy[index] = value;
      setFormData({ ...formData, juecesApelacionInstancia3: copy });
    }
  };

  return (
    <div className={embedded ? "subjects-inline" : "fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in"}>
      <div className={embedded ? "subjects-sheet" : "w-full sm:max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-700 sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col overflow-hidden"}>
        
        {/* Header */}
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center text-sm font-bold">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 font-serif-legal">
                Sujetos procesales
              </h3>
              <p className="text-[11px] text-slate-400">
                Designación de Fiscales y Magistrados en cada etapa e instancia
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="subjects-close android-touch p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 overflow-x-auto text-xs px-2">
          <button
            onClick={() => setActiveTab('fiscalia')}
            className={`py-2 px-3 whitespace-nowrap border-b-2 font-medium transition ${
              activeTab === 'fiscalia'
                ? 'border-rose-500 text-rose-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Fiscalía
          </button>
          <button
            onClick={() => setActiveTab('jueces_1ra')}
            className={`py-2 px-3 whitespace-nowrap border-b-2 font-medium transition ${
              activeTab === 'jueces_1ra'
                ? 'border-amber-500 text-amber-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Jueces 1ª Instancia
          </button>
          <button
            onClick={() => setActiveTab('jueces_apelacion')}
            className={`py-2 px-3 whitespace-nowrap border-b-2 font-medium transition ${
              activeTab === 'jueces_apelacion'
                ? 'border-purple-500 text-purple-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Jueces de Apelación
          </button>
          <button
            onClick={() => setActiveTab('otros')}
            className={`py-2 px-3 whitespace-nowrap border-b-2 font-medium transition ${
              activeTab === 'otros'
                ? 'border-cyan-500 text-cyan-400 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Defensa y Peritos
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          
          {/* TAB: FISCALÍA */}
          {activeTab === 'fiscalia' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-rose-950/20 border border-rose-900/40 text-[11px] text-rose-300 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  El Ministerio Público ostenta la titularidad de la acción penal pública y la carga probatoria.
                </span>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Fiscal Provincial Titular (Director de la Investigación)
                </label>
                <input
                  type="text"
                  value={formData.fiscalProvincial}
                  onChange={e => setFormData({ ...formData, fiscalProvincial: e.target.value })}
                  placeholder="Ej: Dr. Rodrigo Albarracín Muro"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Fiscal Adjunto(a) Provincial
                </label>
                <input
                  type="text"
                  value={formData.fiscalAdjunto}
                  onChange={e => setFormData({ ...formData, fiscalAdjunto: e.target.value })}
                  placeholder="Ej: Dra. Patricia Valdivia Campos"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-rose-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* TAB: JUECES 1ª INSTANCIA */}
          {activeTab === 'jueces_1ra' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-900/40 text-[11px] text-amber-300 flex items-center gap-2">
                <Scale className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  En el sistema acusatorio, el Juez de Garantías (Investigación Preparatoria) es distinto al Juez Sentenciador (Juicio Oral).
                </span>
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Juez de Investigación Preparatoria (Control de Etapa Intermedia)
                </label>
                <input
                  type="text"
                  value={formData.juezInvestigacionPreparatoria}
                  onChange={e => setFormData({ ...formData, juezInvestigacionPreparatoria: e.target.value })}
                  placeholder="Ej: Dra. Carmen Rosa Solís"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Juez Penal de Juicio Oral (Sentenciador Unipersonal / Colegiado)
                </label>
                <input
                  type="text"
                  value={formData.juezJuicioOral}
                  onChange={e => setFormData({ ...formData, juezJuicioOral: e.target.value })}
                  placeholder="Ej: Dr. Guillermo Navarro Peña"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* TAB: JUECES DE APELACIÓN (DIFERENTES MAGISTRADOS) */}
          {activeTab === 'jueces_apelacion' && (
            <div className="space-y-5">
              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-800/40 text-[11px] text-purple-200">
                <p className="font-semibold mb-1 flex items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5 text-purple-400" />
                  Garantía del Juez Natural y Principio de Imparcialidad:
                </p>
                <p className="text-slate-300">
                  Las apelaciones son resueltas por jueces superiores distintos a los que emitieron la resolución o sentencia apelada.
                </p>
              </div>

              {/* Instancia 1 de apelación */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h4 className="font-bold text-amber-400 text-xs flex items-center gap-1">
                  <span>🏛️</span> Primera Sala Penal de Apelaciones (1ª Apelación)
                </h4>
                {formData.juecesApelacionInstancia1.map((juez, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-[10px] text-slate-500 font-mono-legal text-right">
                      {idx === 0 ? 'Pres.' : `Voc. ${idx}`}
                    </span>
                    <input
                      type="text"
                      value={juez}
                      onChange={e => handleUpdateJuecesApelacion(1, idx, e.target.value)}
                      placeholder={`Magistrado ${idx + 1}`}
                      className="flex-1 p-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 focus:border-amber-500 focus:outline-none text-xs"
                    />
                  </div>
                ))}
              </div>

              {/* Instancia 2 de apelación */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h4 className="font-bold text-cyan-400 text-xs flex items-center gap-1">
                  <span>🏛️</span> Segunda Sala Penal Superior (2ª Apelación)
                </h4>
                {formData.juecesApelacionInstancia2.map((juez, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-[10px] text-slate-500 font-mono-legal text-right">
                      {idx === 0 ? 'Pres.' : `Voc. ${idx}`}
                    </span>
                    <input
                      type="text"
                      value={juez}
                      onChange={e => handleUpdateJuecesApelacion(2, idx, e.target.value)}
                      placeholder={`Magistrado Superior ${idx + 1}`}
                      className="flex-1 p-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 focus:border-cyan-500 focus:outline-none text-xs"
                    />
                  </div>
                ))}
              </div>

              {/* Instancia 3 (Casación / Suprema) */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h4 className="font-bold text-purple-400 text-xs flex items-center gap-1">
                  <span>⚖️</span> Sala Penal Permanente Suprema (Última Apelación / Casación)
                </h4>
                {formData.juecesApelacionInstancia3.map((juez, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-[10px] text-slate-500 font-mono-legal text-right">
                      {idx === 0 ? 'Sup. 1' : `Sup. ${idx + 1}`}
                    </span>
                    <input
                      type="text"
                      value={juez}
                      onChange={e => handleUpdateJuecesApelacion(3, idx, e.target.value)}
                      placeholder={`Juez Supremo ${idx + 1}`}
                      className="flex-1 p-1.5 rounded bg-slate-900 border border-slate-700 text-slate-200 focus:border-purple-500 focus:outline-none text-xs"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: OTROS (DEFENSA Y PERITO) */}
          {activeTab === 'otros' && (
            <div className="space-y-4">
              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Abogado Defensor (Defensa Técnica)
                </label>
                <input
                  type="text"
                  value={formData.abogadoDefensa}
                  onChange={e => setFormData({ ...formData, abogadoDefensa: e.target.value })}
                  placeholder="Ej: Dr. Alejandro Benítez Ortiz"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold mb-1 block">
                  Perito Oficial del Instituto de Medicina Legal / Criminalística
                </label>
                <input
                  type="text"
                  value={formData.peritoOficial}
                  onChange={e => setFormData({ ...formData, peritoOficial: e.target.value })}
                  placeholder="Ej: Mayor PNP Jorge L. Paredes"
                  className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex justify-end gap-2">
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="android-touch px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="android-touch px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-purple-950"
          >
            <Check className="w-4 h-4" />
            Guardar Magistrados
          </button>
        </div>

      </div>
    </div>
  );
};
