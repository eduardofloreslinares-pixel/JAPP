export type StageId = 
  | 'investigacion_preliminar'
  | 'investigacion_preparatoria'
  | 'acusacion_enviada'
  | 'etapa_intermedia'
  | 'juicio_oral'
  | 'sentencia_dictada'
  | 'caso_resuelto_definitivo';

export type SubcaseDecision = 'pendiente' | 'procede_juicio' | 'sobreseimiento' | 'excluido_ilicitud';

export interface TimelineEvent {
  id: string;
  fecha: string;
  hora?: string;
  titulo: string;
  descripcion: string;
  tipo: 'hecho' | 'diligencia' | 'resolucion' | 'audiencia' | 'apelacion';
  autor?: string;
}

export interface PruebaElemento {
  id: string;
  tipo: 'documental' | 'testimonial' | 'pericial' | 'material' | 'digital';
  titulo: string;
  descripcion: string;
  fechaRecabada: string;
  origen: string;
  pertinencia: string;
  admitidaPJ?: boolean;
}

export interface DiligenciaFiscal {
  id: string;
  titulo: string;
  tipo: 'inspeccion' | 'declaracion' | 'peritaje' | 'allanamiento' | 'informe' | 'diligencia' | 'otro';
  fecha: string;
  detalles: string;
  resultado: string;
  responsable: string;
}

export interface ConductaImputada {
  id: string;
  imputadoNombre: string;
  descripcionConducta: string;
  tipificacionLegal: string; // ej. Art 189 CP - Robo agravado
  gravedad: 'leve' | 'grave' | 'muy_grave';
  pruebasAsociadasIds: string[];
}

export interface AudienciaSubcaso {
  id: string;
  fecha: string;
  tipo: 'alegatos' | 'supuestos' | 'debate_probatorio' | 'resolucion';
  alegatoFiscalia: string;
  alegatoDefensa: string;
  conclusionesJuez?: string;
}

export interface SubcasoIntermedio {
  id: string;
  conductaId: string;
  titulo: string;
  imputadoNombre: string;
  conductaDescripcion: string;
  tipificacionLegal: string;
  pruebasAsignadas: PruebaElemento[];
  audiencias: AudienciaSubcaso[];
  estado: SubcaseDecision;
  motivacionDecision?: string;
  fechaResolucion?: string;
  juezResolutor?: string;
}

export interface PeticionFiscal {
  id: string;
  fecha: string;
  tipo: 'prision_preventiva' | 'incorporar_prueba' | 'apercibimiento' | 'reprogramacion' | 'medida_cautelar' | 'otra';
  titulo: string;
  fundamentacion: string;
  estado: 'pendiente' | 'admitida' | 'rechazada';
  respuestaJuez?: string;
  nuevaPrueba?: PruebaElemento;
}

export interface AlegatoJuicio {
  tipo: 'apertura' | 'clausura';
  fiscalia: string;
  defensa: string;
  fecha: string;
}

export interface SentenciaData {
  fecha: string;
  fallo: 'condenatoria' | 'absolutoria' | 'mixta';
  penasImputados: {
    imputadoNombre: string;
    penaAnios: number;
    tipoPena: string;
    inhabilitacionMeses?: number;
  }[];
  reparacionCivilMonto: number;
  reparacionCivilBeneficiario: string;
  fundamentacionJuridica: string;
  juezSentenciador: string;
}

export interface ApelacionRecord {
  numeroApelacion: 1 | 2 | 3;
  fechaInterposicion: string;
  quienApela: 'defensa' | 'fiscalia' | 'ambas_partes';
  motivosAgravios: string;
  juecesSalaApelaciones: string[];
  admisibilidadUltima?: 'admitida' | 'inadmisible' | 'pendiente';
  estado: 'en_tramite' | 'resuelta';
  resolucionSala?: string;
  falloApelacion?: 'confirma' | 'revoca' | 'anula_y_reordena';
}

export interface SujetosProcesales {
  fiscalProvincial: string;
  fiscalAdjunto: string;
  juezInvestigacionPreparatoria: string;
  juezJuicioOral: string;
  juecesApelacionInstancia1: string[];
  juecesApelacionInstancia2: string[];
  juecesApelacionInstancia3: string[];
  abogadoDefensa: string;
  peritoOficial: string;
}

export interface CasoJusticia {
  id: string;
  numeroExpediente: string;
  etapaActual: StageId;
  
  // Resumen del caso (visible en toda la app)
  queOcurrio: string;
  cuando: string; // fecha y hora
  donde: string; // lugar / ubicación
  como: string; // modus operandi
  delitoImputado: string;
  presuntosResponsables: string[];
  presuntaVictima: string;
  descripcionHechos: string;
  lineaTemporal: TimelineEvent[];

  // Sujetos procesales
  sujetos: SujetosProcesales;

  // Etapa 1: Investigación Preliminar
  diligenciasPreliminares: DiligenciaFiscal[];
  pruebasRecabadas: PruebaElemento[];
  evaluacionPreliminar: string;
  decisionPreliminar?: 'abrir_preparatoria' | 'archivar';
  fundamentacionPreliminar?: string;

  // Etapa 2: Investigación Preparatoria
  conductas: ConductaImputada[];
  diligenciasPreparatorias: DiligenciaFiscal[];
  acusacionFiscal?: {
    fecha: string;
    pretensionPunitiva: string;
    reparacionCivilSolicitada: number;
    fundamentosAcusacion: string;
    fiscalEmisor: string;
  };

  // Tránsito / Control de Acusación
  evaluacionAcusacionPJ?: {
    fecha: string;
    decision: 'aceptar' | 'devolver' | 'pendiente';
    motivoDevolucion?: string;
    fundamentacionAceptacion?: string;
    juezEvaluador: string;
  };

  // Peticiones de fiscalía en sede judicial
  peticionesFiscales: PeticionFiscal[];

  // Etapa 3: Etapa Intermedia (Subcasos)
  subcasos: SubcasoIntermedio[];

  // Etapa 4: Juicio Oral
  alegatosApertura?: AlegatoJuicio;
  alegatosClausura?: AlegatoJuicio;
  evaluacionAlegatosJuez?: string;
  sentencia?: SentenciaData;

  // Sistema de Apelaciones (hasta 3 apelaciones)
  apelaciones: ApelacionRecord[];
  apelacionActualIndex: number; // 0, 1, 2, 3
  casoCerradoDefinitivo: boolean;
  fechaCierreDefinitivo?: string;
}
