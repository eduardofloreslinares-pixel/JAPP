import { CasoJusticia } from '../types/justicia';

export const CASO_EJEMPLO: CasoJusticia = {
  id: 'exp-2026-0842-crim',
  numeroExpediente: 'EXP. 00842-2026-JR-PE-03',
  etapaActual: 'investigacion_preparatoria',
  
  queOcurrio: 'Asalto a mano armada y sustracción de joyas valorizadas en USD 85,000 con lesiones leves al guardia de seguridad.',
  cuando: '14 de Septiembre de 2026, 18:45 horas',
  donde: 'Joyería "El Diamante Real", Av. Los Libertadores 450, Centro Histórico',
  como: 'Tres sujetos irrumpieron con pasamontañas, redujeron al custodio de seguridad con arma de fuego, rompieron vitrinas con combas y huyeron en una camioneta negra con placa clonada.',
  delitoImputado: 'Robo Agravado con uso de armas en banda organizada (Art. 189 del Código Penal)',
  presuntosResponsables: [
    'Carlos "El Halcón" Mendoza',
    'Marcos Vivanco Salazar',
    'Raúl Peña Córdova'
  ],
  presuntaVictima: 'Joyería El Diamante Real S.A.C. y Manuel Ramos (vigilante)',
  descripcionHechos: 'El día 14 de septiembre a las 18:45 hrs, aprovechando el cierre comercial, tres individuos encapuchados ingresaron intimidando a clientes y empleados. Uno de ellos (identificado preliminarmente como Carlos Mendoza) encañonó al vigilante causándole contusión craneal leve, mientras los otros dos sustraían alhajas finas en mochilas térmicas.',
  
  lineaTemporal: [
    {
      id: 'tl-1',
      fecha: '14/09/2026',
      hora: '18:45',
      titulo: 'Comisión del Delito',
      descripcion: 'Ingreso violento a la joyería, agresión a guardia y sustracción de joyas.',
      tipo: 'hecho'
    },
    {
      id: 'tl-2',
      fecha: '14/09/2026',
      hora: '19:30',
      titulo: 'Intervención Policial y Fiscalía de Turno',
      descripcion: 'Llegada de peritos de criminalística y levantamiento de huellas dactilares.',
      tipo: 'diligencia',
      autor: 'Comisaría Central y Fiscal de Turno'
    },
    {
      id: 'tl-3',
      fecha: '16/09/2026',
      hora: '10:00',
      titulo: 'Disposición Fiscal de Inicio de Diligencias',
      descripcion: 'Fiscalía apertura formalmente la Investigación Preliminar por plazo de 60 días.',
      tipo: 'resolucion',
      autor: 'Fiscal Provincial Dr. Rodrigo Albarracín'
    },
    {
      id: 'tl-4',
      fecha: '20/09/2026',
      hora: '15:00',
      titulo: 'Captura en Flagrancia Diferida e Incautación',
      descripcion: 'Allanamiento de inmueble en Calle Los Pinos hallándose 30 piezas de joyería y arma de fuego.',
      tipo: 'diligencia',
      autor: 'DIVINCRI y Ministerio Público'
    }
  ],

  sujetos: {
    fiscalProvincial: 'Dr. Rodrigo Albarracín Muro (1ª Fiscalía Corporativa)',
    fiscalAdjunto: 'Dra. Patricia Valdivia Campos',
    juezInvestigacionPreparatoria: 'Dra. Carmen Rosa Solís (3º Juzgado de Inv. Preparatoria)',
    juezJuicioOral: 'Dr. Guillermo Navarro Peña (Juzgado Penal Unipersonal)',
    juecesApelacionInstancia1: [
      'Dr. Hernán Barreto (Presidente Sala Superior)',
      'Dra. Sofía Maldonado',
      'Dr. Esteban Ponce de León'
    ],
    juecesApelacionInstancia2: [
      'Dra. Beatriz Montenegro (Segunda Sala Penal)',
      'Dr. Andrés Quiroga',
      'Dra. Jimena Salas'
    ],
    juecesApelacionInstancia3: [
      'Dr. César San Martín Castro (Sala Penal Permanente Suprema)',
      'Dr. Víctor Prado Saldarriaga',
      'Dra. Elvia Barrios'
    ],
    abogadoDefensa: 'Dr. Alejandro Benítez Ortiz (Defensa Técnica de Imputados)',
    peritoOficial: 'Mayor PNP Jorge L. Paredes (Balística y Dactiloscopía)'
  },

  diligenciasPreliminares: [
    {
      id: 'dil-1',
      titulo: 'Acta de Inspección Criminalística e Inspección Ocular',
      tipo: 'inspeccion',
      fecha: '14/09/2026',
      detalles: 'Levantamiento de fragmentos de vidrio de vitrinas rotas y toma de muestras hematológicas en mostrador.',
      resultado: 'Se hallaron 4 impresiones dactilares aptas para cotejo homologadas con base AFIS.',
      responsable: 'Perito Oficial PNP Jorge L. Paredes'
    },
    {
      id: 'dil-2',
      titulo: 'Visualización de Cámaras de Seguridad de la Joyería y Vía Pública',
      tipo: 'diligencia',
      fecha: '15/09/2026',
      detalles: 'Extracción del disco duro DVR de seguridad con 4 ángulos de video HD.',
      resultado: 'Se identifica complexión física y tatuaje distintivo en antebrazo derecho atribuible a Carlos Mendoza.',
      responsable: 'Dra. Patricia Valdivia Campos (Fiscal Adjunta)'
    },
    {
      id: 'dil-3',
      titulo: 'Certificado Médico Legal del vigilante Manuel Ramos',
      tipo: 'peritaje',
      fecha: '15/09/2026',
      detalles: 'Evaluación de policontusiones y traumatismo encéfalo craneano leve por golpe de cacha de revólver.',
      resultado: '8 días de atención médica y 20 días de incapacidad médico-legal.',
      responsable: 'Médico Legista IML'
    }
  ],

  pruebasRecabadas: [
    {
      id: 'pr-1',
      tipo: 'documental',
      titulo: 'Video DVR de 1080p con secuencia completa del atraco',
      descripcion: 'Grabación de 14 minutos que muestra ingreso, reducción del vigilante y fractura de mostradores.',
      fechaRecabada: '15/09/2026',
      origen: 'Cámaras Joyería El Diamante Real',
      pertinencia: 'Acredita modo, tiempo, lugar y uso concertado de armas de fuego.'
    },
    {
      id: 'pr-2',
      tipo: 'pericial',
      titulo: 'Informe Pericial Dactiloscópico Nº 249-2026',
      descripcion: 'Cotejo positivo de huella latente hallada en el marco de la vitrina con índice derecho de Carlos Mendoza.',
      fechaRecabada: '18/09/2026',
      origen: 'Laboratorio Central de Criminalística',
      pertinencia: 'Vincula de forma directa y concluyente a Carlos Mendoza en el lugar de los hechos.'
    },
    {
      id: 'pr-3',
      tipo: 'material',
      titulo: 'Revólver Taurus Calibre .38 SPL con número limado incautado',
      descripcion: 'Arma de fuego con 4 cartuchos percutidos y dos sin percutir hallada en poder de Marcos Vivanco.',
      fechaRecabada: '20/09/2026',
      origen: 'Allanamiento domiciliario',
      pertinencia: 'Arma empleada para amedrentar a las víctimas en la consumación.'
    },
    {
      id: 'pr-4',
      tipo: 'testimonial',
      titulo: 'Declaración Testimonial del Vigilante Manuel Ramos',
      descripcion: 'Relato circunstanciado reconociendo la voz, contextura y las amenazas de muerte proferidas por los asaltantes.',
      fechaRecabada: '22/09/2026',
      origen: 'Despacho Fiscal',
      pertinencia: 'Acredita la violencia física y zozobra provocada durante el asalto.'
    }
  ],

  evaluacionPreliminar: 'Se cuenta con indicios reveladores de la existencia del delito de Robo Agravado y vinculación directa de los tres imputados.',
  decisionPreliminar: 'abrir_preparatoria',
  fundamentacionPreliminar: 'Habiéndose recopilado elementos de convicción de alta gravedad e individualizado a los presuntos partícipes, procede formalizar y continuar con la investigación preparatoria conforme a ley.',

  conductas: [
    {
      id: 'cond-1',
      imputadoNombre: 'Carlos "El Halcón" Mendoza',
      descripcionConducta: 'Ingreso violento con arma de fuego, encañonamiento y reducción violenta del custodio de seguridad causándole lesiones.',
      tipificacionLegal: 'Art. 189 Inc. 1, 3 y 4 del Código Penal (Robo con crueldad y arma de fuego)',
      gravedad: 'muy_grave',
      pruebasAsociadasIds: ['pr-1', 'pr-2', 'pr-4']
    },
    {
      id: 'cond-2',
      imputadoNombre: 'Marcos Vivanco Salazar',
      descripcionConducta: 'Fractura de vitrinas principales con comba y embolsado de 42 relojes y gargantillas de oro.',
      tipificacionLegal: 'Art. 189 Inc. 4 del Código Penal (Concurso de dos o más personas)',
      gravedad: 'grave',
      pruebasAsociadasIds: ['pr-1', 'pr-3']
    },
    {
      id: 'cond-3',
      imputadoNombre: 'Raúl Peña Córdova',
      descripcionConducta: 'Conducción y facilitación del vehículo de fuga tipo camioneta 4x4 con placa clonada y contravigilancia externa.',
      tipificacionLegal: 'Art. 189 Código Penal en calidad de Cómplice Primario',
      gravedad: 'grave',
      pruebasAsociadasIds: ['pr-1']
    }
  ],

  diligenciasPreparatorias: [
    {
      id: 'dil-prep-1',
      titulo: 'Reconstrucción Fiscal de los Hechos con Presencia Judicial',
      tipo: 'diligencia',
      fecha: '02/10/2026',
      detalles: 'Verificación in situ de las rutas de ingreso, escape y roles ejecutados por cada investigado.',
      resultado: 'Corrobora coincidencia milimétrica con los videos de seguridad y versiones testificales.',
      responsable: 'Fiscal Provincial Dr. Rodrigo Albarracín'
    }
  ],

  peticionesFiscales: [],
  subcasos: [],
  apelaciones: [],
  apelacionActualIndex: 0,
  casoCerradoDefinitivo: false
};

export const CASO_EN_BLANCO: CasoJusticia = {
  id: 'exp-nuevo-' + Date.now(),
  numeroExpediente: 'EXP. ' + Math.floor(1000 + Math.random() * 9000) + '-2026-JR-PE-01',
  etapaActual: 'investigacion_preliminar',
  
  queOcurrio: '',
  cuando: '',
  donde: '',
  como: '',
  delitoImputado: '',
  presuntosResponsables: [],
  presuntaVictima: '',
  descripcionHechos: '',
  lineaTemporal: [],

  sujetos: {
    fiscalProvincial: 'Dr. Fiscal Provincial Titular',
    fiscalAdjunto: 'Dra. Fiscal Adjunta',
    juezInvestigacionPreparatoria: 'Dra. Jueza de Investigación Preparatoria',
    juezJuicioOral: 'Dr. Juez Penal Unipersonal',
    juecesApelacionInstancia1: ['Vocal Presidente 1', 'Vocal 2', 'Vocal 3'],
    juecesApelacionInstancia2: ['Vocal Superior A', 'Vocal Superior B', 'Vocal Superior C'],
    juecesApelacionInstancia3: ['Juez Supremo 1', 'Juez Supremo 2', 'Juez Supremo 3'],
    abogadoDefensa: 'Dr. Abogado Defensor',
    peritoOficial: 'Perito Criminalístico Oficial'
  },

  diligenciasPreliminares: [],
  pruebasRecabadas: [],
  evaluacionPreliminar: '',
  conductas: [],
  diligenciasPreparatorias: [],
  peticionesFiscales: [],
  subcasos: [],
  apelaciones: [],
  apelacionActualIndex: 0,
  casoCerradoDefinitivo: false
};
