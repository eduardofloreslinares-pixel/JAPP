import SwiftUI

struct Expediente: View {
    @EnvironmentObject private var archivo: Archivo
    let caso: CasoJusticia
    var desdeJuzgado = false
    @State private var seccion = 0
    @State private var formulario: Formulario?
    @State private var borrarHito: TimelineEvent?

    private var editable: Bool {
        caso.fiscalEdita || (desdeJuzgado && !caso.cerrado && caso.evaluacionAcusacionPJ?.decision == "aceptar")
    }

    var body: some View {
        Contenedor {
            Cabecera(caso: caso, icono: "doc.text.fill", color: .indigo)
            Picker("Sección del expediente", selection: $seccion) {
                Text("Hechos").tag(0)
                Text("Cronología").tag(1)
                Text("Sujetos").tag(2)
            }
            .pickerStyle(.segmented)
            switch seccion {
            case 1: cronologia
            case 2: sujetos
            default: hechos
            }
        }
        .sheet(item: $formulario) { Editor(formulario: $0).tint(.indigo) }
        .alert("¿Eliminar este hito?", isPresented: Binding(get: { borrarHito != nil }, set: { if !$0 { borrarHito = nil } })) {
            Button("Cancelar", role: .cancel) { borrarHito = nil }
            Button("Eliminar", role: .destructive) {
                if let id = borrarHito?.id { actualizar { $0.lineaTemporal.removeAll { $0.id == id } } }
                borrarHito = nil
            }
        } message: { Text(borrarHito?.titulo ?? "") }
    }

    private var hechos: some View {
        Tarjeta(titulo: "Hechos y calificación", icono: "list.bullet.rectangle", color: .indigo) {
            Dato("Qué ocurrió", caso.queOcurrio)
            Dato("Cuándo", caso.cuando)
            Dato("Dónde", caso.donde)
            Dato("Cómo", caso.como)
            Dato("Qué se imputa", caso.delitoImputado)
            Dato("Presuntos responsables", caso.presuntosResponsables.joined(separator: "\n"))
            Dato("Presunta víctima", caso.presuntaVictima)
            Dato("Descripción", caso.descripcionHechos)
            if caso.queOcurrio.isEmpty && caso.descripcionHechos.isEmpty {
                Text("Completa los datos para construir el resumen del caso.").font(.subheadline).foregroundStyle(.secondary)
            }
            if editable {
                Accion(titulo: "Editar hechos", icono: "square.and.pencil") { editarHechos() }
            } else if caso.judicializado {
                Label("Edición a cargo del Poder Judicial", systemImage: "lock").font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder private var cronologia: some View {
        if editable {
            Accion(titulo: "Añadir hito", icono: "plus", principal: true) { editarHito() }
        }
        if caso.lineaTemporal.isEmpty {
            ContentUnavailableView("Sin actuaciones", systemImage: "clock", description: Text("Aquí aparecerán los hitos y las decisiones del expediente."))
        }
        ForEach(Array(caso.lineaTemporal.reversed())) { hito in
            Tarjeta(titulo: hito.titulo, icono: icono(hito.tipo), color: .indigo) {
                Text(([hito.fecha, hito.hora ?? "", rotulo(hito.tipo)].filter { !$0.isEmpty }).joined(separator: " · "))
                    .font(.caption.weight(.medium)).foregroundStyle(.secondary)
                Text(hito.descripcion).font(.subheadline)
                Dato("Actuado por", hito.autor ?? "")
                if editable && !caso.cerrado {
                    Menu("Opciones del hito", systemImage: "ellipsis.circle") {
                        Button("Editar", systemImage: "pencil") { editarHito(hito) }
                        Button(role: .destructive) { borrarHito = hito } label: { Label("Eliminar", systemImage: "trash") }
                    }
                }
            }
        }
    }

    private var sujetos: some View {
        let s = caso.sujetos
        return Tarjeta(titulo: "Sujetos procesales", icono: "person.2", color: .indigo) {
            Dato("Fiscal provincial", s.fiscalProvincial)
            Dato("Fiscal adjunto", s.fiscalAdjunto)
            Dato("Juez de investigación preparatoria", s.juezInvestigacionPreparatoria)
            Dato("Juez de juicio oral", s.juezJuicioOral)
            Dato("Sala de primera apelación", s.juecesApelacionInstancia1.joined(separator: "\n"))
            Dato("Sala de segunda apelación", s.juecesApelacionInstancia2.joined(separator: "\n"))
            Dato("Sala de última apelación", s.juecesApelacionInstancia3.joined(separator: "\n"))
            Dato("Abogado defensor", s.abogadoDefensa)
            Dato("Perito oficial", s.peritoOficial)
            if editable || (desdeJuzgado && !caso.cerrado) {
                Accion(titulo: "Editar sujetos", icono: "square.and.pencil") { editarSujetos() }
            }
        }
    }

    private func actualizar(_ modificar: (inout CasoJusticia) -> Void) {
        archivo.actualizar(caso.id, modificar)
    }

    private func editarHechos() {
        formulario = Formulario(titulo: "Hechos del expediente", campos: [
            .largo("que", "¿Qué ocurrió?", inicial: caso.queOcurrio, requerido: false),
            .texto("cuando", "¿Cuándo?", inicial: caso.cuando, requerido: false),
            .texto("donde", "¿Dónde?", inicial: caso.donde, requerido: false),
            .largo("como", "¿Cómo?", inicial: caso.como, requerido: false),
            .texto("delito", "¿Qué se imputa?", inicial: caso.delitoImputado, requerido: false),
            .largo("imputados", "Presuntos responsables · uno por línea", inicial: caso.presuntosResponsables.joined(separator: "\n"), requerido: false),
            .texto("victima", "Presunta víctima", inicial: caso.presuntaVictima, requerido: false),
            .largo("descripcion", "Descripción", inicial: caso.descripcionHechos, requerido: false)
        ]) { v in
            actualizar {
                $0.queOcurrio = v["que"]; $0.cuando = v["cuando"]; $0.donde = v["donde"]; $0.como = v["como"]
                $0.delitoImputado = v["delito"]; $0.presuntosResponsables = v.nombres("imputados")
                $0.presuntaVictima = v["victima"]; $0.descripcionHechos = v["descripcion"]
            }
        }
    }

    private func editarHito(_ previo: TimelineEvent? = nil) {
        formulario = Formulario(titulo: previo == nil ? "Nuevo hito" : "Editar hito", campos: [
            .texto("titulo", "Título", inicial: previo?.titulo ?? ""),
            .opciones("tipo", "Tipo", ["hecho", "diligencia", "resolucion", "audiencia", "apelacion"], inicial: previo?.tipo),
            .texto("fecha", "Fecha", inicial: previo?.fecha ?? hoy()),
            .texto("hora", "Hora", inicial: previo?.hora ?? "", requerido: false),
            .texto("autor", "Actuado por", inicial: previo?.autor ?? "", requerido: false),
            .largo("descripcion", "Descripción", inicial: previo?.descripcion ?? "")
        ]) { v in
            actualizar { c in
                let hito = TimelineEvent(id: previo?.id ?? nuevoID(), fecha: v["fecha"], hora: v["hora"], titulo: v["titulo"],
                                         descripcion: v["descripcion"], tipo: v["tipo"], autor: v["autor"])
                if let i = c.lineaTemporal.firstIndex(where: { $0.id == hito.id }) { c.lineaTemporal[i] = hito }
                else { c.lineaTemporal.append(hito) }
            }
        }
    }

    private func editarSujetos() {
        let s = caso.sujetos
        formulario = Formulario(titulo: "Sujetos procesales", campos: [
            .texto("fiscal", "Fiscal provincial", inicial: s.fiscalProvincial),
            .texto("adjunto", "Fiscal adjunto", inicial: s.fiscalAdjunto, requerido: false),
            .texto("preparatoria", "Juez de investigación preparatoria", inicial: s.juezInvestigacionPreparatoria),
            .texto("oral", "Juez de juicio oral", inicial: s.juezJuicioOral),
            .largo("sala1", "Primera apelación · un juez por línea", inicial: s.juecesApelacionInstancia1.joined(separator: "\n")),
            .largo("sala2", "Segunda apelación · un juez por línea", inicial: s.juecesApelacionInstancia2.joined(separator: "\n")),
            .largo("sala3", "Última apelación · un juez por línea", inicial: s.juecesApelacionInstancia3.joined(separator: "\n")),
            .texto("defensa", "Abogado defensor", inicial: s.abogadoDefensa, requerido: false),
            .texto("perito", "Perito oficial", inicial: s.peritoOficial, requerido: false)
        ]) { v in
            actualizar { c in
                c.sujetos = .init(fiscalProvincial: v["fiscal"], fiscalAdjunto: v["adjunto"], juezInvestigacionPreparatoria: v["preparatoria"],
                                  juezJuicioOral: v["oral"], juecesApelacionInstancia1: v.nombres("sala1"), juecesApelacionInstancia2: v.nombres("sala2"),
                                  juecesApelacionInstancia3: v.nombres("sala3"), abogadoDefensa: v["defensa"], peritoOficial: v["perito"])
            }
        }
    }

    private func icono(_ tipo: String) -> String {
        switch tipo {
        case "diligencia": "list.clipboard"
        case "resolucion": "checkmark.seal"
        case "audiencia": "person.2"
        case "apelacion": "arrow.turn.up.right"
        default: "clock"
        }
    }
}

struct ExpedienteJudicial: View {
    @EnvironmentObject private var archivo: Archivo
    let id: String
    var body: some View {
        if let caso = archivo.expedientes.first(where: { $0.id == id }) {
            Expediente(caso: caso, desdeJuzgado: true)
                .navigationTitle("Expediente judicial")
        }
    }
}
