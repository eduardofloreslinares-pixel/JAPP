import SwiftUI

struct Expediente: View {
    @EnvironmentObject private var archivo: Archivo
    let caso: CasoJusticia
    var desdeJuzgado = false
    @State private var seccion = 0
    @State private var formulario: Formulario?
    @State private var borrarHito: TimelineEvent?

    private var editable: Bool {
        caso.fiscalEdita || (desdeJuzgado && !caso.cerrado && caso.evaluacionAcusacionPJ?.decision == "aceptar")
    }

    var body: some View {
        Contenedor {
            Cabecera(caso: caso, icono: "doc.text.fill", color: .indigo)
            Accesos(nombre: "Secciones del expediente", destinos: [
                .init(id: 0, titulo: "Hechos", icono: "doc.text"),
                .init(id: 1, titulo: "Cronología", icono: "clock", valor: String(caso.lineaTemporal.count)),
                .init(id: 2, titulo: "Sujetos", icono: "person.2", valor: String(caso.presuntosResponsables.count)),
                .init(id: 3, titulo: "Pruebas", icono: "tray.full", valor: String(caso.pruebasRecabadas.count))
            ], seleccion: $seccion, color: .indigo)
            switch seccion {
            case 1: cronologia
            case 2: sujetos
            case 3: pruebas
            default: hechos
            }
        }
        .sheet(item: $formulario) { Editor(formulario: $0, caso: caso).tint(.indigo) }
        .alert("¿Eliminar este hito?", isPresented: Binding(get: { borrarHito != nil }, set: { if !$0 { borrarHito = nil } })) {
            Button("Cancelar", role: .cancel) { borrarHito = nil }
            Button("Eliminar", role: .destructive) {
                if let id = borrarHito?.id { actualizar { $0.lineaTemporal.removeAll { $0.id == id } } }
                borrarHito = nil
            }
        } message: { Text(borrarHito?.titulo ?? "") }
    }

    private var pruebas: some View {
        Tarjeta(titulo: "Pruebas del expediente", icono: "tray.full", color: .indigo) {
            if caso.pruebasRecabadas.isEmpty { Text("Todavía no hay pruebas.").foregroundStyle(.secondary) }
            ForEach(caso.pruebasRecabadas) { PruebaFila(prueba: $0) }
        }
    }

    private var hechos: some View {
        Tarjeta(titulo: "Hechos y calificación", icono: "list.bullet.rectangle", color: .indigo) {
            Dato("Qué ocurrió", caso.queOcurrio)
            Dato("Cuándo", caso.cuando)
            Dato("Dónde", caso.donde)
            Dato("Por qué", caso.porQue ?? "")
            Dato("Cómo", caso.como)
            Dato("Qué se imputa", caso.delitoImputado)
            Dato("Presuntos responsables", caso.presuntosResponsables.joined(separator: "\n"))
            Dato("Presunta víctima", caso.presuntaVictima)
            Dato("Descripción", caso.descripcionHechos)
            if caso.queOcurrio.isEmpty && caso.descripcionHechos.isEmpty {
                Text("Completa los datos para construir el resumen del caso.").font(.subheadline).foregroundStyle(.secondary)
            }
            if editable {
                Accion(titulo: "Editar hechos", icono: "square.and.pencil") { editarHechos() }
            } else if caso.judicializado {
                Label("Edición a cargo del Poder Judicial", systemImage: "lock").font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder private var cronologia: some View {
        if editable {
            Accion(titulo: "Añadir hito", icono: "plus", principal: true) { editarHito() }
        }
        if caso.lineaTemporal.isEmpty {
            ContentUnavailableView("Sin actuaciones", systemImage: "clock", description: Text("Aquí aparecerán los hitos y las decisiones del expediente."))
        }
        ForEach(Array(caso.lineaTemporal.reversed())) { hito in
            Tarjeta(titulo: hito.titulo, icono: icono(hito.tipo), color: .indigo) {
                Text(([hito.fecha, hito.hora ?? "", rotulo(hito.tipo)].filter { !$0.isEmpty }).joined(separator: " · "))
                    .font(.caption.weight(.medium)).foregroundStyle(.secondary)
                Text(hito.descripcion).font(.subheadline)
                Dato("Actuado por", hito.autor ?? "")
                if editable && !caso.cerrado {
                    Menu("Opciones del hito", systemImage: "ellipsis.circle") {
                        Button("Editar", systemImage: "pencil") { editarHito(hito) }
                        Button(role: .destructive) { borrarHito = hito } label: { Label("Eliminar", systemImage: "trash") }
                    }
                }
            }
        }
    }

    private var sujetos: some View {
        let s = caso.sujetos
        return Tarjeta(titulo: "Sujetos procesales", icono: "person.2", color: .indigo) {
            Dato("Fiscal provincial", s.fiscalProvincial)
            Dato("Fiscal adjunto", s.fiscalAdjunto)
            Dato("Juez de investigación preparatoria", s.juezInvestigacionPreparatoria)
            Dato("Juez de juicio oral", s.juezJuicioOral)
            Dato("Sala de primera apelación", s.juecesApelacionInstancia1.joined(separator: "\n"))
            Dato("Sala de segunda apelación", s.juecesApelacionInstancia2.joined(separator: "\n"))
            Dato("Sala de última apelación", s.juecesApelacionInstancia3.joined(separator: "\n"))
            Dato("Abogado defensor", s.abogadoDefensa)
            Dato("Perito oficial", s.peritoOficial)
            if editable || (desdeJuzgado && !caso.cerrado) {
                Accion(titulo: "Editar sujetos", icono: "square.and.pencil") { editarSujetos() }
            }
        }
    }

    private func actualizar(_ modificar: (inout CasoJusticia) -> Void) {
        archivo.actualizar(caso.id, modificar)
    }

    private func editarHechos() {
        formulario = Formulario(titulo: "Hechos del expediente", campos: [
            .largo("que", "¿Qué ocurrió?", inicial: caso.queOcurrio, requerido: false),
            .texto("cuando", "¿Cuándo?", inicial: caso.cuando, requerido: false),
            .texto("donde", "¿Dónde?", inicial: caso.donde, requerido: false),
            .largo("porque", "¿Por qué?", inicial: caso.porQue ?? "", requerido: false),
            .largo("como", "¿Cómo?", inicial: caso.como, requerido: false),
            .texto("delito", "¿Qué se imputa?", inicial: caso.delitoImputado, requerido: false),
            .largo("imputados", "Presuntos responsables · uno por línea", inicial: caso.presuntosResponsables.joined(separator: "\n"), requerido: false),
            .texto("victima", "Presunta víctima", inicial: caso.presuntaVictima, requerido: false),
            .largo("descripcion", "Descripción", inicial: caso.descripcionHechos, requerido: false)
        ]) { v in
            actualizar {
                $0.porQue = v["porque"]; $0.queOcurrio = v["que"]; $0.cuando = v["cuando"]; $0.donde = v["donde"]; $0.como = v["como"]
                $0.delitoImputado = v["delito"]; $0.presuntosResponsables = v.nombres("imputados")
                $0.presuntaVictima = v["victima"]; $0.descripcionHechos = v["descripcion"]
            }
        }
    }

    private func editarHito(_ previo: TimelineEvent? = nil) {
        formulario = Formulario(titulo: previo == nil ? "Nuevo hito" : "Editar hito", campos: [
            .texto("titulo", "Título", inicial: previo?.titulo ?? ""),
            .opciones("tipo", "Tipo", ["hecho", "diligencia", "resolucion", "audiencia", "apelacion"], inicial: previo?.tipo),
            .texto("fecha", "Fecha", inicial: previo?.fecha ?? hoy()),
            .texto("hora", "Hora", inicial: previo?.hora ?? "", requerido: false),
            .texto("autor", "Actuado por", inicial: previo?.autor ?? "", requerido: false),
            .largo("descripcion", "Descripción", inicial: previo?.descripcion ?? "")
        ]) { v in
            actualizar { c in
                let hito = TimelineEvent(id: previo?.id ?? nuevoID(), fecha: v["fecha"], hora: v["hora"], titulo: v["titulo"],
                                         descripcion: v["descripcion"], tipo: v["tipo"], autor: v["autor"])
                if let i = c.lineaTemporal.firstIndex(where: { $0.id == hito.id }) { c.lineaTemporal[i] = hito }
                else { c.lineaTemporal.append(hito) }
            }
        }
    }

    private func editarSujetos() {
        let s = caso.sujetos
        formulario = Formulario(titulo: "Sujetos procesales", campos: [
            .texto("fiscal", "Fiscal provincial", inicial: s.fiscalProvincial),
            .texto("adjunto", "Fiscal adjunto", inicial: s.fiscalAdjunto, requerido: false),
            .texto("preparatoria", "Juez de investigación preparatoria", inicial: s.juezInvestigacionPreparatoria),
            .texto("oral", "Juez de juicio oral", inicial: s.juezJuicioOral),
            .largo("sala1", "Primera apelación · un juez por línea", inicial: s.juecesApelacionInstancia1.joined(separator: "\n")),
            .largo("sala2", "Segunda apelación · un juez por línea", inicial: s.juecesApelacionInstancia2.joined(separator: "\n")),
            .largo("sala3", "Última apelación · un juez por línea", inicial: s.juecesApelacionInstancia3.joined(separator: "\n")),
            .texto("defensa", "Abogado defensor", inicial: s.abogadoDefensa, requerido: false),
            .texto("perito", "Perito oficial", inicial: s.peritoOficial, requerido: false)
        ]) { v in
            actualizar { c in
                c.sujetos = .init(fiscalProvincial: v["fiscal"], fiscalAdjunto: v["adjunto"], juezInvestigacionPreparatoria: v["preparatoria"],
                                  juezJuicioOral: v["oral"], juecesApelacionInstancia1: v.nombres("sala1"), juecesApelacionInstancia2: v.nombres("sala2"),
                                  juecesApelacionInstancia3: v.nombres("sala3"), abogadoDefensa: v["defensa"], peritoOficial: v["perito"])
            }
        }
    }

    private func icono(_ tipo: String) -> String {
        switch tipo {
        case "diligencia": "list.clipboard"
        case "resolucion": "checkmark.seal"
        case "audiencia": "person.2"
        case "apelacion": "arrow.turn.up.right"
        default: "clock"
        }
    }
}

struct ExpedienteJudicial: View {
    @EnvironmentObject private var archivo: Archivo
    let id: String
    var body: some View {
        if let caso = archivo.expedientes.first(where: { $0.id == id }) {
            Expediente(caso: caso, desdeJuzgado: true)
                .navigationTitle("Expediente judicial")
        }
    }
}

struct DetallePrueba: View {
    let prueba: PruebaElemento
    @Environment(\.dismiss) private var cerrar

    var body: some View {
        NavigationStack {
            Contenedor {
                Tarjeta(titulo: prueba.titulo, icono: "doc.text.magnifyingglass", color: .indigo) {
                    Etiqueta(texto: rotulo(prueba.tipo), color: .indigo)
                    Dato("Descripción", prueba.descripcion)
                    Dato("Origen", prueba.origen)
                    Dato("Fecha de obtención", prueba.fechaRecabada)
                    Dato("Pertinencia", prueba.pertinencia)
                    if let admitida = prueba.admitidaPJ {
                        Etiqueta(texto: admitida ? "Admitida" : "Excluida", color: admitida ? .green : .red)
                    }
                }
            }
            .navigationTitle("Ficha de prueba")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } }
            }
        }
    }
}

struct ConsultaRapida: View {
    let caso: CasoJusticia
    @Environment(\.dismiss) private var cerrar
    @State private var texto = ""
    @State private var abierta: PruebaElemento?

    private struct Entrada: Identifiable {
        let id: String
        let titulo: String
        let contenido: String
    }

    var body: some View {
        NavigationStack {
            List {
                if texto.isEmpty {
                    Section {
                        Cabecera(caso: caso, icono: "doc.text.magnifyingglass", color: .indigo)
                            .listRowInsets(EdgeInsets())
                            .listRowBackground(Color.clear)
                    }
                }

                grupo("Hechos y partes", hechos)
                grupo("Sujetos", sujetos)
                grupo("Diligencias", diligencias)
                grupo("Conductas y subcasos", conductas)
                grupo("Audiencias y alegatos", audiencias)
                grupo("Actuaciones y decisiones", actuaciones)

                let pruebas = caso.pruebasRecabadas.filter {
                    coincide([$0.titulo, $0.descripcion, $0.tipo, $0.origen, $0.pertinencia].joined(separator: " "))
                }
                if !pruebas.isEmpty {
                    Section("Pruebas") {
                        ForEach(pruebas) { prueba in
                            Button {
                                abierta = prueba
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prueba.titulo).foregroundStyle(.primary)
                                    Text(rotulo(prueba.tipo) + (prueba.origen.isEmpty ? "" : " · " + prueba.origen))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }

                if !texto.isEmpty && pruebas.isEmpty && !hayCoincidencias {
                    ContentUnavailableView.search(text: texto)
                }
            }
            .navigationTitle("Consultar expediente")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $texto, placement: .navigationBarDrawer(displayMode: .always), prompt: "Buscar en este expediente")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } }
            }
            .sheet(item: $abierta) { DetallePrueba(prueba: $0) }
        }
    }

    private var hechos: [Entrada] {
        [
            .init(id: "que", titulo: "Qué ocurrió", contenido: caso.queOcurrio),
            .init(id: "cuando", titulo: "Cuándo", contenido: caso.cuando),
            .init(id: "donde", titulo: "Dónde", contenido: caso.donde),
            .init(id: "porque", titulo: "Por qué", contenido: caso.porQue ?? ""),
            .init(id: "como", titulo: "Cómo", contenido: caso.como),
            .init(id: "delito", titulo: "Imputación", contenido: caso.delitoImputado),
            .init(id: "imputados", titulo: "Presuntos responsables", contenido: caso.presuntosResponsables.joined(separator: "\n")),
            .init(id: "victima", titulo: "Presunta víctima", contenido: caso.presuntaVictima),
            .init(id: "descripcion", titulo: "Descripción", contenido: caso.descripcionHechos)
        ]
    }

    private var sujetos: [Entrada] {
        let s = caso.sujetos
        return [
            .init(id: "fiscal", titulo: "Fiscal provincial", contenido: s.fiscalProvincial),
            .init(id: "adjunto", titulo: "Fiscal adjunto", contenido: s.fiscalAdjunto),
            .init(id: "juez", titulo: "Juez de investigación preparatoria", contenido: s.juezInvestigacionPreparatoria),
            .init(id: "juicio", titulo: "Juez de juicio oral", contenido: s.juezJuicioOral),
            .init(id: "defensa", titulo: "Defensa", contenido: s.abogadoDefensa),
            .init(id: "perito", titulo: "Perito", contenido: s.peritoOficial),
            .init(id: "sala1", titulo: "Primera sala", contenido: s.juecesApelacionInstancia1.joined(separator: "\n")),
            .init(id: "sala2", titulo: "Segunda sala", contenido: s.juecesApelacionInstancia2.joined(separator: "\n")),
            .init(id: "sala3", titulo: "Última sala", contenido: s.juecesApelacionInstancia3.joined(separator: "\n"))
        ]
    }

    private var diligencias: [Entrada] {
        (caso.diligenciasPreliminares + caso.diligenciasPreparatorias).map {
            .init(id: $0.id, titulo: $0.titulo,
                  contenido: [$0.fecha, $0.responsable, $0.detalles, $0.resultado].filter { !$0.isEmpty }.joined(separator: "\n"))
        }
    }

    private var conductas: [Entrada] {
        let imputadas = caso.conductas.map {
            Entrada(id: $0.id, titulo: $0.imputadoNombre, contenido: $0.descripcionConducta + "\n" + $0.tipificacionLegal)
        }
        let judiciales = caso.subcasos.map {
            Entrada(id: $0.id, titulo: $0.titulo,
                    contenido: [$0.conductaDescripcion, $0.tipificacionLegal, rotulo($0.estado), $0.motivacionDecision ?? ""]
                        .filter { !$0.isEmpty }.joined(separator: "\n"))
        }
        let afectaciones = (caso.afectaciones ?? []).map {
            Entrada(id: $0.id, titulo: "Afectación · " + $0.titulo, contenido: $0.desarrollo)
        }
        return imputadas + judiciales + afectaciones
    }

    private var audiencias: [Entrada] {
        var entradas: [Entrada] = caso.subcasos.flatMap { subcaso in
            subcaso.audiencias.enumerated().map { indice, audiencia in
                Entrada(id: subcaso.id + "-" + String(indice), titulo: rotulo(audiencia.tipo) + " · " + subcaso.imputadoNombre,
                        contenido: [audiencia.fecha, audiencia.alegatoFiscalia, audiencia.alegatoDefensa, audiencia.conclusionesJuez ?? ""]
                            .filter { !$0.isEmpty }.joined(separator: "\n"))
            }
        }
        for subcaso in caso.subcasos {
            for pregunta in subcaso.preguntasJudiciales ?? [] {
                let contenido = [pregunta.fiscalia, pregunta.contraparte, pregunta.evaluacion]
                    .compactMap { $0 }.joined(separator: "\n")
                entradas.append(.init(id: pregunta.id, titulo: pregunta.pregunta,
                    contenido: contenido.isEmpty ? "Pregunta judicial pendiente de respuesta" : contenido))
            }
            for diligencia in subcaso.diligenciasEspeciales ?? [] {
                entradas.append(.init(id: diligencia.id, titulo: "Diligencia especial · " + subcaso.imputadoNombre,
                    contenido: diligencia.orden + "\n" + (diligencia.resultado ?? "Pendiente")))
            }
        }
        for alegato in [caso.alegatosApertura, caso.alegatosClausura].compactMap({ $0 }) {
            entradas.append(.init(id: alegato.tipo, titulo: "Alegatos de " + alegato.tipo,
                contenido: "Fiscalía: " + alegato.fiscalia + "\nDefensa: " + alegato.defensa))
        }
        return entradas
    }

    private var actuaciones: [Entrada] {
        var entradas: [Entrada] = []
        if let acusacion = caso.acusacionFiscal {
            entradas.append(.init(id: "acusacion", titulo: "Acusación fiscal",
                contenido: acusacion.pretensionPunitiva + "\n" + soles(acusacion.reparacionCivilSolicitada) + "\n" + acusacion.fundamentosAcusacion))
        }
        if let sentencia = caso.sentencia {
            entradas.append(.init(id: "sentencia", titulo: "Sentencia · " + rotulo(sentencia.fallo), contenido: sentencia.fundamentacionJuridica))
        }
        entradas += caso.peticionesFiscales.map {
            .init(id: $0.id, titulo: $0.titulo, contenido: [rotulo($0.estado), $0.fundamentacion, $0.respuestaJuez ?? ""].joined(separator: "\n"))
        }
        entradas += caso.apelaciones.map {
            .init(id: "recurso-" + String($0.numeroApelacion), titulo: "Apelación " + String($0.numeroApelacion),
                  contenido: [$0.motivosAgravios, $0.resolucionSala ?? ""].joined(separator: "\n"))
        }
        if let constitucional = caso.recursoConstitucional {
            entradas.append(.init(id: "recurso-tc", titulo: "Tribunal Constitucional",
                contenido: [constitucional.motivosAgravios, constitucional.resolucionSala ?? ""].joined(separator: "\n")))
        }
        entradas += caso.lineaTemporal.reversed().map {
            .init(id: $0.id, titulo: $0.titulo, contenido: $0.fecha + "\n" + $0.descripcion)
        }
        return entradas
    }

    private func coincide(_ valor: String) -> Bool {
        texto.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || valor.localizedStandardContains(texto.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    private func filtrar(_ entradas: [Entrada]) -> [Entrada] {
        entradas.filter { !$0.contenido.isEmpty && coincide($0.titulo + " " + $0.contenido) }
    }

    private var hayCoincidencias: Bool {
        [hechos, sujetos, diligencias, conductas, audiencias, actuaciones].contains { !filtrar($0).isEmpty }
    }

    @ViewBuilder private func grupo(_ titulo: String, _ entradas: [Entrada]) -> some View {
        let visibles = filtrar(entradas)
        if !visibles.isEmpty {
            Section(titulo) {
                ForEach(visibles) { entrada in
                    DisclosureGroup(entrada.titulo) {
                        Text(entrada.contenido).font(.subheadline).textSelection(.enabled)
                    }
                }
            }
        }
    }
}
