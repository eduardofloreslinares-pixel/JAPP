import Combine
import SwiftUI
import UIKit
import WebKit

@MainActor
final class JusticiaPortal: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    @Published private(set) var ready = false
    @Published private(set) var selected = 0
    @Published private(set) var badges = ["", ""]
    @Published private(set) var title = ""
    let exportEvents = PassthroughSubject<Data, Never>()

    private let storageKeys = ["justicia_expediente_v1", "justicia_expedientes_v2"]
    private var snapshotURL: URL {
        URL.applicationSupportDirectory.appending(path: "Justicia/expedientes.json")
    }

    private(set) lazy var webView: WKWebView = {
        let configuration = WKWebViewConfiguration()
        configuration.setURLSchemeHandler(LocalFiles(), forURLScheme: "justicia")
        let controller = configuration.userContentController
        controller.add(WeakMessageHandler(portal: self), name: "justicia")
        installPersistence(on: controller)
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = self
        view.uiDelegate = self
        view.isOpaque = false
        view.backgroundColor = .clear
        view.scrollView.backgroundColor = .clear
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.scrollView.bounces = false
        view.load(URLRequest(url: URL(string: "justicia://local/index.html")!))
        return view
    }()

    func showTab(_ index: Int) {
        run("window.justiciaShowTab?.(\(index))")
    }

    func openCases() { run("window.justiciaOpenCases?.()") }
    func exportCase() { run("window.justiciaExportCase?.()") }

    private func run(_ script: String) {
        webView.evaluateJavaScript(script, completionHandler: nil)
    }

    private func installPersistence(on controller: WKUserContentController) {
        controller.removeAllUserScripts()
        controller.addUserScript(WKUserScript(source: persistenceScript(),
                                               injectionTime: .atDocumentStart,
                                               forMainFrameOnly: true))
    }

    private func persistenceScript() -> String {
        let data = (try? Data(contentsOf: snapshotURL)) ?? Data("{}".utf8)
        // Use base64 to embed JSON as inert text, including arbitrary accents and quotes.
        return """
        (() => {
          const keys = ['justicia_expediente_v1', 'justicia_expedientes_v2'];
          let last = '';
          let memory = {};
          let storage = null;
          try {
            const bytes = Uint8Array.from(atob('\(data.base64EncodedString())'), x => x.charCodeAt(0));
            memory = JSON.parse(new TextDecoder().decode(bytes));
          } catch {}
          try { storage = window.localStorage; storage.getItem(keys[0]); } catch {
            storage = null;
            Object.defineProperty(window, 'localStorage', { value: Object.create(Storage.prototype) });
          }
          const local = window.localStorage;
          const nativeGet = Storage.prototype.getItem;
          const nativeSet = Storage.prototype.setItem;
          const nativeRemove = Storage.prototype.removeItem;
          Storage.prototype.getItem = function(key) {
            return this === local && !storage ? memory[key] ?? null : nativeGet.call(this, key);
          };
          Storage.prototype.setItem = function(key, value) {
            if (this === local && !storage) memory[key] = String(value);
            else nativeSet.call(this, key, value);
            if (this === local && keys.includes(key)) queueMicrotask(window.justiciaPersist);
          };
          Storage.prototype.removeItem = function(key) {
            if (this === local && !storage) delete memory[key];
            else nativeRemove.call(this, key);
            if (this === local && keys.includes(key)) queueMicrotask(window.justiciaPersist);
          };
          if (storage && keys.some(key => key in memory)) for (const key of keys) {
            if (typeof memory[key] === 'string') nativeSet.call(local, key, memory[key]);
            else nativeRemove.call(local, key);
          }
          window.justiciaPersist = () => {
            const snapshot = {};
            for (const key of keys) {
              const value = local.getItem(key);
              if (value !== null) snapshot[key] = value;
            }
            const payload = JSON.stringify(snapshot);
            if (payload !== last) {
              last = payload;
              window.webkit.messageHandlers.justicia.postMessage({ kind: 'save', snapshot });
            }
          };
        })();
        """
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              let body = message.body as? [String: Any],
              let kind = body["kind"] as? String else { return }
        switch kind {
        case "navigation":
            selected = max(0, min(2, body["selected"] as? Int ?? 0))
            badges = body["badges"] as? [String] ?? []
            title = body["title"] as? String ?? ""
            ready = true
        case "save":
            guard let snapshot = body["snapshot"] as? [String: String],
                  snapshot.keys.allSatisfy(storageKeys.contains) else { return }
            do {
                try FileManager.default.createDirectory(at: snapshotURL.deletingLastPathComponent(),
                                                        withIntermediateDirectories: true)
                let data = try JSONEncoder().encode(snapshot)
                try data.write(to: snapshotURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            } catch {
                // The persistent WebKit store remains available if writing the backup fails.
                NSLog("No se pudo guardar el respaldo de Justicia: %@", error.localizedDescription)
            }
        case "reload":
            installPersistence(on: userContentController)
            webView.reload()
        case "export":
            if let content = body["content"] as? String {
                exportEvents.send(Data(content.utf8))
            }
        default: break
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let url = action.request.url
        decisionHandler(url?.scheme == "justicia" && url?.host == "local" ? .allow : .cancel)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let presenter = presenter(for: webView) else { completionHandler(); return }
        let alert = UIAlertController(title: "Justicia", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let presenter = presenter(for: webView) else { completionHandler(false); return }
        let alert = UIAlertController(title: "Justicia", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "Aceptar", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }

    private func presenter(for view: UIView) -> UIViewController? {
        var controller = view.window?.rootViewController
        while let presented = controller?.presentedViewController { controller = presented }
        return controller
    }
}

struct JusticiaWebView: UIViewRepresentable {
    let portal: JusticiaPortal
    func makeUIView(context: Context) -> WKWebView { portal.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

@MainActor
private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var portal: JusticiaPortal?
    init(portal: JusticiaPortal) { self.portal = portal }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        portal?.userContentController(userContentController, didReceive: message)
    }
}

private final class LocalFiles: NSObject, WKURLSchemeHandler {
    private let types = ["html": "text/html", "js": "text/javascript", "css": "text/css",
                         "json": "application/json", "svg": "image/svg+xml"]

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url, url.host == "local",
              let root = Bundle.main.resourceURL?.appending(path: "Web") else {
            task.didFailWithError(URLError(.badURL))
            return
        }
        let path = url.path.isEmpty || url.path == "/" ? "index.html" : String(url.path.dropFirst())
        let file = root.appending(path: path).standardizedFileURL
        guard file.path.hasPrefix(root.path + "/"),
              let mime = types[file.pathExtension],
              let data = try? Data(contentsOf: file) else {
            task.didFailWithError(URLError(.fileDoesNotExist))
            return
        }
        task.didReceive(URLResponse(url: url, mimeType: mime,
                                   expectedContentLength: data.count, textEncodingName: "utf-8"))
        task.didReceive(data)
        task.didFinish()
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {}
}
