import SwiftUI
import PhotosUI
import UIKit

struct Editor: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var cerrar
    let casoID: UUID
    let area: Area
    let accion: Accion
    let guardado: (UUID) -> Void
    @State private var titulo = ""
    @State private var texto = ""
    @State private var respuesta: Resultado?
    @State private var juicios: [UUID: String] = [:]
    @State private var votos: [Voto] = []
    @State private var referencias: Set<UUID> = []
    @State private var seleccionFoto: PhotosPickerItem?
    @State private var foto: Data?
    @State private var cargandoFoto = false
    @State private var errorFoto: String?

    var body: some View {
        if let caso = archivo.caso(casoID) {
            NavigationStack {
                Form {
                    contenido(caso)
                }
                .navigationTitle(accion.titulo(en: caso))
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { cerrar() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Registrar") { registrar(caso) }.disabled(!valido(caso))
                    }
                }
                .task(id: seleccionFoto) {
                    if let item = seleccionFoto { await cargar(item) }
                }
            }
        }
    }

    @ViewBuilder private func contenido(_ caso: Caso) -> some View {
        switch accion {
        case .hecho(let pregunta):
            Section {
                TextField("Respuesta", text: $texto, axis: .vertical).lineLimit(4...12)
            } header: { Text(pregunta.pista) }
        case .evidencia:
            Section {
                PhotosPicker(selection: $seleccionFoto, matching: .images, photoLibrary: .shared()) {
                    Label(foto == nil ? "Elegir foto" : "Cambiar foto", systemImage: "photo")
                }
                if cargandoFoto { ProgressView("Cargando foto") }
                if let errorFoto { Text(errorFoto).font(.footnote).foregroundStyle(.red) }
                if let foto, let imagen = UIImage(data: foto) {
                    Image(uiImage: imagen).resizable().scaledToFit().frame(maxHeight: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    Button("Quitar foto", role: .destructive) {
                        self.foto = nil
                        seleccionFoto = nil
                    }
                }
                TextField("Descripción", text: $texto, axis: .vertical).lineLimit(3...8)
            }
        case .evaluacionFiscal, .control, .sentencia, .revision, .falloTC:
            evaluacion(caso)
            if accion != .evaluacionFiscal {
                Votacion(personas: caso.jueces, pregunta: preguntaVoto, votos: $votos)
                TextField(accion == .sentencia ? "Parte resolutiva, pena o medidas" : "Resumen de la decisión",
                          text: $texto, axis: .vertical).lineLimit(3...8)
            }
        case .apertura, .acusacion, .objetiva:
            if accion == .objetiva {
                TextField("Pregunta de sí o no", text: $titulo)
            }
            Section {
                Picker("Respuesta", selection: $respuesta) {
                    Text("Elegir").tag(nil as Resultado?)
                    Text("Sí").tag(Optional(Resultado.si))
                    Text("No").tag(Optional(Resultado.no))
                }
                .pickerStyle(.segmented)
                TextField(accion == .objetiva ? "Comentario opcional" : "Motivo", text: $texto, axis: .vertical)
                    .lineLimit(3...8)
                if respuesta == .si, let aviso = caso.bloqueo(accion) {
                    Text(aviso).font(.footnote).foregroundStyle(.secondary)
                }
            }
            if accion == .acusacion { evidenciaVinculada(caso) }
        default:
            Section {
                if solicitaTitulo { TextField("Título", text: $titulo) }
                TextField(accion == .recurso || accion == .constitucional ? "Fundamentos del recurso" : "Descripción", text: $texto, axis: .vertical)
                    .lineLimit(4...12)
            }
            if accion == .conducta || accion == .afectacion || accion == .diligencia { evidenciaVinculada(caso) }
        }
    }

    private var solicitaTitulo: Bool {
        switch accion {
        case .conducta, .afectacion, .comunicado, .diligencia, .objetiva: true
        default: false
        }
    }

    private var evaluando: Bool {
        [.evaluacionFiscal, .control, .sentencia, .revision, .falloTC].contains(accion)
    }

    private var preguntaVoto: String {
        switch accion {
        case .control: "¿Admitir la acusación?"
        case .sentencia: "¿Dictar condena?"
        case .revision: "¿Estimar el recurso?"
        default: "¿Estimar el recurso constitucional?"
        }
    }

    private func material(_ caso: Caso) -> [Acto] {
        switch accion {
        case .evaluacionFiscal:
            return caso.hechos + caso.evidencias
        case .control:
            let acusacion = caso.actos.last { $0.tipo == .acusacion }.map { [$0] } ?? []
            return acusacion + caso.actos.filter { [.conducta, .afectacion, .evidencia].contains($0.tipo) }
        case .sentencia:
            return caso.actos.filter { ($0.tipo == .minijuicio && $0.cerrada && $0.resultado != .reprogramado) ||
                $0.tipo == .audienciaFinal || $0.tipo == .evidencia }
        default:
            return caso.actos.filter { [.recurso, .constitucional, .sentencia, .revision, .evidencia, .minijuicio, .audienciaFinal].contains($0.tipo) && $0.resultado != .empate }
        }
    }

    private func evaluacion(_ caso: Caso) -> some View {
        ForEach(material(caso)) { acto in
            Section {
                VStack(alignment: .leading, spacing: 9) {
                    ResumenActo(acto: acto, caso: caso)
                    if acto.audiencia {
                        DisclosureGroup("Leer conversación") {
                            ForEach(acto.mensajes) { mensaje in
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(mensaje.autor).font(.caption.bold()).foregroundStyle(.secondary)
                                    Text(mensaje.texto).font(.subheadline)
                                }
                                .padding(.vertical, 3)
                            }
                        }
                    }
                    TextField("Escribe la evaluación aquí", text: Binding(
                        get: { juicios[acto.id, default: ""] },
                        set: { juicios[acto.id] = $0 }
                    ), axis: .vertical)
                    .lineLimit(2...7)
                    .padding(11)
                    .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 13))
                    .accessibilityLabel("Evaluación de " + acto.rotulo)
                }
            }
        }
    }

    @ViewBuilder private func evidenciaVinculada(_ caso: Caso) -> some View {
        if !caso.evidencias.isEmpty {
            Section("Evidencias vinculadas") {
                ForEach(caso.evidencias) { acto in
                    Toggle(acto.rotulo, isOn: Binding(get: { referencias.contains(acto.id) }, set: { marcado in
                        if marcado { referencias.insert(acto.id) } else { referencias.remove(acto.id) }
                    }))
                }
            }
        }
    }

    private func valido(_ caso: Caso) -> Bool {
        guard caso.acciones(area).contains(accion), !cargandoFoto else { return false }
        if evaluando {
            let actos = material(caso)
            guard !actos.isEmpty, actos.allSatisfy({ !juicios[$0.id, default: ""].limpio.isEmpty }) else { return false }
            return accion == .evaluacionFiscal || (votos.count == caso.jueces.count && !texto.limpio.isEmpty)
        }
        if solicitaTitulo && titulo.limpio.isEmpty { return false }
        switch accion {
        case .evidencia: return foto != nil || !texto.limpio.isEmpty
        case .apertura, .acusacion:
            guard respuesta != nil, !texto.limpio.isEmpty else { return false }
            return respuesta != .si || caso.bloqueo(accion) == nil
        case .objetiva: return respuesta != nil
        default: return !texto.limpio.isEmpty
        }
    }

    private func actoNuevo(_ caso: Caso) -> Acto? {
        let tipo: TipoActo
        var pregunta: Pregunta?
        var resultado = respuesta
        var decision: String?
        var encabezado = accion.titulo(en: caso)
        switch accion {
        case .hecho(let item): tipo = .hecho; pregunta = item
        case .evidencia: tipo = .evidencia
        case .evaluacionFiscal: tipo = .evaluacionFiscal; resultado = .realizado
        case .apertura:
            tipo = .apertura
            decision = respuesta == .si ? "Se abre investigación" : "No se abre investigación"
        case .afectacion: tipo = .afectacion
        case .conducta: tipo = .conducta
        case .acusacion:
            tipo = .acusacion
            encabezado = "Acusación fiscal"
            decision = respuesta == .si ? "Acusación remitida al juez" : "Fiscalía decide no acusar"
        case .control:
            tipo = .control
            encabezado = "Control de acusación"
            resultado = mayoria(votos)
            decision = resultado == .si ? "Acusación admitida" : resultado == .no ? "Devuelta para subsanar" : "Empate · decisión pendiente"
        case .sentencia:
            tipo = .sentencia
            encabezado = "Sentencia"
            resultado = mayoria(votos)
            decision = resultado == .si ? "Condenatoria" : resultado == .no ? "Absolutoria" : "Empate · sin sentencia"
        case .recurso: tipo = .recurso; encabezado = "Apelación \(caso.apelaciones + 1)"
        case .revision:
            tipo = .revision
            encabezado = "Fallo de apelación \(caso.apelaciones)"
            resultado = mayoria(votos)
            decision = resultado == .si ? "Recurso estimado" : resultado == .no ? "Recurso desestimado" : "Empate · sin fallo"
        case .constitucional: tipo = .constitucional
        case .falloTC:
            tipo = .falloTC
            encabezado = "Fallo constitucional"
            resultado = mayoria(votos)
            decision = resultado == .si ? "Recurso estimado" : resultado == .no ? "Recurso desestimado" : "Empate · sin fallo"
        case .comunicado: tipo = .comunicado
        case .objetiva: tipo = .objetiva; decision = respuesta?.titulo
        case .diligencia: tipo = .diligencia
        case .cierre: tipo = .cierre; decision = "Expediente cerrado"
        case .minijuicio, .audienciaFinal: return nil
        }
        let evaluaciones: [Evaluacion] = evaluando ? material(caso).map {
            Evaluacion(id: $0.id, titulo: $0.rotulo, texto: juicios[$0.id, default: ""].limpio)
        } : []
        let contenido = accion == .evaluacionFiscal ? "Evaluadas \(evaluaciones.count) actuaciones." : texto.limpio
        return Acto(area: area, tipo: tipo, titulo: solicitaTitulo ? titulo.limpio : encabezado, texto: contenido,
                    pregunta: pregunta, resultado: resultado, decision: decision, referencias: Array(referencias),
                    evaluaciones: evaluaciones, votos: votos, foto: foto)
    }

    private func registrar(_ caso: Caso) {
        guard valido(caso), let acto = actoNuevo(caso) else { return }
        var id: UUID?
        if archivo.editar(casoID, { id = $0.aplicar(accion, acto: acto) }), let id { guardado(id) }
    }

    @MainActor private func cargar(_ item: PhotosPickerItem) async {
        cargandoFoto = true
        errorFoto = nil
        defer { if seleccionFoto == item { cargandoFoto = false } }
        do {
            guard let data = try await item.loadTransferable(type: Data.self), let imagen = UIImage(data: data) else {
                throw CocoaError(.fileReadCorruptFile)
            }
            guard !Task.isCancelled, seleccionFoto == item else { return }
            let maximo = max(imagen.size.width, imagen.size.height)
            guard maximo > 0 else { throw CocoaError(.fileReadCorruptFile) }
            let escala = min(1, 1500 / maximo)
            let lado = CGSize(width: max(1, imagen.size.width * escala), height: max(1, imagen.size.height * escala))
            let formato = UIGraphicsImageRendererFormat()
            formato.scale = 1
            let reducida = UIGraphicsImageRenderer(size: lado, format: formato).image { _ in
                imagen.draw(in: CGRect(origin: .zero, size: lado))
            }
            foto = reducida.jpegData(compressionQuality: 0.83)
            if foto == nil { errorFoto = "No se pudo preparar la foto." }
        } catch {
            if !Task.isCancelled { errorFoto = "No se pudo abrir la foto. Puedes volver a seleccionarla." }
        }
    }
}

struct Votacion: View {
    let personas: [Persona]
    let pregunta: String
    @Binding var votos: [Voto]
    @State private var posturas: [UUID: Bool] = [:]
    @State private var razones: [UUID: String] = [:]

    var body: some View {
        Section {
            ForEach(personas) { juez in
                VStack(alignment: .leading, spacing: 8) {
                    Text(juez.nombre).font(.headline)
                    Picker("Voto de " + juez.nombre, selection: Binding(
                        get: { posturas[juez.id] },
                        set: { posturas[juez.id] = $0; actualizar() }
                    )) {
                        Text("Elegir").tag(nil as Bool?)
                        Text("Sí").tag(Optional(true))
                        Text("No").tag(Optional(false))
                    }
                    .pickerStyle(.segmented)
                    TextField("Fundamento de " + juez.nombre, text: Binding(
                        get: { razones[juez.id, default: ""] },
                        set: { razones[juez.id] = $0; actualizar() }
                    ), axis: .vertical)
                    .lineLimit(2...6)
                }
                .padding(.vertical, 4)
            }
            if votos.count == personas.count, let resultado = mayoria(votos) {
                Text(resultado == .empate ? "Empate" : "Mayoría: " + resultado.titulo)
                    .font(.subheadline.weight(.semibold)).foregroundStyle(Oro.resultado(resultado) ?? .primary)
            }
        } header: { Text(pregunta) }
    }

    private func actualizar() {
        votos = personas.compactMap { persona in
            let fundamento = razones[persona.id, default: ""].limpio
            guard let voto = posturas[persona.id], !fundamento.isEmpty else { return nil }
            return Voto(id: persona.id, juez: persona.nombre, aFavor: voto, fundamento: fundamento)
        }
    }
}

struct ResumenVotos: View {
    let votos: [Voto]
    let resultado: Resultado?
    var compacto = false

    var body: some View {
        if let resultado, resultado == .si || resultado == .no || resultado == .empate {
            let favor = votos.filter { $0.aFavor }
            let contra = votos.filter { !$0.aFavor }
            if resultado == .empate {
                grupo("A favor", favor, color: .green)
                grupo("En contra", contra, color: .red)
            } else if resultado == .si {
                grupo("Mayoría · Sí", favor, color: .green)
                grupo("Minoría · No", contra, color: .red)
            } else {
                grupo("Mayoría · No", contra, color: .red)
                grupo("Minoría · Sí", favor, color: .green)
            }
        }
    }

    @ViewBuilder private func grupo(_ titulo: String, _ grupo: [Voto], color: Color) -> some View {
        if !grupo.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text(titulo + " · " + String(grupo.count)).font(.caption.bold())
                ForEach(grupo) { voto in
                    Text(voto.juez + ": " + voto.fundamento)
                        .font(.caption)
                        .lineLimit(compacto ? 2 : nil)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(8)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 11))
        }
    }
}

struct ActoDetalle: View {
    @Environment(\.dismiss) private var cerrar
    let caso: Caso
    let acto: Acto
    var modal = true

    var body: some View {
        if modal { NavigationStack { contenido } }
        else { contenido }
    }

    private var contenido: some View {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Actuación \(acto.codigo) · \(acto.sello)")
                        .font(.caption).foregroundStyle(.secondary)
                    if let decision = acto.decision {
                        Text(decision).font(.title3.bold())
                    }
                    if let data = acto.foto, let imagen = UIImage(data: data) {
                        Image(uiImage: imagen).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    if !acto.texto.isEmpty { Text(acto.texto).textSelection(.enabled) }
                    ResumenVotos(votos: acto.votos, resultado: acto.resultado)
                    if !acto.mensajes.isEmpty {
                        DisclosureGroup("Conversación") {
                            ForEach(acto.mensajes) { mensaje in
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(mensaje.autor + " · " + mensaje.rol.titulo).font(.caption.bold())
                                    Text(mensaje.texto).font(.subheadline).textSelection(.enabled)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, 5)
                            }
                        }
                    }
                    ForEach(acto.evaluaciones) { evaluacion in
                        VStack(alignment: .leading, spacing: 7) {
                            Text(evaluacion.titulo).font(.headline)
                            if let fuente = caso.acto(evaluacion.id), !fuente.texto.isEmpty {
                                Text(fuente.texto).font(.footnote).foregroundStyle(.secondary)
                            }
                            Text(evaluacion.texto).textSelection(.enabled)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 13))
                    }
                    ForEach(acto.referencias, id: \.self) { id in
                        if let relacionado = caso.acto(id) {
                            NavigationLink(relacionado.rotulo) {
                                ActoDetalle(caso: caso, acto: relacionado, modal: false)
                            }
                        }
                    }
                }
                .padding(19)
                .frame(maxWidth: 670)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .navigationTitle(acto.rotulo)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if modal { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } } }
            }
    }
}
