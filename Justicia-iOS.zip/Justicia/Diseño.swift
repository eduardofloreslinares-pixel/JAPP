import SwiftUI

struct Campo: Identifiable {
    enum Estilo { case texto, largo, opciones([String]), decimal }
    let id: String
    let titulo: String
    let inicial: String
    let requerido: Bool
    let estilo: Estilo

    static func texto(_ id: String, _ titulo: String, inicial: String = "", requerido: Bool = true) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: requerido, estilo: .texto)
    }
    static func largo(_ id: String, _ titulo: String, inicial: String = "", requerido: Bool = true) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: requerido, estilo: .largo)
    }
    static func opciones(_ id: String, _ titulo: String, _ opciones: [String], inicial: String? = nil) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial ?? opciones.first ?? "", requerido: true, estilo: .opciones(opciones))
    }
    static func decimal(_ id: String, _ titulo: String, inicial: String = "0") -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: true, estilo: .decimal)
    }
}

struct Valores {
    var textos: [String: String]
    var pruebas: Set<String>
    subscript(_ id: String) -> String { textos[id, default: ""].trimmingCharacters(in: .whitespacesAndNewlines) }
    func numero(_ id: String) -> Double? {
        guard let valor = Double(self[id].replacingOccurrences(of: ",", with: ".")), valor.isFinite, valor >= 0 else { return nil }
        return valor
    }
    func nombres(_ id: String) -> [String] {
        self[id].split(whereSeparator: { $0.isNewline || $0 == "," })
            .map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    }
}

struct Formulario: Identifiable {
    let id = UUID()
    let titulo: String
    var accion = "Guardar"
    var campos: [Campo]
    var pruebas: [PruebaElemento] = []
    var seleccion: Set<String> = []
    let guardar: (Valores) -> Void
}

struct Editor: View {
    @Environment(\.dismiss) private var cerrar
    let formulario: Formulario
    let caso: CasoJusticia?
    @State private var valores: Valores
    @State private var consulta = false

    init(formulario: Formulario, caso: CasoJusticia? = nil) {
        self.formulario = formulario
        self.caso = caso
        _valores = State(initialValue: Valores(textos: Dictionary(uniqueKeysWithValues: formulario.campos.map { ($0.id, $0.inicial) }), pruebas: formulario.seleccion))
    }

    private var valido: Bool {
        formulario.campos.allSatisfy { campo in
            if case .decimal = campo.estilo { return valores.numero(campo.id) != nil }
            return !campo.requerido || !valores[campo.id].isEmpty
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                ForEach(formulario.campos) { campo in
                    fila(campo)
                }
                if !formulario.pruebas.isEmpty {
                    Section("Pruebas asociadas") {
                        ForEach(formulario.pruebas) { prueba in
                            Toggle(prueba.titulo, isOn: Binding(
                                get: { valores.pruebas.contains(prueba.id) },
                                set: { if $0 { valores.pruebas.insert(prueba.id) } else { valores.pruebas.remove(prueba.id) } }
                            ))
                        }
                    }
                }
            }
            .navigationTitle(formulario.titulo)
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $consulta) {
                if let caso { ConsultaRapida(caso: caso) }
            }
            .toolbar {
                if caso != nil {
                    ToolbarItem(placement: .bottomBar) {
                        Button("Consultar expediente", systemImage: "doc.text.magnifyingglass") { consulta = true }
                    }
                }
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { cerrar() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(formulario.accion) {
                        formulario.guardar(valores)
                        cerrar()
                    }
                    .disabled(!valido)
                }
            }
        }
    }

    @ViewBuilder private func fila(_ campo: Campo) -> some View {
        let binding = Binding(get: { valores.textos[campo.id, default: ""] }, set: { valores.textos[campo.id] = $0 })
        switch campo.estilo {
        case .opciones(let opciones):
            Picker(campo.titulo, selection: binding) {
                ForEach(opciones, id: \.self) { Text(rotulo($0)).tag($0) }
            }
        case .largo:
            Section(campo.titulo) {
                TextField(campo.titulo, text: binding, axis: .vertical).lineLimit(3...10)
            }
        case .texto, .decimal:
            VStack(alignment: .leading, spacing: 5) {
                Text(campo.titulo).font(.caption).foregroundStyle(.secondary)
                if case .decimal = campo.estilo {
                    TextField(campo.titulo, text: binding).keyboardType(.decimalPad)
                } else {
                    TextField(campo.titulo, text: binding)
                }
            }
        }
    }
}

struct Tarjeta<Contenido: View>: View {
    var titulo: String
    var icono: String
    var color: Color = .accentColor
    @ViewBuilder var contenido: Contenido

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            Label { Text(titulo) } icon: { Image(systemName: icono).foregroundStyle(color) }
                .font(.headline)
                .foregroundStyle(.primary)
                .accessibilityAddTraits(.isHeader)
            contenido
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }
}

struct Dato: View {
    let titulo: String
    let valor: String
    init(_ titulo: String, _ valor: String) { self.titulo = titulo; self.valor = valor }

    var body: some View {
        if !valor.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text(titulo).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Text(valor).font(.subheadline).textSelection(.enabled)
            }
        }
    }
}

struct Accion: View {
    let titulo: String
    let icono: String
    var principal = false
    var accion: () -> Void
    var body: some View {
        if principal {
            Button(titulo, systemImage: icono, action: accion)
                .buttonStyle(.glassProminent)
        } else {
            Button(titulo, systemImage: icono, action: accion)
                .buttonStyle(.glass)
        }
    }
}

struct Cabecera: View {
    let caso: CasoJusticia
    let icono: String
    let color: Color
    var persona = ""
    @Environment(\.colorScheme) private var apariencia

    private var titulo: String {
        caso.delitoImputado.isEmpty ? "Expediente penal" : caso.delitoImputado
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(caso.numeroExpediente).font(.caption2.monospaced().weight(.semibold))
                    Etiqueta(texto: caso.devuelto ? "Acusación devuelta" : caso.etapa.titulo,
                             color: caso.devuelto ? .orange : color)
                }
                Spacer(minLength: 8)
                Image(systemName: icono)
                    .font(.system(size: 26, weight: .medium))
                    .foregroundStyle(color)
                    .frame(width: 49, height: 49)
                    .background(color.opacity(0.15), in: RoundedRectangle(cornerRadius: 16))
                    .accessibilityHidden(true)
            }
            Text(titulo)
                .font(.title2.weight(.bold))
                .fontDesign(.serif)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            if !persona.isEmpty { Text(persona).font(.footnote).foregroundStyle(.secondary) }
            RutaProcesal(etapa: caso.etapa, color: color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(17)
        .background {
            RoundedRectangle(cornerRadius: 25).fill(
                LinearGradient(colors: [color.opacity(apariencia == .dark ? 0.26 : 0.15),
                                        Color(uiColor: .secondarySystemGroupedBackground)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
            )
        }
        .overlay {
            RoundedRectangle(cornerRadius: 25).strokeBorder(color.opacity(0.22), lineWidth: 1)
        }
    }
}

struct RutaProcesal: View {
    let etapa: Etapa
    let color: Color

    var body: some View {
        let etapas: [Etapa] = [.preliminar, .preparatoria, .control, .intermedia, .juicio, .sentencia, .resuelto]
        let avance = etapas.firstIndex(of: etapa) ?? 0
        HStack(spacing: 4) {
            ForEach(etapas.indices, id: \.self) { indice in
                Capsule()
                    .fill(indice <= avance ? color.opacity(indice == avance ? 1 : 0.5) : Color.secondary.opacity(0.2))
                    .frame(height: 4)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Etapa \(avance + 1) de \(etapas.count): \(etapa.titulo)")
    }
}

struct Etiqueta: View {
    let texto: String
    let color: Color
    var body: some View {
        Text(texto)
            .font(.caption2.weight(.bold))
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .foregroundStyle(.primary)
            .background(color.opacity(0.18), in: Capsule())
    }
}

struct SeccionVisual: Identifiable {
    let id: Int
    let titulo: String
    let icono: String
    var valor: String? = nil
}

struct Accesos: View {
    let nombre: String
    let destinos: [SeccionVisual]
    @Binding var seleccion: Int
    let color: Color

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 135), spacing: 8)], spacing: 8) {
            ForEach(destinos) { destino in
                let activo = destino.id == seleccion
                Button {
                    seleccion = destino.id
                } label: {
                    HStack(spacing: 7) {
                        Image(systemName: destino.icono).foregroundStyle(color)
                        Text(destino.titulo).font(.footnote.weight(activo ? .bold : .medium))
                            .fixedSize(horizontal: false, vertical: true)
                        Spacer(minLength: 0)
                        if let valor = destino.valor {
                            Text(valor).font(.caption.monospacedDigit().weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .frame(minHeight: 44)
                    .background(activo ? color.opacity(0.17) : Color(uiColor: .secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 13))
                    .overlay { RoundedRectangle(cornerRadius: 13).strokeBorder(activo ? color.opacity(0.45) : .clear) }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(activo ? .isSelected : [])
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel(nombre)
    }
}

struct BarraActuacion<Contenido: View>: View {
    @ViewBuilder var contenido: Contenido
    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { contenido }.fixedSize(horizontal: true, vertical: false)
            VStack(alignment: .leading, spacing: 7) { contenido }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(.regularMaterial)
    }
}

struct ParAlegatos: View {
    let fiscalia: String
    let defensa: String
    @Environment(\.horizontalSizeClass) private var ancho
    var body: some View {
        let layout = ancho == .regular ? AnyLayout(HStackLayout(alignment: .top, spacing: 8)) : AnyLayout(VStackLayout(alignment: .leading, spacing: 7))
        layout {
            postura("Fiscalía", fiscalia, color: .pink)
            postura("Defensa", defensa, color: .blue)
        }
    }

    private func postura(_ titulo: String, _ texto: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Etiqueta(texto: titulo, color: color)
            Text(texto.isEmpty ? "Sin alegato registrado" : texto)
                .font(.subheadline).textSelection(.enabled)
                .foregroundStyle(texto.isEmpty ? Color.secondary : Color.primary)
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct Contenedor<Contenido: View>: View {
    @ViewBuilder var contenido: Contenido
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) { contenido }
                .frame(maxWidth: 720)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .scrollDismissesKeyboard(.interactively)
    }
}
