import SwiftUI

struct Campo: Identifiable {
    enum Estilo { case texto, largo, opciones([String]), decimal }
    let id: String
    let titulo: String
    let inicial: String
    let requerido: Bool
    let estilo: Estilo

    static func texto(_ id: String, _ titulo: String, inicial: String = "", requerido: Bool = true) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: requerido, estilo: .texto)
    }
    static func largo(_ id: String, _ titulo: String, inicial: String = "", requerido: Bool = true) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: requerido, estilo: .largo)
    }
    static func opciones(_ id: String, _ titulo: String, _ opciones: [String], inicial: String? = nil) -> Self {
        .init(id: id, titulo: titulo, inicial: inicial ?? opciones.first ?? "", requerido: true, estilo: .opciones(opciones))
    }
    static func decimal(_ id: String, _ titulo: String, inicial: String = "0") -> Self {
        .init(id: id, titulo: titulo, inicial: inicial, requerido: true, estilo: .decimal)
    }
}

struct Valores {
    var textos: [String: String]
    var pruebas: Set<String>
    subscript(_ id: String) -> String { textos[id, default: ""].trimmingCharacters(in: .whitespacesAndNewlines) }
    func numero(_ id: String) -> Double? {
        guard let valor = Double(self[id].replacingOccurrences(of: ",", with: ".")), valor.isFinite, valor >= 0 else { return nil }
        return valor
    }
    func nombres(_ id: String) -> [String] {
        self[id].split(whereSeparator: { $0.isNewline || $0 == "," })
            .map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    }
}

struct Formulario: Identifiable {
    let id = UUID()
    let titulo: String
    var accion = "Guardar"
    var campos: [Campo]
    var pruebas: [PruebaElemento] = []
    var seleccion: Set<String> = []
    let guardar: (Valores) -> Void
}

struct Editor: View {
    @Environment(\.dismiss) private var cerrar
    let formulario: Formulario
    @State private var valores: Valores

    init(formulario: Formulario) {
        self.formulario = formulario
        _valores = State(initialValue: Valores(textos: Dictionary(uniqueKeysWithValues: formulario.campos.map { ($0.id, $0.inicial) }), pruebas: formulario.seleccion))
    }

    private var valido: Bool {
        formulario.campos.allSatisfy { campo in
            if case .decimal = campo.estilo { return valores.numero(campo.id) != nil }
            return !campo.requerido || !valores[campo.id].isEmpty
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                ForEach(formulario.campos) { campo in
                    fila(campo)
                }
                if !formulario.pruebas.isEmpty {
                    Section("Pruebas asociadas") {
                        ForEach(formulario.pruebas) { prueba in
                            Toggle(prueba.titulo, isOn: Binding(
                                get: { valores.pruebas.contains(prueba.id) },
                                set: { if $0 { valores.pruebas.insert(prueba.id) } else { valores.pruebas.remove(prueba.id) } }
                            ))
                        }
                    }
                }
            }
            .navigationTitle(formulario.titulo)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { cerrar() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(formulario.accion) {
                        formulario.guardar(valores)
                        cerrar()
                    }
                    .disabled(!valido)
                }
            }
        }
    }

    @ViewBuilder private func fila(_ campo: Campo) -> some View {
        let binding = Binding(get: { valores.textos[campo.id, default: ""] }, set: { valores.textos[campo.id] = $0 })
        switch campo.estilo {
        case .opciones(let opciones):
            Picker(campo.titulo, selection: binding) {
                ForEach(opciones, id: \.self) { Text(rotulo($0)).tag($0) }
            }
        case .largo:
            Section(campo.titulo) {
                TextField(campo.titulo, text: binding, axis: .vertical).lineLimit(3...10)
            }
        case .texto, .decimal:
            VStack(alignment: .leading, spacing: 5) {
                Text(campo.titulo).font(.caption).foregroundStyle(.secondary)
                if case .decimal = campo.estilo {
                    TextField(campo.titulo, text: binding).keyboardType(.decimalPad)
                } else {
                    TextField(campo.titulo, text: binding)
                }
            }
        }
    }
}

struct Tarjeta<Contenido: View>: View {
    var titulo: String
    var icono: String
    var color: Color = .accentColor
    @ViewBuilder var contenido: Contenido

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            Label(titulo, systemImage: icono)
                .font(.headline)
                .foregroundStyle(color)
                .accessibilityAddTraits(.isHeader)
            contenido
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(17)
        .background(.background, in: RoundedRectangle(cornerRadius: 23))
    }
}

struct Dato: View {
    let titulo: String
    let valor: String
    init(_ titulo: String, _ valor: String) { self.titulo = titulo; self.valor = valor }

    var body: some View {
        if !valor.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text(titulo).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Text(valor).font(.subheadline).textSelection(.enabled)
            }
        }
    }
}

struct Accion: View {
    let titulo: String
    let icono: String
    var principal = false
    var accion: () -> Void
    var body: some View {
        if principal {
            Button(titulo, systemImage: icono, action: accion)
                .buttonStyle(.glassProminent)
        } else {
            Button(titulo, systemImage: icono, action: accion)
                .buttonStyle(.glass)
        }
    }
}

struct Cabecera: View {
    let caso: CasoJusticia
    let icono: String
    let color: Color
    var persona = ""

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: icono)
                .font(.title2.weight(.medium))
                .foregroundStyle(color)
                .frame(width: 48, height: 48)
                .glassEffect(.regular.tint(color.opacity(0.2)), in: .rect(cornerRadius: 15))
            VStack(alignment: .leading, spacing: 5) {
                Text(caso.etapa.titulo).font(.title3.bold())
                Text(caso.numeroExpediente).font(.subheadline.monospaced())
                if !persona.isEmpty { Text(persona).font(.caption).foregroundStyle(.secondary) }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 5)
    }
}

struct Contenedor<Contenido: View>: View {
    @ViewBuilder var contenido: Contenido
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) { contenido }
                .frame(maxWidth: 720)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .scrollDismissesKeyboard(.interactively)
    }
}
