import SwiftUI

struct Judicial: View {
    @EnvironmentObject private var archivo: Archivo
    let caso: CasoJusticia
    let navegar: (Pestaña) -> Void
    @State private var formulario: Formulario?
    @State private var seccion = 0

    var body: some View {
        Contenedor {
            Cabecera(caso: caso, icono: "building.columns.fill", color: .orange,
                     persona: caso.etapa == .juicio || caso.etapa == .sentencia ? caso.juezOral : caso.juezIntermedio)
            if caso.acusacionFiscal == nil {
                Tarjeta(titulo: "A la espera de la acusación", icono: "clock", color: .orange) {
                    Text("El control judicial se habilita al remitirse la acusación fiscal.").font(.subheadline)
                    Accion(titulo: "Ir a Fiscalía", icono: "arrow.left") { navegar(.fiscalia) }
                }
            } else {
                Picker("Sección judicial", selection: $seccion) {
                    Text("Actuación").tag(0)
                    Text("Subcasos").tag(1)
                    Text("Peticiones").tag(2)
                    Text("Recursos").tag(3)
                }
                .pickerStyle(.segmented)
                NavigationLink {
                    ExpedienteJudicial(id: caso.id)
                } label: {
                    Label("Consultar expediente", systemImage: "doc.text")
                }
                .buttonStyle(.glass)
                switch seccion {
                case 1: subcasos
                case 2: peticiones
                case 3: recursos
                default: actuacion
                }
            }
        }
        .sheet(item: $formulario) { Editor(formulario: $0).tint(.orange) }
    }

    @ViewBuilder private var actuacion: some View {
        if caso.cerrado {
            Tarjeta(titulo: "Expediente cerrado", icono: "lock.circle.fill", color: .orange) {
                Dato("Fecha de cierre", caso.fechaCierreDefinitivo ?? "")
                Text("Las actuaciones quedan disponibles para consulta.").font(.subheadline)
            }
        }
        switch caso.etapa {
        case .control: control
        case .intermedia: subcasos
        case .juicio: juicio
        case .sentencia: sentencia; recursos
        case .resuelto: sentencia; recursos
        default: EmptyView()
        }
        if caso.etapa != .control && caso.acusacionFiscal != nil { control }
    }

    private var control: some View {
        Tarjeta(titulo: "Control de acusación", icono: "checkmark.seal", color: .orange) {
            if let acusacion = caso.acusacionFiscal {
                Dato("Fiscal · " + acusacion.fecha, acusacion.fiscalEmisor)
                Dato("Pretensión punitiva", acusacion.pretensionPunitiva)
                Dato("Reparación civil", soles(acusacion.reparacionCivilSolicitada))
                Dato("Fundamentación", acusacion.fundamentosAcusacion)
                ForEach(caso.conductas) { conducta in
                    DisclosureGroup(conducta.imputadoNombre) {
                        Dato("Conducta imputada", conducta.descripcionConducta)
                        Dato("Tipificación", conducta.tipificacionLegal)
                    }
                }
            }
            if let revision = caso.evaluacionAcusacionPJ, revision.decision != "pendiente" {
                Dato(revision.decision == "devolver" ? "Devuelto a Fiscalía" : "Acusación admitida",
                     revision.motivoDevolucion ?? revision.fundamentacionAceptacion ?? "")
            }
            if caso.etapa == .control && !caso.devuelto && !caso.cerrado {
                Accion(titulo: "Admitir acusación", icono: "checkmark", principal: true) { revisarAcusacion(admitir: true) }
                    .disabled(caso.conductas.isEmpty)
                Accion(titulo: "Devolver a Fiscalía", icono: "arrow.uturn.backward") { revisarAcusacion(admitir: false) }
            }
            Accion(titulo: "Ver expediente", icono: "doc.text") { navegar(.expediente) }
        }
    }

    @ViewBuilder private var subcasos: some View {
        if caso.subcasos.isEmpty {
            Tarjeta(titulo: "Subcasos", icono: "square.stack", color: .orange) {
                Text("Se generan a partir de las conductas cuando se admite la acusación.").font(.subheadline)
            }
        }
        ForEach(caso.subcasos) { item in
            Tarjeta(titulo: item.titulo, icono: "person.text.rectangle", color: .orange) {
                Text(rotulo(item.estado)).font(.caption.weight(.semibold)).foregroundStyle(.orange)
                Dato("Conducta", item.conductaDescripcion)
                Dato("Tipificación", item.tipificacionLegal)
                if !item.pruebasAsignadas.isEmpty {
                    DisclosureGroup("Pruebas · \(item.pruebasAsignadas.count)") {
                        ForEach(item.pruebasAsignadas) { PruebaFila(prueba: $0) }
                    }
                }
                let otrasPruebas = caso.pruebasRecabadas.filter { prueba in
                    !item.pruebasAsignadas.contains { $0.id == prueba.id }
                }
                if !otrasPruebas.isEmpty {
                    DisclosureGroup("Otras pruebas del expediente") {
                        ForEach(otrasPruebas) { PruebaFila(prueba: $0) }
                    }
                }
                if !item.audiencias.isEmpty {
                    DisclosureGroup("Audiencias · \(item.audiencias.count)") {
                        ForEach(Array(item.audiencias.enumerated()), id: \.offset) { fila in
                            DisclosureGroup(rotulo(fila.element.tipo) + " · " + fila.element.fecha) {
                                Dato("Fiscalía", fila.element.alegatoFiscalia)
                                Dato("Defensa", fila.element.alegatoDefensa)
                                Dato("Conclusiones", fila.element.conclusionesJuez ?? "")
                            }
                        }
                    }
                }
                Dato("Motivación de la resolución", item.motivacionDecision ?? "")
                Dato("Magistratura", item.juezResolutor ?? "")
                if caso.etapa == .intermedia && item.estado == "pendiente" && !caso.cerrado {
                    Accion(titulo: "Registrar audiencia", icono: "calendar.badge.plus") { audiencia(item) }
                    Accion(titulo: "Valorar pruebas", icono: "checklist") { valorar(item) }
                        .disabled(caso.pruebasRecabadas.isEmpty)
                    Accion(titulo: "Resolver subcaso", icono: "checkmark.seal", principal: true) { resolver(item) }
                        .disabled(item.audiencias.count <= (item.audienciasAntesDeRevision ?? 0))
                }
            }
        }
        if caso.etapa == .intermedia && !caso.cerrado {
            let pendientes = caso.subcasos.filter { $0.estado == "pendiente" }.count
            Tarjeta(titulo: "Paso a juicio oral", icono: "arrow.right.circle", color: .orange) {
                Text(pendientes == 0 ? "Se han resuelto los subcasos." : "\(pendientes) subcasos pendientes.").font(.subheadline)
                Accion(titulo: "Abrir juicio oral", icono: "arrow.right", principal: true) {
                    actualizar { c in
                        c.etapa = .juicio
                        c.registrar("Juicio oral instalado", "Concluyó la etapa intermedia.", tipo: "audiencia", autor: c.juezOral)
                    }
                    seccion = 0
                }
                .disabled(pendientes > 0 || caso.subcasos.isEmpty)
            }
        }
    }

    private var juicio: some View {
        Tarjeta(titulo: "Juicio oral", icono: "quote.bubble", color: .orange) {
            Dato("Magistratura", caso.juezOral)
            Dato("Decisiones de la etapa intermedia", caso.subcasos.map { "\($0.imputadoNombre) · \(rotulo($0.estado))" }.joined(separator: "\n"))
            if let apertura = caso.alegatosApertura {
                Dato("Apertura · Fiscalía", apertura.fiscalia)
                Dato("Apertura · Defensa", apertura.defensa)
            }
            if let clausura = caso.alegatosClausura {
                Dato("Clausura · Fiscalía", clausura.fiscalia)
                Dato("Clausura · Defensa", clausura.defensa)
            }
            Dato("Evaluación judicial", caso.evaluacionAlegatosJuez ?? "")
            Accion(titulo: "Alegatos de apertura", icono: "mic") { alegatos(apertura: true) }
            Accion(titulo: "Alegatos de clausura", icono: "mic") { alegatos(apertura: false) }
            Accion(titulo: "Evaluar alegatos", icono: "checklist") { evaluarAlegatos() }
            Accion(titulo: "Dictar sentencia", icono: "checkmark.seal", principal: true) { dictar() }
                .disabled(caso.alegatosApertura == nil || caso.alegatosClausura == nil || (caso.evaluacionAlegatosJuez ?? "").isEmpty)
        }
    }

    @ViewBuilder private var sentencia: some View {
        if let fallo = caso.sentencia {
            Tarjeta(titulo: "Sentencia \(rotulo(fallo.fallo).lowercased())", icono: "doc.badge.checkmark", color: .orange) {
                Dato(fallo.fecha, fallo.juezSentenciador)
                ForEach(Array(fallo.penasImputados.enumerated()), id: \.offset) { fila in
                    let pena = fila.element
                    Dato(pena.imputadoNombre, pena.ponencia)
                }
                Dato("Reparación civil", soles(fallo.reparacionCivilMonto))
                Dato("Beneficiario", fallo.reparacionCivilBeneficiario)
                Dato("Fundamentación", fallo.fundamentacionJuridica)
                Dato("Evaluación de los alegatos", caso.evaluacionAlegatosJuez ?? "")
                ForEach(Array((caso.sentenciasAnteriores ?? []).enumerated()), id: \.offset) { fila in
                    let anterior = fila.element
                    DisclosureGroup("Sentencia anterior · " + anterior.fecha) {
                        Dato(rotulo(anterior.fallo), anterior.juezSentenciador)
                        Dato("Fundamentación", anterior.fundamentacionJuridica)
                        Dato("Reparación civil", soles(anterior.reparacionCivilMonto))
                    }
                }
            }
        }
    }

    private var recursos: some View {
        Tarjeta(titulo: "Apelaciones", icono: "arrow.turn.up.right", color: .orange) {
            if caso.apelaciones.isEmpty { Text("No hay apelaciones registradas.").foregroundStyle(.secondary) }
            ForEach(Array(caso.apelaciones.enumerated()), id: \.offset) { fila in
                let recurso = fila.element
                DisclosureGroup("Apelación \(recurso.numeroApelacion) · \(rotulo(recurso.estado))") {
                    Dato(rotulo(recurso.quienApela) + " · " + recurso.fechaInterposicion, recurso.motivosAgravios)
                    Dato("Sala revisora", recurso.juecesSalaApelaciones.joined(separator: "\n"))
                    Dato("Admisibilidad", recurso.admisibilidadUltima.map(rotulo) ?? "")
                    Dato("Resolución", recurso.resolucionSala ?? "")
                    Dato("Fallo", recurso.falloApelacion.map(rotulo) ?? "")
                }
            }
            if caso.etapa == .sentencia && !caso.cerrado {
                if caso.apelaciones.last?.admisibilidadUltima == "pendiente" {
                    Accion(titulo: "Resolver admisibilidad", icono: "checkmark.seal", principal: true) { admisibilidad() }
                } else if caso.numeroApelaciones < 3 {
                    let titulos = ["Apelar", "Segunda apelación", "Última apelación"]
                    Accion(titulo: titulos[caso.numeroApelaciones], icono: "arrow.turn.up.right", principal: true) { apelar() }
                } else {
                    Accion(titulo: "Declarar cierre definitivo", icono: "lock", principal: true) { cerrarCaso() }
                }
            }
        }
    }

    private var peticiones: some View {
        Tarjeta(titulo: "Peticiones fiscales", icono: "tray.full", color: .orange) {
            if caso.peticionesFiscales.isEmpty { Text("No hay peticiones registradas.").foregroundStyle(.secondary) }
            ForEach(caso.peticionesFiscales) { peticion in
                PeticionFila(peticion: peticion)
                if peticion.estado == "pendiente" && !caso.cerrado && !caso.devuelto {
                    Accion(titulo: "Resolver «\(peticion.titulo)»", icono: "checkmark.seal") { resolverPeticion(peticion) }
                }
            }
        }
    }

    private func actualizar(_ modificar: (inout CasoJusticia) -> Void) {
        archivo.actualizar(caso.id, modificar)
    }

    private func revisarAcusacion(admitir: Bool) {
        formulario = Formulario(titulo: admitir ? "Admitir acusación" : "Devolver acusación",
                                accion: admitir ? "Admitir" : "Devolver", campos: [.largo("motivo", "Fundamentación")]) { v in
            actualizar { c in
                if admitir {
                    c.admitirAcusacion(v["motivo"])
                } else {
                    c.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "devolver", motivoDevolucion: v["motivo"],
                                                   juezEvaluador: c.sujetos.juezInvestigacionPreparatoria)
                    c.registrar("Acusación devuelta", v["motivo"], autor: c.sujetos.juezInvestigacionPreparatoria)
                }
            }
            if admitir { seccion = 1 } else { navegar(.fiscalia) }
        }
    }

    private func audiencia(_ item: SubcasoIntermedio) {
        formulario = Formulario(titulo: "Registrar audiencia", campos: [
            .opciones("tipo", "Tipo", ["alegatos", "supuestos", "debate_probatorio", "resolucion"]),
            .texto("fecha", "Fecha", inicial: hoy()), .largo("fiscal", "Alegatos de Fiscalía", requerido: false),
            .largo("defensa", "Alegatos de la defensa", requerido: false), .largo("juez", "Conclusiones judiciales")
        ]) { v in
            actualizar { c in
                guard let i = c.subcasos.firstIndex(where: { $0.id == item.id }) else { return }
                c.subcasos[i].audiencias.append(.init(id: nuevoID(), fecha: v["fecha"], tipo: v["tipo"], alegatoFiscalia: v["fiscal"],
                                                      alegatoDefensa: v["defensa"], conclusionesJuez: v["juez"]))
                c.lineaTemporal.append(.init(id: nuevoID(), fecha: v["fecha"], titulo: "Audiencia · " + item.titulo,
                                             descripcion: v["juez"], tipo: "audiencia", autor: c.juezIntermedio))
            }
        }
    }

    private func valorar(_ item: SubcasoIntermedio) {
        let previas = Set(item.pruebasAsignadas.filter { $0.admitidaPJ != false }.map(\.id))
        formulario = Formulario(titulo: "Pruebas admitidas", campos: [
            .largo("motivo", "Valoración probatoria")
        ], pruebas: caso.pruebasRecabadas, seleccion: previas) { v in
            actualizar { c in
                guard let i = c.subcasos.firstIndex(where: { $0.id == item.id }) else { return }
                let mantener = Set(c.subcasos[i].pruebasAsignadas.map(\.id)).union(v.pruebas)
                c.subcasos[i].pruebasAsignadas = c.pruebasRecabadas.filter { mantener.contains($0.id) }.map {
                    var prueba = $0
                    prueba.admitidaPJ = v.pruebas.contains(prueba.id)
                    return prueba
                }
                c.registrar("Valoración probatoria · " + item.titulo, v["motivo"], tipo: "audiencia", autor: c.juezIntermedio)
            }
        }
    }

    private func resolver(_ item: SubcasoIntermedio) {
        formulario = Formulario(titulo: "Resolver subcaso", campos: [
            .opciones("decision", "Decisión", ["procede_juicio", "sobreseimiento", "excluido_ilicitud"]), .largo("motivo", "Motivación")
        ]) { v in
            actualizar { c in
                guard let i = c.subcasos.firstIndex(where: { $0.id == item.id }) else { return }
                let juez = c.juezIntermedio
                c.subcasos[i].estado = v["decision"]
                c.subcasos[i].fechaResolucion = hoy()
                c.subcasos[i].motivacionDecision = v["motivo"]
                c.subcasos[i].juezResolutor = juez
                c.subcasos[i].audiencias.append(.init(id: nuevoID(), fecha: hoy(), tipo: "resolucion", alegatoFiscalia: "", alegatoDefensa: "", conclusionesJuez: v["motivo"]))
                c.registrar(rotulo(v["decision"]) + " · " + item.titulo, v["motivo"], autor: juez)
            }
        }
    }

    private func alegatos(apertura: Bool) {
        let anterior = apertura ? caso.alegatosApertura : caso.alegatosClausura
        let tipo = apertura ? "apertura" : "clausura"
        formulario = Formulario(titulo: "Alegatos de " + tipo, campos: [
            .largo("fiscal", "Fiscalía", inicial: anterior?.fiscalia ?? ""),
            .largo("defensa", "Defensa", inicial: anterior?.defensa ?? "")
        ]) { v in
            actualizar { c in
                let registro = AlegatoJuicio(tipo: tipo, fiscalia: v["fiscal"], defensa: v["defensa"], fecha: hoy())
                if apertura { c.alegatosApertura = registro } else { c.alegatosClausura = registro }
                c.registrar("Alegatos de " + tipo, v["fiscal"] + "\n\n" + v["defensa"], tipo: "audiencia", autor: c.juezOral)
            }
        }
    }

    private func evaluarAlegatos() {
        formulario = Formulario(titulo: "Evaluación judicial", campos: [
            .largo("texto", "Evaluación de los alegatos", inicial: caso.evaluacionAlegatosJuez ?? "")
        ]) { v in actualizar { $0.evaluacionAlegatosJuez = v["texto"] } }
    }

    private func dictar() {
        let nombres = caso.presuntosResponsables
        var campos: [Campo] = [
            .opciones("fallo", "Fallo", ["condenatoria", "absolutoria", "mixta"]),
            .decimal("monto", "Reparación civil (S/)"), .texto("beneficiario", "Beneficiario", inicial: caso.presuntaVictima, requerido: false),
            .largo("motivo", "Fundamentación jurídica")
        ]
        for (i, nombre) in nombres.enumerated() {
            campos += [
                .decimal("pena\(i)", "Años de pena · " + nombre),
                .texto("tipo\(i)", "Tipo de pena · " + nombre, inicial: "Pena privativa de libertad"),
                .decimal("inh\(i)", "Meses de inhabilitación · " + nombre)
            ]
        }
        if !caso.salaActual.isEmpty {
            campos.append(.opciones("resultado", "Fallo de la sala", ["confirma", "revoca", "anula_y_reordena"]))
        }
        formulario = Formulario(titulo: "Dictar sentencia", accion: "Dictar", campos: campos) { v in
            actualizar { c in
                let absolutoria = v["fallo"] == "absolutoria"
                let penas = nombres.enumerated().map { i, nombre in
                    let años = v.numero("pena\(i)") ?? 0
                    let absuelto = absolutoria || (v["fallo"] == "mixta" && años == 0)
                    return Pena(imputadoNombre: nombre, penaAnios: absuelto ? 0 : años,
                                tipoPena: absuelto ? "Absuelto" : v["tipo\(i)"], inhabilitacionMeses: absuelto ? 0 : v.numero("inh\(i)"))
                }
                let juez = c.juezOral
                if let previa = c.sentencia {
                    c.sentenciasAnteriores = (c.sentenciasAnteriores ?? []) + [previa]
                }
                c.sentencia = .init(fecha: hoy(), fallo: v["fallo"], penasImputados: penas, reparacionCivilMonto: absolutoria ? 0 : (v.numero("monto") ?? 0),
                                    reparacionCivilBeneficiario: v["beneficiario"], fundamentacionJuridica: v["motivo"], juezSentenciador: juez)
                c.etapa = .sentencia
                if let i = c.apelaciones.lastIndex(where: { $0.estado == "en_tramite" }) {
                    c.apelaciones[i].estado = "resuelta"
                    c.apelaciones[i].resolucionSala = v["motivo"]
                    c.apelaciones[i].falloApelacion = v["resultado"].isEmpty ? nil : v["resultado"]
                }
                c.registrar("Sentencia " + rotulo(v["fallo"]).lowercased(), v["motivo"], autor: juez)
            }
        }
    }

    private func apelar() {
        formulario = Formulario(titulo: "Interponer apelación", accion: "Presentar", campos: [
            .opciones("parte", "Parte recurrente", ["defensa", "fiscalia", "ambas_partes"]), .largo("motivo", "Motivación de agravios")
        ]) { v in
            actualizar { $0.presentarRecurso(parte: v["parte"], motivo: v["motivo"]) }
            seccion = caso.numeroApelaciones == 2 ? 3 : 1
        }
    }

    private func admisibilidad() {
        formulario = Formulario(titulo: "Admisibilidad del recurso", campos: [
            .opciones("decision", "Decisión de la sala", ["admitir", "inadmisible"]), .largo("motivo", "Fundamentación")
        ]) { v in
            let admitir = v["decision"] == "admitir"
            actualizar { $0.revisarUltimoRecurso(admitir: admitir, motivo: v["motivo"]) }
            seccion = admitir ? 1 : 0
        }
    }

    private func cerrarCaso() {
        formulario = Formulario(titulo: "Cierre definitivo", accion: "Cerrar caso", campos: [.largo("motivo", "Fundamentación")]) { v in
            actualizar { $0.cerrar(v["motivo"]) }
            seccion = 0
        }
    }

    private func resolverPeticion(_ peticion: PeticionFiscal) {
        formulario = Formulario(titulo: "Resolver petición", campos: [
            .opciones("decision", "Decisión", ["admitida", "rechazada"]), .largo("motivo", "Respuesta judicial")
        ]) { v in
            actualizar { c in
                guard let i = c.peticionesFiscales.firstIndex(where: { $0.id == peticion.id }) else { return }
                c.peticionesFiscales[i].estado = v["decision"]
                c.peticionesFiscales[i].respuestaJuez = v["motivo"]
                if v["decision"] == "admitida", var prueba = peticion.nuevaPrueba {
                    prueba.admitidaPJ = true
                    c.incorporar(prueba)
                }
                c.registrar("Petición " + v["decision"] + " · " + peticion.titulo, v["motivo"], autor: c.juezIntermedio)
            }
        }
    }
}

func soles(_ monto: Double) -> String {
    monto.formatted(.currency(code: "PEN").locale(Locale(identifier: "es_PE")))
}

private extension Pena {
    var ponencia: String {
        guard penaAnios > 0 || (inhabilitacionMeses ?? 0) > 0 else { return tipoPena }
        let años = penaAnios.formatted()
        let meses = (inhabilitacionMeses ?? 0).formatted()
        return "\(tipoPena) · \(años) años · \(meses) meses de inhabilitación"
    }
}
