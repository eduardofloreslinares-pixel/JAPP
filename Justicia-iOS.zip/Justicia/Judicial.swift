import SwiftUI

struct Judicial: View {
    @EnvironmentObject private var archivo: Archivo
    let caso: CasoJusticia
    let navegar: (Pestaña) -> Void
    @State private var formulario: Formulario?
    @State private var seccion = 0

    private var avanceSubcasos: String {
        let resueltos = caso.subcasos.filter { $0.estado != "pendiente" }.count
        return "\(resueltos)/\(caso.subcasos.count)"
    }

    var body: some View {
        Contenedor {
            Cabecera(caso: caso, icono: "building.columns.fill", color: .orange,
                     persona: caso.etapa == .juicio || caso.etapa == .sentencia ? caso.juezOral : caso.juezIntermedio)
            if caso.acusacionFiscal == nil {
                Tarjeta(titulo: "A la espera de la acusación", icono: "clock", color: .orange) {
                    Text("El control judicial se habilita al remitirse la acusación fiscal.").font(.subheadline)
                    Accion(titulo: "Ir a Fiscalía", icono: "arrow.left") { navegar(.fiscalia) }
                }
            } else {
                Accesos(nombre: "Secciones judiciales", destinos: [
                    .init(id: 0, titulo: "Actuación", icono: "building.columns"),
                    .init(id: 1, titulo: "Conductas", icono: "square.stack", valor: avanceSubcasos),
                    .init(id: 2, titulo: "Peticiones", icono: "tray.full", valor: String(caso.pendientes)),
                    .init(id: 3, titulo: "Recursos", icono: "arrow.turn.up.right", valor: String(caso.numeroApelaciones))
                ], seleccion: $seccion, color: .orange)
                NavigationLink {
                    ExpedienteJudicial(id: caso.id)
                } label: {
                    Label("Consultar expediente", systemImage: "doc.text")
                }
                .buttonStyle(.glass)
                switch seccion {
                case 1: subcasos
                case 2: peticiones
                case 3: recursos
                default: actuacion
                }
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if seccion == 0 && caso.etapa == .control && caso.acusacionFiscal != nil && !caso.devuelto && !caso.cerrado {
                BarraActuacion {
                    Accion(titulo: "Devolver", icono: "arrow.uturn.backward") { revisarAcusacion(admitir: false) }
                    Accion(titulo: "Admitir acusación", icono: "checkmark", principal: true) { revisarAcusacion(admitir: true) }
                        .disabled(caso.conductas.isEmpty)
                }
            } else if seccion == 0 && caso.etapa == .juicio && !caso.cerrado {
                BarraActuacion {
                    if caso.puedeSentenciar {
                        Accion(titulo: "Dictar sentencia", icono: "checkmark.seal", principal: true) { dictar() }
                    } else if caso.conductasResueltas {
                        Accion(titulo: "Registrar audiencia final", icono: "person.2.wave.2", principal: true) { audienciaFinal() }
                    } else {
                        Accion(titulo: "Revisar conductas · " + avanceSubcasos, icono: "square.stack", principal: true) { seccion = 1 }
                    }
                }
            }
        }
        .sheet(item: $formulario) { Editor(formulario: $0, caso: caso).tint(.orange) }
    }

    @ViewBuilder private var actuacion: some View {
        if caso.cerrado {
            Tarjeta(titulo: "Expediente cerrado", icono: "lock.circle.fill", color: .orange) {
                Dato("Fecha de cierre", caso.fechaCierreDefinitivo ?? "")
                Text("Las actuaciones quedan disponibles para consulta.").font(.subheadline)
            }
        }
        switch caso.etapa {
        case .control: control
        case .intermedia: subcasos
        case .juicio: juicio
        case .sentencia: sentencia; recursos
        case .resuelto: sentencia; recursos
        default: EmptyView()
        }
        if caso.etapa != .control && caso.acusacionFiscal != nil { control }
    }

    private var control: some View {
        Tarjeta(titulo: "Etapa preparatoria · Control judicial", icono: "checkmark.seal", color: .orange) {
            if let acusacion = caso.acusacionFiscal {
                Dato("Fiscal · " + acusacion.fecha, acusacion.fiscalEmisor)
                Dato("Pretensión punitiva", acusacion.pretensionPunitiva)
                Dato("Reparación civil", soles(acusacion.reparacionCivilSolicitada))
                Dato("Fundamentación", acusacion.fundamentosAcusacion)
                ForEach(caso.afectaciones ?? []) { item in
                    DisclosureGroup("Afectación · " + item.titulo) {
                        Dato("Desarrollo fiscal", item.desarrollo)
                        ForEach(caso.pruebasRecabadas.filter { item.pruebas.contains($0.id) }) { prueba in
                            PruebaFila(prueba: prueba)
                        }
                    }
                }
                ForEach(caso.conductas) { conducta in
                    DisclosureGroup(conducta.imputadoNombre) {
                        Dato("Conducta imputada", conducta.descripcionConducta)
                        Dato("Tipificación", conducta.tipificacionLegal)
                        ForEach(caso.pruebasRecabadas.filter { conducta.pruebasAsociadasIds.contains($0.id) }) { prueba in
                            PruebaFila(prueba: prueba)
                        }
                    }
                }
            }
            if let revision = caso.evaluacionAcusacionPJ, revision.decision != "pendiente" {
                Dato(revision.decision == "devolver" ? "Devuelto a Fiscalía" : "Acusación admitida",
                     revision.motivoDevolucion ?? revision.fundamentacionAceptacion ?? "")
            }
            Accion(titulo: "Ver expediente", icono: "doc.text") { navegar(.expediente) }
        }
    }

    @ViewBuilder private var subcasos: some View {
        if caso.subcasos.isEmpty {
            Tarjeta(titulo: "Conductas", icono: "square.stack", color: .orange) {
                Text("Se examinan cuando el juez admite la acusación y abre el juicio oral.").font(.subheadline)
            }
        }
        ForEach(caso.subcasos) { item in
            NavigationLink {
                MesaSubcaso(casoID: caso.id, subcasoID: item.id, prepararValoracion: valorar)
            } label: {
                Tarjeta(titulo: item.imputadoNombre, icono: "person.text.rectangle", color: .orange) {
                    HStack {
                        Etiqueta(texto: rotulo(item.estado), color: colorSubcaso(item.estado))
                        Spacer()
                        Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    }
                    Text(item.conductaDescripcion).font(.subheadline).lineLimit(3)
                    Text(item.tipificacionLegal).font(.caption).foregroundStyle(.secondary)
                    Label("\(item.pruebasAsignadas.count) pruebas · \((item.preguntasJudiciales ?? []).count) preguntas", systemImage: "list.bullet.rectangle")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .buttonStyle(.plain)
        }
        if caso.etapa == .juicio && caso.conductasResueltas {
            Accion(titulo: "Ir a audiencia final", icono: "arrow.right.circle", principal: true) { seccion = 0 }
        }
    }

    @ViewBuilder private var juicio: some View {
        Tarjeta(titulo: "Control judicial", icono: "gauge.with.dots.needle.50percent", color: .orange) {
            ProgressView(value: Double(caso.subcasos.filter { $0.estado != "pendiente" }.count),
                         total: Double(max(caso.subcasos.count, 1)))
                .accessibilityLabel("Progreso del juicio oral")
            Dato("Conductas resueltas", avanceSubcasos)
            ForEach(Array(caso.lineaTemporal.suffix(3).reversed())) { actuacion in
                Dato(actuacion.fecha, actuacion.titulo)
            }
            Accion(titulo: "Examinar conductas", icono: "square.stack") { seccion = 1 }
        }
        Tarjeta(titulo: "Audiencia final", icono: "quote.bubble", color: .orange) {
            if caso.conductasResueltas {
                ForEach(caso.subcasos) { item in
                    DisclosureGroup(item.imputadoNombre + " · " + rotulo(item.estado)) {
                        Dato("Fundamentos de la conducta", item.motivacionDecision ?? "")
                    }
                }
                if let alegatos = caso.alegatosClausura {
                    ParAlegatos(fiscalia: alegatos.fiscalia, defensa: alegatos.defensa)
                }
                ForEach(caso.pruebasRecabadas.filter { (caso.referenciasAudienciaFinal ?? []).contains($0.id) }) { prueba in
                    PruebaFila(prueba: prueba)
                }
                Dato("Valoración conjunta", caso.evaluacionAlegatosJuez ?? "")
                if caso.alegatosClausura != nil {
                    Accion(titulo: "Editar audiencia final", icono: "square.and.pencil") { audienciaFinal() }
                }
            } else {
                Label("Disponible al resolver todas las conductas", systemImage: "lock").font(.subheadline)
            }
        }
    }

    @ViewBuilder private var sentencia: some View {
        if let fallo = caso.sentencia {
            Tarjeta(titulo: "Sentencia \(rotulo(fallo.fallo).lowercased())", icono: "doc.badge.checkmark", color: .orange) {
                Dato(fallo.fecha, fallo.juezSentenciador)
                ForEach(Array(fallo.penasImputados.enumerated()), id: \.offset) { fila in
                    let pena = fila.element
                    Dato(pena.imputadoNombre, pena.ponencia)
                }
                Dato("Reparación civil", soles(fallo.reparacionCivilMonto))
                Dato("Beneficiario", fallo.reparacionCivilBeneficiario)
                Dato("Fundamentación", fallo.fundamentacionJuridica)
                Dato("Evaluación de los alegatos", caso.evaluacionAlegatosJuez ?? "")
                ForEach(Array((caso.sentenciasAnteriores ?? []).enumerated()), id: \.offset) { fila in
                    let anterior = fila.element
                    DisclosureGroup("Sentencia anterior · " + anterior.fecha) {
                        Dato(rotulo(anterior.fallo), anterior.juezSentenciador)
                        Dato("Fundamentación", anterior.fundamentacionJuridica)
                        Dato("Reparación civil", soles(anterior.reparacionCivilMonto))
                    }
                }
            }
        }
    }

    private var recursos: some View {
        Tarjeta(titulo: "Revisión y recursos", icono: "arrow.turn.up.right", color: .orange) {
            if let fallo = caso.sentencia {
                DisclosureGroup("Sentencia de referencia · " + fallo.fecha) {
                    Dato(rotulo(fallo.fallo), fallo.fundamentacionJuridica)
                    Dato("Magistratura", fallo.juezSentenciador)
                    Dato("Reparación civil", soles(fallo.reparacionCivilMonto))
                }
            }
            if caso.apelaciones.isEmpty { Text("No hay apelaciones registradas.").foregroundStyle(.secondary) }
            ForEach(Array(caso.apelaciones.enumerated()), id: \.offset) { fila in
                recursoFila("Apelación \(fila.element.numeroApelacion)", fila.element)
            }
            if let constitucional = caso.recursoConstitucional {
                recursoFila("Tribunal Constitucional", constitucional)
            }
            if caso.etapa == .sentencia && !caso.cerrado && caso.sentencia != nil {
                if let pendiente = caso.recursoPendiente {
                    Dato("Fallo impugnado", pendiente.falloImpugnado ?? "")
                    ForEach(caso.subcasos) { item in
                        DisclosureGroup(item.imputadoNombre + " · " + rotulo(item.estado)) {
                            Dato("Resolución de la conducta", item.motivacionDecision ?? "")
                        }
                    }
                    DisclosureGroup("Pruebas del expediente · \(caso.pruebasRecabadas.count)") {
                        ForEach(caso.pruebasRecabadas) { PruebaFila(prueba: $0) }
                    }
                    if let final = caso.alegatosClausura {
                        DisclosureGroup("Alegatos finales") {
                            ParAlegatos(fiscalia: final.fiscalia, defensa: final.defensa)
                        }
                    }
                    Accion(titulo: "Evaluar actuados y emitir fallo", icono: "checkmark.seal", principal: true) { revisarRecurso() }
                } else if caso.recursoConstitucional?.estado == "en_tramite" {
                    Accion(titulo: "Registrar decisión constitucional", icono: "checkmark.seal", principal: true) { resolverTC() }
                } else {
                    if caso.numeroApelaciones < 2 && caso.recursoConstitucional == nil {
                        Accion(titulo: caso.numeroApelaciones == 0 ? "Apelar sentencia" : "Apelar el fallo",
                               icono: "arrow.turn.up.right", principal: true) { apelar() }
                    }
                    if caso.puedeRecurrirTC {
                        Accion(titulo: "Presentar recurso constitucional", icono: "building.columns") { apelar(constitucional: true) }
                    }
                    Accion(titulo: "Cerrar expediente", icono: "lock") { cerrarCaso() }
                }
            }
        }
    }

    private func recursoFila(_ titulo: String, _ recurso: ApelacionRecord) -> some View {
        DisclosureGroup(titulo + " · " + rotulo(recurso.estado)) {
            Dato(rotulo(recurso.quienApela) + " · " + recurso.fechaInterposicion, recurso.motivosAgravios)
            Dato("Fallo impugnado", recurso.falloImpugnado ?? "")
            Dato("Sala revisora", recurso.juecesSalaApelaciones.joined(separator: "\n"))
            Dato("Evaluación cualitativa de los actuados", recurso.evaluacionActuados ?? "")
            Dato("Fallo", recurso.falloApelacion.map(rotulo) ?? "")
            Dato("Fundamentación", recurso.resolucionSala ?? "")
        }
    }

    private var peticiones: some View {
        Tarjeta(titulo: "Peticiones fiscales", icono: "tray.full", color: .orange) {
            if caso.peticionesFiscales.isEmpty { Text("No hay peticiones registradas.").foregroundStyle(.secondary) }
            ForEach(caso.peticionesFiscales) { peticion in
                PeticionFila(peticion: peticion)
                if peticion.estado == "pendiente" && !caso.cerrado && !caso.devuelto {
                    Accion(titulo: "Resolver «\(peticion.titulo)»", icono: "checkmark.seal") { resolverPeticion(peticion) }
                }
            }
        }
    }

    private func actualizar(_ modificar: (inout CasoJusticia) -> Void) {
        archivo.actualizar(caso.id, modificar)
    }

    private func revisarAcusacion(admitir: Bool) {
        formulario = Formulario(titulo: admitir ? "Admitir acusación" : "Devolver acusación",
                                accion: admitir ? "Admitir" : "Devolver", campos: [.largo("motivo", "Fundamentación")]) { v in
            actualizar { c in
                if admitir {
                    c.admitirAcusacion(v["motivo"])
                } else {
                    c.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "devolver", motivoDevolucion: v["motivo"],
                                                   juezEvaluador: c.sujetos.juezInvestigacionPreparatoria)
                    c.registrar("Acusación devuelta", v["motivo"], autor: c.sujetos.juezInvestigacionPreparatoria)
                }
            }
            if admitir { seccion = 1 } else { navegar(.fiscalia) }
        }
    }

    private func valorar(_ item: SubcasoIntermedio, _ expediente: CasoJusticia) -> Formulario {
        let previas = Set(item.pruebasAsignadas.filter { $0.admitidaPJ != false }.map(\.id))
        return Formulario(titulo: "Pruebas admitidas", campos: [
            .largo("motivo", "Valoración probatoria")
        ], pruebas: expediente.pruebasRecabadas, seleccion: previas) { v in
            actualizar { c in
                guard let i = c.subcasos.firstIndex(where: { $0.id == item.id }) else { return }
                let mantener = Set(c.subcasos[i].pruebasAsignadas.map(\.id)).union(v.pruebas)
                c.subcasos[i].pruebasAsignadas = c.pruebasRecabadas.filter { mantener.contains($0.id) }.map {
                    var prueba = $0
                    prueba.admitidaPJ = v.pruebas.contains(prueba.id)
                    return prueba
                }
                c.registrar("Valoración probatoria · " + item.titulo, v["motivo"], tipo: "audiencia", autor: c.juezOral)
            }
        }
    }

    private func audienciaFinal() {
        guard caso.conductasResueltas else { return }
        let anterior = caso.alegatosClausura
        formulario = Formulario(titulo: "Audiencia final", campos: [
            .largo("fiscal", "Alegatos de Fiscalía", inicial: anterior?.fiscalia ?? ""),
            .largo("contraparte", "Alegatos de la contraparte", inicial: anterior?.defensa ?? ""),
            .largo("evaluacion", "Valoración conjunta de conductas, pruebas y alegatos", inicial: caso.evaluacionAlegatosJuez ?? "")
        ], pruebas: caso.pruebasRecabadas, seleccion: Set(caso.referenciasAudienciaFinal ?? [])) { v in
            actualizar { c in
                guard c.etapa == .juicio, c.conductasResueltas else { return }
                c.alegatosClausura = .init(tipo: "clausura", fiscalia: v["fiscal"], defensa: v["contraparte"], fecha: hoy())
                c.evaluacionAlegatosJuez = v["evaluacion"]
                c.referenciasAudienciaFinal = v.pruebas.sorted()
                c.registrar("Audiencia final", v["evaluacion"], tipo: "audiencia", autor: c.juezOral)
            }
        }
    }

    private func dictar() {
        guard caso.puedeSentenciar else { return }
        let nombres = caso.presuntosResponsables
        var campos: [Campo] = [
            .opciones("fallo", "Fallo", ["condenatoria", "absolutoria", "mixta"]),
            .decimal("monto", "Reparación civil (S/)"), .texto("beneficiario", "Beneficiario", inicial: caso.presuntaVictima, requerido: false),
            .largo("motivo", "Fundamentación jurídica")
        ]
        for (i, nombre) in nombres.enumerated() {
            campos += [
                .decimal("pena\(i)", "Años de pena · " + nombre),
                .texto("tipo\(i)", "Tipo de pena · " + nombre, inicial: "Pena privativa de libertad"),
                .decimal("inh\(i)", "Meses de inhabilitación · " + nombre)
            ]
        }
        formulario = Formulario(titulo: "Dictar sentencia", accion: "Dictar", campos: campos) { v in
            actualizar { c in
                guard c.puedeSentenciar else { return }
                let absolutoria = v["fallo"] == "absolutoria"
                let penas = nombres.enumerated().map { i, nombre in
                    let años = v.numero("pena\(i)") ?? 0
                    let absuelto = absolutoria || (v["fallo"] == "mixta" && años == 0)
                    return Pena(imputadoNombre: nombre, penaAnios: absuelto ? 0 : años,
                                tipoPena: absuelto ? "Absuelto" : v["tipo\(i)"], inhabilitacionMeses: absuelto ? 0 : v.numero("inh\(i)"))
                }
                let juez = c.juezOral
                if let previa = c.sentencia {
                    c.sentenciasAnteriores = (c.sentenciasAnteriores ?? []) + [previa]
                }
                c.sentencia = .init(fecha: hoy(), fallo: v["fallo"], penasImputados: penas, reparacionCivilMonto: absolutoria ? 0 : (v.numero("monto") ?? 0),
                                    reparacionCivilBeneficiario: v["beneficiario"], fundamentacionJuridica: v["motivo"], juezSentenciador: juez)
                c.etapa = .sentencia
                if let i = c.apelaciones.lastIndex(where: { $0.estado == "en_tramite" }) {
                    c.apelaciones[i].estado = "resuelta"
                    c.apelaciones[i].resolucionSala = v["motivo"]
                    c.apelaciones[i].falloApelacion = "resuelta_en_sentencia"
                }
                c.registrar("Sentencia " + rotulo(v["fallo"]).lowercased(), v["motivo"], autor: juez)
            }
        }
    }

    private func apelar(constitucional: Bool = false) {
        formulario = Formulario(titulo: constitucional ? "Recurso constitucional" : "Interponer apelación", accion: "Presentar", campos: [
            .opciones("parte", "Parte recurrente", ["defensa", "fiscalia", "ambas_partes"]),
            .largo("motivo", constitucional ? "Fundamentos del recurso" : "Agravios del fallo impugnado")
        ]) { v in
            actualizar { c in
                if constitucional { c.presentarRecursoTC(parte: v["parte"], motivo: v["motivo"]) }
                else { c.presentarRecurso(parte: v["parte"], motivo: v["motivo"]) }
            }
            seccion = 3
        }
    }

    private func revisarRecurso() {
        formulario = Formulario(titulo: "Revisión de los actuados", accion: "Emitir fallo", campos: [
            .largo("evaluacion", "Evaluación cualitativa de resoluciones, pruebas y alegatos"),
            .opciones("fallo", "Fallo", ["confirma", "revoca", "modifica", "anula_y_reordena", "inadmisible"]),
            .largo("motivo", "Fundamentos y parte resolutiva")
        ]) { v in
            actualizar { $0.resolverRecurso(evaluacion: v["evaluacion"], fallo: v["fallo"], fundamento: v["motivo"]) }
        }
    }

    private func resolverTC() {
        formulario = Formulario(titulo: "Decisión constitucional", campos: [
            .opciones("fallo", "Decisión", ["fundado", "infundado", "improcedente"]),
            .largo("motivo", "Fundamentos y efectos de la decisión")
        ]) { v in
            actualizar { $0.resolverRecursoTC(fallo: v["fallo"], fundamento: v["motivo"]) }
        }
    }

    private func cerrarCaso() {
        formulario = Formulario(titulo: "Cierre definitivo", accion: "Cerrar caso", campos: [.largo("motivo", "Fundamentación")]) { v in
            actualizar { $0.cerrar(v["motivo"]) }
            seccion = 0
        }
    }

    private func resolverPeticion(_ peticion: PeticionFiscal) {
        formulario = Formulario(titulo: "Resolver petición", campos: [
            .opciones("decision", "Decisión", ["admitida", "rechazada"]), .largo("motivo", "Respuesta judicial")
        ]) { v in
            actualizar { c in
                guard let i = c.peticionesFiscales.firstIndex(where: { $0.id == peticion.id }) else { return }
                c.peticionesFiscales[i].estado = v["decision"]
                c.peticionesFiscales[i].respuestaJuez = v["motivo"]
                if v["decision"] == "admitida", var prueba = peticion.nuevaPrueba {
                    prueba.admitidaPJ = true
                    c.incorporar(prueba)
                }
                c.registrar("Petición " + v["decision"] + " · " + peticion.titulo, v["motivo"], autor: c.juezIntermedio)
            }
        }
    }
}

func soles(_ monto: Double) -> String {
    monto.formatted(.currency(code: "PEN").locale(Locale(identifier: "es_PE")))
}

private extension Pena {
    var ponencia: String {
        guard penaAnios > 0 || (inhabilitacionMeses ?? 0) > 0 else { return tipoPena }
        let años = penaAnios.formatted()
        let meses = (inhabilitacionMeses ?? 0).formatted()
        return "\(tipoPena) · \(años) años · \(meses) meses de inhabilitación"
    }
}

private func colorSubcaso(_ estado: String) -> Color {
    switch estado {
    case "pendiente": .orange
    case "procede_juicio", "acreditada": .green
    case "excluido_ilicitud", "no_acreditada": .red
    default: .indigo
    }
}

private struct MesaSubcaso: View {
    @EnvironmentObject private var archivo: Archivo
    let casoID: String
    let subcasoID: String
    let prepararValoracion: (SubcasoIntermedio, CasoJusticia) -> Formulario
    @State private var formulario: Formulario?
    @State private var pruebaAbierta: PruebaElemento?
    @State private var mostrandoBorrador = false

    var body: some View {
        if let caso = archivo.expedientes.first(where: { $0.id == casoID }),
           let item = caso.subcasos.first(where: { $0.id == subcasoID }) {
            let editable = caso.etapa == .juicio && item.estado == "pendiente" && !caso.cerrado
            Contenedor {
                Tarjeta(titulo: item.titulo, icono: "building.columns", color: .orange) {
                    Etiqueta(texto: rotulo(item.estado), color: colorSubcaso(item.estado))
                    Text(item.conductaDescripcion).font(.title3.bold()).fontDesign(.serif)
                    Dato("Tipificación jurídica", item.tipificacionLegal)
                    Dato("Magistratura", item.juezResolutor ?? caso.juezOral)
                }
                preguntas(item, editable: editable)
                diligencias(item, editable: editable)
                if !item.audiencias.isEmpty { alegatos(item) }
                pruebas(item, caso: caso, editable: editable)
                if let motivacion = item.motivacionDecision {
                    Tarjeta(titulo: "Resolución", icono: "checkmark.seal", color: colorSubcaso(item.estado)) {
                        Dato(item.fechaResolucion ?? "Motivación", motivacion)
                        ForEach(caso.pruebasRecabadas.filter { (item.referenciasResolucion ?? []).contains($0.id) }) { prueba in
                            Button(prueba.titulo, systemImage: "link") { pruebaAbierta = prueba }
                        }
                    }
                }
            }
            .navigationTitle("Minijuicio por conducta")
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if editable {
                    BarraActuacion {
                        Accion(titulo: "Pregunta judicial", icono: "questionmark.bubble") { nuevaPregunta() }
                        Accion(titulo: item.borrador == nil ? "Redactar resolución" : "Retomar borrador", icono: "square.and.pencil", principal: true) {
                            mostrandoBorrador = true
                        }
                    }
                }
            }
            .sheet(item: $formulario) { Editor(formulario: $0, caso: caso).tint(.orange) }
            .sheet(item: $pruebaAbierta) { DetallePrueba(prueba: $0).tint(.orange) }
            .sheet(isPresented: $mostrandoBorrador) { EditorResolucion(casoID: casoID, item: item) }
        }
    }

    private func preguntas(_ item: SubcasoIntermedio, editable: Bool) -> some View {
        Tarjeta(titulo: "Preguntas del juez", icono: "questionmark.bubble", color: .orange) {
            let preguntas = item.preguntasJudiciales ?? []
            if preguntas.isEmpty {
                Text("El juez formula una pregunta específica sobre esta conducta. Luego responden Fiscalía y la contraparte.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(preguntas) { pregunta in
                VStack(alignment: .leading, spacing: 10) {
                    Text(pregunta.pregunta).font(.headline)
                    if pregunta.fiscalia != nil || pregunta.contraparte != nil {
                        ParAlegatos(fiscalia: pregunta.fiscalia ?? "", defensa: pregunta.contraparte ?? "")
                    }
                    Dato("Evaluación del juez", pregunta.evaluacion ?? "")
                    if editable && !pregunta.completa {
                        let paso = pregunta.fiscalia == nil ? "fiscalia" : pregunta.contraparte == nil ? "contraparte" : "evaluacion"
                        Accion(titulo: tituloPaso(paso), icono: "square.and.pencil") { contestar(pregunta, paso: paso) }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(11)
                .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    private func diligencias(_ item: SubcasoIntermedio, editable: Bool) -> some View {
        Tarjeta(titulo: "Diligencias especiales", icono: "list.clipboard", color: .orange) {
            ForEach(item.diligenciasEspeciales ?? []) { diligencia in
                VStack(alignment: .leading, spacing: 6) {
                    Dato("Orden judicial", diligencia.orden)
                    Dato("Resultado", diligencia.resultado ?? "Pendiente")
                    if editable && diligencia.resultado == nil {
                        Accion(titulo: "Registrar resultado", icono: "checkmark") { registrarResultado(diligencia) }
                    }
                }
            }
            if editable {
                Accion(titulo: "Ordenar diligencia", icono: "plus") { ordenarDiligencia() }
                Accion(titulo: "Recabar prueba", icono: "doc.badge.plus") { recabarPrueba() }
            }
        }
    }

    private func modificar(_ cambio: (inout SubcasoIntermedio, inout CasoJusticia) -> Void) {
        archivo.actualizar(casoID) { caso in
            guard caso.etapa == .juicio,
                  let indice = caso.subcasos.firstIndex(where: { $0.id == subcasoID && $0.estado == "pendiente" }) else { return }
            var subcaso = caso.subcasos[indice]
            cambio(&subcaso, &caso)
            caso.subcasos[indice] = subcaso
        }
    }

    private func nuevaPregunta() {
        formulario = Formulario(titulo: "Pregunta judicial", campos: [
            .largo("pregunta", "Pregunta específica sobre la conducta")
        ]) { v in
            modificar { subcaso, caso in
                subcaso.preguntasJudiciales = (subcaso.preguntasJudiciales ?? []) + [PreguntaJudicial(pregunta: v["pregunta"])]
                caso.registrar("Pregunta judicial · " + subcaso.titulo, v["pregunta"], tipo: "audiencia", autor: caso.juezOral)
            }
        }
    }

    private func tituloPaso(_ paso: String) -> String {
        switch paso {
        case "fiscalia": "Registrar respuesta de Fiscalía"
        case "contraparte": "Registrar respuesta de la contraparte"
        default: "Evaluar las respuestas"
        }
    }

    private func contestar(_ pregunta: PreguntaJudicial, paso: String) {
        formulario = Formulario(titulo: tituloPaso(paso), campos: [
            .largo("respuesta", paso == "evaluacion" ? "Evaluación judicial" : "Respuesta")
        ]) { v in
            modificar { subcaso, caso in
                guard var preguntas = subcaso.preguntasJudiciales,
                      let i = preguntas.firstIndex(where: { $0.id == pregunta.id }) else { return }
                let texto = v["respuesta"]
                switch paso {
                case "fiscalia": preguntas[i].fiscalia = texto
                case "contraparte": preguntas[i].contraparte = texto
                default: preguntas[i].evaluacion = texto
                }
                subcaso.preguntasJudiciales = preguntas
                let autor = paso == "fiscalia" ? caso.sujetos.fiscalProvincial : paso == "contraparte" ? caso.sujetos.abogadoDefensa : caso.juezOral
                caso.registrar(tituloPaso(paso) + " · " + subcaso.titulo, texto, tipo: "audiencia", autor: autor)
            }
        }
    }

    private func ordenarDiligencia() {
        formulario = Formulario(titulo: "Diligencia especial", accion: "Ordenar", campos: [
            .largo("orden", "Actuación ordenada y propósito")
        ]) { v in
            modificar { subcaso, caso in
                subcaso.diligenciasEspeciales = (subcaso.diligenciasEspeciales ?? []) + [DiligenciaEspecial(orden: v["orden"])]
                caso.registrar("Diligencia especial · " + subcaso.titulo, v["orden"], tipo: "diligencia", autor: caso.juezOral)
            }
        }
    }

    private func registrarResultado(_ diligencia: DiligenciaEspecial) {
        formulario = Formulario(titulo: "Resultado de diligencia", campos: [.largo("resultado", "Resultado")]) { v in
            modificar { subcaso, caso in
                guard var diligencias = subcaso.diligenciasEspeciales,
                      let i = diligencias.firstIndex(where: { $0.id == diligencia.id }) else { return }
                diligencias[i].resultado = v["resultado"]
                subcaso.diligenciasEspeciales = diligencias
                caso.registrar("Resultado de diligencia · " + subcaso.titulo, v["resultado"], tipo: "diligencia", autor: caso.juezOral)
            }
        }
    }

    private func recabarPrueba() {
        formulario = Formulario(titulo: "Recabar prueba", campos: camposPrueba) { v in
            modificar { subcaso, caso in
                let prueba = crearPrueba(v)
                caso.incorporar(prueba)
                subcaso.pruebasAsignadas.append(prueba)
                caso.registrar("Prueba recabada · " + subcaso.titulo, prueba.titulo, tipo: "diligencia", autor: caso.juezOral)
            }
        }
    }

    private func alegatos(_ item: SubcasoIntermedio) -> some View {
        Tarjeta(titulo: "Actuaciones registradas", icono: "quote.bubble", color: .orange) {
            if item.audiencias.isEmpty {
                Text("Registra una audiencia para comparar las posiciones y poder emitir la resolución.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(Array(item.audiencias.enumerated().reversed()), id: \.offset) { fila in
                VStack(alignment: .leading, spacing: 8) {
                    Text(rotulo(fila.element.tipo) + " · " + fila.element.fecha).font(.subheadline.bold())
                    if fila.element.tipo != "resolucion" {
                        ParAlegatos(fiscalia: fila.element.alegatoFiscalia, defensa: fila.element.alegatoDefensa)
                    }
                    Dato("Conclusiones judiciales", fila.element.conclusionesJuez ?? "")
                }
            }
        }
    }

    private func pruebas(_ item: SubcasoIntermedio, caso: CasoJusticia, editable: Bool) -> some View {
        Tarjeta(titulo: "Pruebas de la conducta", icono: "tray.full", color: .orange) {
            if item.pruebasAsignadas.isEmpty {
                Text("Sin pruebas vinculadas.").font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(item.pruebasAsignadas) { prueba in filaPrueba(prueba, vinculada: true) }
            let otras = caso.pruebasRecabadas.filter { prueba in !item.pruebasAsignadas.contains { $0.id == prueba.id } }
            if !otras.isEmpty {
                DisclosureGroup("Otras pruebas del expediente · \(otras.count)") {
                    ForEach(otras) { prueba in filaPrueba(prueba, vinculada: false) }
                }
            }
            if editable && !caso.pruebasRecabadas.isEmpty {
                Accion(titulo: "Valorar pruebas", icono: "checklist") { formulario = prepararValoracion(item, caso) }
            }
        }
    }

    private func filaPrueba(_ prueba: PruebaElemento, vinculada: Bool) -> some View {
        Button {
            pruebaAbierta = prueba
        } label: {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(prueba.titulo).font(.subheadline.bold())
                    Text([rotulo(prueba.tipo), prueba.origen, prueba.fechaRecabada].filter { !$0.isEmpty }.joined(separator: " · "))
                        .font(.caption).foregroundStyle(.secondary)
                    if vinculada {
                        Etiqueta(texto: prueba.admitidaPJ == true ? "Admitida" : prueba.admitidaPJ == false ? "Excluida" : "Sin valorar",
                                 color: prueba.admitidaPJ == true ? .green : prueba.admitidaPJ == false ? .red : .orange)
                    }
                }
                Spacer(minLength: 8)
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            }
            .padding(.vertical, 7)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct EditorResolucion: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var cerrar
    let casoID: String
    let item: SubcasoIntermedio
    @State private var borrador: BorradorResolucion
    @State private var pruebaAbierta: PruebaElemento?
    @State private var consulta = false

    init(casoID: String, item: SubcasoIntermedio) {
        self.casoID = casoID
        self.item = item
        var inicial = item.borrador ?? BorradorResolucion()
        if inicial.resultado == "procede_juicio" { inicial.resultado = "acreditada" }
        if inicial.resultado == "sobreseimiento" { inicial.resultado = "no_acreditada" }
        _borrador = State(initialValue: inicial)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(item.conductaDescripcion).font(.subheadline)
                    Text(item.tipificacionLegal).font(.caption).foregroundStyle(.secondary)
                } header: { Text(item.imputadoNombre) }
                Section("Decisión y motivos") {
                    Picker("Resultado", selection: $borrador.resultado) {
                        ForEach(["acreditada", "no_acreditada", "excluido_ilicitud"], id: \.self) { Text(rotulo($0)).tag($0) }
                    }
                    TextField("Motivación", text: $borrador.motivos, axis: .vertical).lineLimit(4...12)
                }
                if let caso = archivo.expedientes.first(where: { $0.id == casoID }), !caso.pruebasRecabadas.isEmpty {
                    Section("Pruebas consideradas") {
                        ForEach(caso.pruebasRecabadas) { prueba in
                            Toggle(prueba.titulo, isOn: Binding(get: { borrador.referencias.contains(prueba.id) }, set: { activo in
                                if activo { borrador.referencias.insert(prueba.id) }
                                else { borrador.referencias.remove(prueba.id) }
                            }))
                            Button("Ver ficha", systemImage: "info.circle") { pruebaAbierta = prueba }
                                .accessibilityLabel("Ver ficha de " + prueba.titulo)
                        }
                    }
                }
                if !listoParaResolver {
                    Section {
                        Text("Completa las preguntas judiciales y las diligencias especiales antes de resolver. Puedes guardar el borrador ahora.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Resolución")
            .navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled()
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    Button("Consultar expediente", systemImage: "doc.text.magnifyingglass") { consulta = true }
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Guardar borrador") { guardar(publicar: false) }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Emitir") { guardar(publicar: true) }
                        .disabled(!listoParaResolver || motivos.isEmpty)
                }
            }
            .sheet(item: $pruebaAbierta) { DetallePrueba(prueba: $0) }
            .sheet(isPresented: $consulta) {
                if let caso = archivo.expedientes.first(where: { $0.id == casoID }) {
                    ConsultaRapida(caso: caso)
                }
            }
        }
        .tint(.orange)
    }

    private var motivos: String { borrador.motivos.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var listoParaResolver: Bool { item.listoParaResolver }

    private func guardar(publicar: Bool) {
        archivo.actualizar(casoID) { caso in
            guard caso.etapa == .juicio,
                  let indice = caso.subcasos.firstIndex(where: { $0.id == item.id && $0.estado == "pendiente" }) else { return }
            if publicar {
                guard caso.subcasos[indice].listoParaResolver, !motivos.isEmpty else { return }
                let juez = caso.juezOral
                caso.subcasos[indice].estado = borrador.resultado
                caso.subcasos[indice].fechaResolucion = hoy()
                caso.subcasos[indice].motivacionDecision = motivos
                caso.subcasos[indice].juezResolutor = juez
                caso.subcasos[indice].referenciasResolucion = borrador.referencias.sorted()
                caso.subcasos[indice].borrador = nil
                caso.subcasos[indice].audiencias.append(.init(id: nuevoID(), fecha: hoy(), tipo: "resolucion",
                    alegatoFiscalia: "", alegatoDefensa: "", conclusionesJuez: motivos))
                caso.registrar(rotulo(borrador.resultado) + " · " + item.titulo, motivos, autor: juez)
            } else {
                caso.subcasos[indice].borrador = borrador
            }
        }
        cerrar()
    }
}
