window.justiciaBlankCase = {"id":"exp-nuevo-1793374595607","numeroExpediente":"EXP. 1416-2026-JR-PE-01","etapaActual":"investigacion_preliminar","queOcurrio":"","cuando":"","donde":"","como":"","delitoImputado":"","presuntosResponsables":[],"presuntaVictima":"","descripcionHechos":"","lineaTemporal":[],"sujetos":{"fiscalProvincial":"Dr. Fiscal Provincial Titular","fiscalAdjunto":"Dra. Fiscal Adjunta","juezInvestigacionPreparatoria":"Dra. Jueza de Investigación Preparatoria","juezJuicioOral":"Dr. Juez Penal Unipersonal","juecesApelacionInstancia1":["Vocal Presidente 1","Vocal 2","Vocal 3"],"juecesApelacionInstancia2":["Vocal Superior A","Vocal Superior B","Vocal Superior C"],"juecesApelacionInstancia3":["Juez Supremo 1","Juez Supremo 2","Juez Supremo 3"],"abogadoDefensa":"Dr. Abogado Defensor","peritoOficial":"Perito Criminalístico Oficial"},"diligenciasPreliminares":[],"pruebasRecabadas":[],"evaluacionPreliminar":"","conductas":[],"diligenciasPreparatorias":[],"peticionesFiscales":[],"subcasos":[],"apelaciones":[],"apelacionActualIndex":0,"casoCerradoDefinitivo":false};

(() => {
  const root = document.getElementById('root');
  const bridge = window.webkit?.messageHandlers?.justicia;
  const tabs = () => [...root.querySelectorAll('nav > div > button')];
  const keys = ['justicia_expediente_v1', 'justicia_expedientes_v2'];
  let lastMessage = '';
  let scheduled = false;
  window.justiciaReload = () => {
    if (bridge) {
      window.justiciaPersist?.();
      bridge.postMessage({ kind: 'reload' });
    } else {
      location.reload();
    }
  };
  window.justiciaShowTab = index => tabs()[index]?.click();
  window.justiciaExportCase = () => {
    const content = localStorage.getItem(keys[0]);
    if (content) bridge?.postMessage({ kind: 'export', content });
  };
  function update() {
    scheduled = false;
    const buttons = tabs();
    if (buttons.length !== 3) return;
    const selected = buttons.findIndex(button => button.classList.contains('font-semibold'));
    const badges = buttons.slice(0, 2).map(button =>
      (button.querySelector(':scope > .absolute')?.textContent || '').trim());
    let title = '';
    try { title = JSON.parse(localStorage.getItem(keys[0]))?.numeroExpediente ?? ''; } catch {}
    const message = { kind: 'navigation', selected, badges, title };
    const encoded = JSON.stringify(message);
    if (lastMessage !== encoded) {
      lastMessage = encoded;
      bridge?.postMessage(message);
    }
    window.justiciaPersist?.();
  }
  function schedule() {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(update);
    }
  }
  new MutationObserver(schedule).observe(root, {
    subtree: true, childList: true, attributes: true, characterData: true
  });
  schedule();
})();
