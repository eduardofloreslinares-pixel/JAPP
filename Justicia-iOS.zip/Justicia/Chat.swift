import SwiftUI

private struct ActorChat: Identifiable {
    let id: String
    let nombre: String
    let rol: Rol
}

struct Chat: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var volver
    let casoID: UUID
    let actoID: UUID
    @State private var actorID: String?
    @State private var texto = ""
    @State private var modo: Intervencion.Tipo = .mensaje
    @State private var cierreChat: CierreChat?
    @State private var consultar = false
    @State private var termino = false

    private enum CierreChat: String, Identifiable {
        case resolver, reprogramar, finalizar
        var id: String { rawValue }
        var titulo: String {
            switch self {
            case .resolver: "Resolver minijuicio"
            case .reprogramar: "Reprogramar minijuicio"
            case .finalizar: "Cerrar audiencia"
            }
        }
    }

    var body: some View {
        if let caso = archivo.caso(casoID), let acto = caso.acto(actoID) {
            NavigationStack {
                VStack(spacing: 0) {
                    encabezado(caso: caso, acto: acto)
                    historial(acto: acto, actor: actor(caso))
                    if !acto.cerrada && !caso.cerrado {
                        if let actor = actor(caso) { escritor(actor, acto: acto) }
                        else {
                            Text("Elige tu rol para intervenir.")
                                .font(.subheadline).foregroundStyle(.secondary)
                                .padding(16)
                        }
                    }
                }
                .background(Color(uiColor: .systemGroupedBackground))
                .navigationTitle(acto.titulo)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Volver") { volver() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Consultar expediente", systemImage: "doc.text.magnifyingglass") { consultar = true }
                            .labelStyle(.iconOnly)
                    }
                }
                .sheet(item: $cierreChat, onDismiss: {
                    if termino { volver() }
                }) { opcion in
                    if let actor = actor(caso), actor.rol == .juez {
                        DecidirChat(casoID: casoID, actoID: actoID, autor: actor.nombre,
                                   titulo: opcion.titulo, reprogramar: opcion == .reprogramar,
                                   votar: opcion == .resolver) { termino = true }
                    }
                }
                .sheet(isPresented: $consultar) {
                    ConsultaChat(caso: caso, acto: acto)
                }
            }
        }
    }

    private func personas(_ caso: Caso) -> [ActorChat] {
        caso.jueces.map { .init(id: $0.id.uuidString, nombre: $0.nombre, rol: .juez) }
        + caso.fiscales.map { .init(id: $0.id.uuidString, nombre: $0.nombre, rol: .fiscal) }
        + [.init(id: "contraparte", nombre: "Contraparte", rol: .defensa)]
    }

    private func actor(_ caso: Caso) -> ActorChat? { personas(caso).first { $0.id == actorID } }

    private func encabezado(caso: Caso, acto: Acto) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(acto.codigo).font(.caption2.monospacedDigit()).foregroundStyle(.secondary)
                    if let id = acto.conducta, let conducta = caso.acto(id) {
                        Text(conducta.titulo).font(.headline)
                    }
                }
                Spacer(minLength: 6)
                if !acto.cerrada && !caso.cerrado {
                    Menu {
                        ForEach(personas(caso)) { persona in
                            Button {
                                actorID = persona.id
                                modo = .mensaje
                            } label: {
                                Label(persona.rol.titulo + " · " + persona.nombre, systemImage: persona.id == actorID ? "checkmark" : "person")
                            }
                        }
                    } label: {
                        Label(actor(caso)?.nombre ?? "Elegir rol", systemImage: "person.crop.circle")
                            .font(.subheadline.weight(.semibold))
                    }
                }
            }
            if let decision = acto.decision {
                Text(decision).font(.subheadline.bold()).foregroundStyle(Oro.resultado(acto.resultado) ?? .primary)
            }
        }
        .padding(13)
        .background(.regularMaterial)
    }

    private func historial(acto: Acto, actor: ActorChat?) -> some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 12) {
                    if acto.mensajes.isEmpty {
                        ContentUnavailableView("Audiencia abierta", systemImage: "bubble.left.and.bubble.right",
                                               description: Text("Elige un rol. El juez puede formular preguntas desde el menú del chat."))
                    }
                    ForEach(acto.mensajes) { mensaje in
                        mensajeFila(mensaje, acto: acto, actor: actor)
                    }
                    if !acto.votos.isEmpty { ResumenVotos(votos: acto.votos, resultado: acto.resultado) }
                    Color.clear.frame(height: 1).id("ultimo")
                }
                .padding(15)
            }
            .defaultScrollAnchor(.bottom)
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: acto.mensajes.count) { _, _ in
                withAnimation(.easeOut(duration: 0.18)) { proxy.scrollTo("ultimo", anchor: .bottom) }
            }
        }
    }

    private func mensajeFila(_ mensaje: Intervencion, acto: Acto, actor: ActorChat?) -> some View {
        let esMio = mensaje.autorID != nil && mensaje.autorID == actor?.id
        let color = Oro.resultado(mensaje.resultado) ?? colorRol(mensaje.rol)
        return HStack(alignment: .top) {
            if esMio { Spacer(minLength: 28) }
            VStack(alignment: .leading, spacing: 5) {
                Text(mensaje.autor + " · " + mensaje.rol.titulo)
                    .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                if mensaje.tipo == .pregunta || mensaje.tipo == .preguntaObjetiva {
                    Text(mensaje.tipo == .preguntaObjetiva ? "Pregunta objetiva" : "Pregunta del juez")
                        .font(.caption2.bold())
                }
                if let origen = mensaje.respuestaA, let pregunta = acto.mensajes.first(where: { $0.id == origen }) {
                    Text(pregunta.texto).font(.caption).foregroundStyle(.secondary)
                }
                Text(mensaje.texto).font(.subheadline).textSelection(.enabled)
                if mensaje.tipo == .preguntaObjetiva, !acto.cerrada, let actor, actor.rol != .juez,
                   !acto.mensajes.contains(where: { $0.respuestaA == mensaje.id && $0.autorID == actor.id }) {
                    HStack {
                        Button("Sí") { responder(true, pregunta: mensaje, actor: actor) }.buttonStyle(.bordered).tint(.green)
                        Button("No") { responder(false, pregunta: mensaje, actor: actor) }.buttonStyle(.bordered).tint(.red)
                    }
                }
                SelloBurbuja(texto: mensaje.fecha.formatted(date: .numeric, time: .shortened))
            }
            .padding(11)
            .background(color.opacity(mensaje.resultado == nil ? 0.10 : 0.21), in: RoundedRectangle(cornerRadius: 16))
            if !esMio { Spacer(minLength: 28) }
        }
    }

    private func colorRol(_ rol: Rol) -> Color {
        switch rol {
        case .juez: Oro.color(.juez)
        case .fiscal: Oro.color(.fiscal)
        case .defensa: .purple
        }
    }

    private func escritor(_ actor: ActorChat, acto: Acto) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            if modo != .mensaje {
                HStack {
                    Text(modo == .preguntaObjetiva ? "Pregunta de sí o no" : "Pregunta abierta")
                        .font(.caption.bold())
                    Spacer()
                    Button("Cancelar pregunta") { modo = .mensaje }.font(.caption)
                }
            }
            HStack(alignment: .bottom, spacing: 9) {
                if actor.rol == .juez {
                    Menu {
                        Button("Hacer pregunta", systemImage: "questionmark.bubble") { modo = .pregunta }
                        Button("Pregunta objetiva · Sí o no", systemImage: "checkmark.circle") { modo = .preguntaObjetiva }
                        if acto.tipo == .minijuicio {
                            Button("Reprogramar", systemImage: "calendar.badge.clock") { cierreChat = .reprogramar }
                            Button("Condena o decisión del minijuicio", systemImage: "checkmark.seal") { cierreChat = .resolver }
                        } else {
                            Button("Cerrar audiencia", systemImage: "checkmark.seal") { cierreChat = .finalizar }
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill").font(.title2)
                    }
                    .accessibilityLabel("Acciones del juez")
                }
                TextField(modo == .mensaje ? "Intervención" : "Escribe la pregunta", text: $texto, axis: .vertical)
                    .lineLimit(1...5)
                    .padding(10)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
                Button {
                    enviar(actor)
                } label: {
                    Image(systemName: "arrow.up").font(.headline)
                }
                .buttonStyle(.glassProminent)
                .disabled(texto.limpio.isEmpty)
                .accessibilityLabel("Enviar intervención")
            }
        }
        .padding(10)
        .background(.regularMaterial)
    }

    private func enviar(_ actor: ActorChat) {
        let mensaje = Intervencion(rol: actor.rol, autor: actor.nombre, autorID: actor.id, tipo: modo, texto: texto.limpio)
        if archivo.editar(casoID, { $0.intervencion(mensaje, en: actoID) }) {
            texto = ""
            modo = .mensaje
        }
    }

    private func responder(_ si: Bool, pregunta: Intervencion, actor: ActorChat) {
        let resultado: Resultado = si ? .si : .no
        let mensaje = Intervencion(rol: actor.rol, autor: actor.nombre, autorID: actor.id, tipo: .respuestaObjetiva,
                                   texto: resultado.titulo, respuestaA: pregunta.id, resultado: resultado)
        archivo.editar(casoID) { $0.intervencion(mensaje, en: actoID) }
    }
}

private struct DecidirChat: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var cerrar
    let casoID: UUID
    let actoID: UUID
    let autor: String
    let titulo: String
    let reprogramar: Bool
    let votar: Bool
    let alCerrar: () -> Void
    @State private var fecha = Date()
    @State private var texto = ""
    @State private var votos: [Voto] = []

    var body: some View {
        if let caso = archivo.caso(casoID) {
            NavigationStack {
                Form {
                    if reprogramar { DatePicker("Nueva fecha", selection: $fecha, displayedComponents: [.date, .hourAndMinute]) }
                    TextField(reprogramar ? "Motivo de la reprogramación" : "Síntesis de lo decidido", text: $texto, axis: .vertical)
                        .lineLimit(4...10)
                    if votar {
                        Votacion(personas: caso.jueces, pregunta: "¿Se acredita la conducta?", votos: $votos)
                        if mayoria(votos) == .empate && votos.count == caso.jueces.count {
                            Text("El empate no cierra el minijuicio. Continúa la deliberación o reprograma.").font(.footnote)
                        }
                    }
                }
                .navigationTitle(titulo)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { cerrar() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Cerrar conversación") { terminar() }.disabled(!valido(caso))
                    }
                }
            }
        }
    }

    private func valido(_ caso: Caso) -> Bool {
        !texto.limpio.isEmpty && (!votar || (votos.count == caso.jueces.count && mayoria(votos) != .empate))
    }

    private func terminar() {
        let resultado: Resultado = reprogramar ? .reprogramado : votar ? (mayoria(votos) ?? .empate) : .realizado
        let decision = reprogramar ? "Reprogramado · " + fecha.formatted(date: .abbreviated, time: .shortened)
            : votar ? (resultado == .si ? "Condena del minijuicio · Conducta acreditada" : "Conducta no acreditada") : "Audiencia final cerrada"
        var guardado = false
        if archivo.editar(casoID, { guardado = $0.terminarAudiencia(actoID, votos: votos, resultado: resultado,
                                                                texto: texto.limpio, decision: decision, autor: autor) }), guardado {
            alCerrar()
            cerrar()
        }
    }
}

private struct ConsultaChat: View {
    @Environment(\.dismiss) private var cerrar
    let caso: Caso
    let acto: Acto

    var body: some View {
        NavigationStack {
            List {
                let material = acto.referencias.compactMap { caso.acto($0) }
                if !material.isEmpty {
                    Section("Actuaciones vinculadas") {
                        ForEach(material) { item in
                            NavigationLink(item.rotulo) { ActoDetalle(caso: caso, acto: item, modal: false) }
                        }
                    }
                }
                Section("Evidencias") {
                    ForEach(caso.evidencias) { item in
                        NavigationLink(item.rotulo) { ActoDetalle(caso: caso, acto: item, modal: false) }
                    }
                }
            }
            .navigationTitle("Material de la audiencia")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } } }
        }
    }
}
