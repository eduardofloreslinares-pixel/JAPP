import Foundation

struct TimelineEvent: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var hora: String?
    var titulo: String
    var descripcion: String
    var tipo: String
    var autor: String?
}

struct PruebaElemento: Codable, Equatable, Identifiable {
    var id: String
    var tipo: String
    var titulo: String
    var descripcion: String
    var fechaRecabada: String
    var origen: String
    var pertinencia: String
    var admitidaPJ: Bool?
}

struct DiligenciaFiscal: Codable, Equatable, Identifiable {
    var id: String
    var titulo: String
    var tipo: String
    var fecha: String
    var detalles: String
    var resultado: String
    var responsable: String
}

struct ConductaImputada: Codable, Equatable, Identifiable {
    var id: String
    var imputadoNombre: String
    var descripcionConducta: String
    var tipificacionLegal: String
    var gravedad: String
    var pruebasAsociadasIds: [String]
}

struct AudienciaSubcaso: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var tipo: String
    var alegatoFiscalia: String
    var alegatoDefensa: String
    var conclusionesJuez: String?
}

struct SubcasoIntermedio: Codable, Equatable, Identifiable {
    var id: String
    var conductaId: String
    var titulo: String
    var imputadoNombre: String
    var conductaDescripcion: String
    var tipificacionLegal: String
    var pruebasAsignadas: [PruebaElemento]
    var audiencias: [AudienciaSubcaso]
    var estado: String
    var motivacionDecision: String?
    var fechaResolucion: String?
    var juezResolutor: String?
    var audienciasAntesDeRevision: Int?
    var borrador: BorradorResolucion?
    var referenciasResolucion: [String]?
}

struct BorradorResolucion: Codable, Equatable {
    var resultado: String = "procede_juicio"
    var motivos: String = ""
    var referencias: Set<String> = []
}

struct PeticionFiscal: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var tipo: String
    var titulo: String
    var fundamentacion: String
    var estado: String
    var respuestaJuez: String?
    var nuevaPrueba: PruebaElemento?
}

struct AlegatoJuicio: Codable, Equatable {
    var tipo: String
    var fiscalia: String
    var defensa: String
    var fecha: String
}

struct Pena: Codable, Equatable {
    var imputadoNombre: String
    var penaAnios: Double
    var tipoPena: String
    var inhabilitacionMeses: Double?
}

struct SentenciaData: Codable, Equatable {
    var fecha: String
    var fallo: String
    var penasImputados: [Pena]
    var reparacionCivilMonto: Double
    var reparacionCivilBeneficiario: String
    var fundamentacionJuridica: String
    var juezSentenciador: String
}

struct ApelacionRecord: Codable, Equatable {
    var numeroApelacion: Int
    var fechaInterposicion: String
    var quienApela: String
    var motivosAgravios: String
    var juecesSalaApelaciones: [String]
    var admisibilidadUltima: String?
    var estado: String
    var resolucionSala: String?
    var falloApelacion: String?
}

struct SujetosProcesales: Codable, Equatable {
    var fiscalProvincial: String
    var fiscalAdjunto: String
    var juezInvestigacionPreparatoria: String
    var juezJuicioOral: String
    var juecesApelacionInstancia1: [String]
    var juecesApelacionInstancia2: [String]
    var juecesApelacionInstancia3: [String]
    var abogadoDefensa: String
    var peritoOficial: String
}

struct Acusacion: Codable, Equatable {
    var fecha: String
    var pretensionPunitiva: String
    var reparacionCivilSolicitada: Double
    var fundamentosAcusacion: String
    var fiscalEmisor: String
}

struct ControlAcusacion: Codable, Equatable {
    var fecha: String
    var decision: String
    var motivoDevolucion: String?
    var fundamentacionAceptacion: String?
    var juezEvaluador: String
}

struct CasoJusticia: Codable, Equatable, Identifiable {
    var id: String
    var numeroExpediente: String
    var etapaActual: String
    var queOcurrio: String
    var cuando: String
    var donde: String
    var como: String
    var delitoImputado: String
    var presuntosResponsables: [String]
    var presuntaVictima: String
    var descripcionHechos: String
    var lineaTemporal: [TimelineEvent]
    var sujetos: SujetosProcesales
    var diligenciasPreliminares: [DiligenciaFiscal]
    var pruebasRecabadas: [PruebaElemento]
    var evaluacionPreliminar: String
    var decisionPreliminar: String?
    var fundamentacionPreliminar: String?
    var conductas: [ConductaImputada]
    var diligenciasPreparatorias: [DiligenciaFiscal]
    var acusacionFiscal: Acusacion?
    var evaluacionAcusacionPJ: ControlAcusacion?
    var peticionesFiscales: [PeticionFiscal]
    var subcasos: [SubcasoIntermedio]
    var alegatosApertura: AlegatoJuicio?
    var alegatosClausura: AlegatoJuicio?
    var evaluacionAlegatosJuez: String?
    var sentencia: SentenciaData?
    var sentenciasAnteriores: [SentenciaData]?
    var apelaciones: [ApelacionRecord]
    var apelacionActualIndex: Int
    var casoCerradoDefinitivo: Bool
    var fechaCierreDefinitivo: String?
}

enum Etapa: String, CaseIterable {
    case preliminar = "investigacion_preliminar"
    case preparatoria = "investigacion_preparatoria"
    case control = "acusacion_enviada"
    case intermedia = "etapa_intermedia"
    case juicio = "juicio_oral"
    case sentencia = "sentencia_dictada"
    case resuelto = "caso_resuelto_definitivo"

    var titulo: String {
        switch self {
        case .preliminar: "Investigación preliminar"
        case .preparatoria: "Investigación preparatoria"
        case .control: "Control de acusación"
        case .intermedia: "Etapa intermedia"
        case .juicio: "Juicio oral"
        case .sentencia: "Sentencia"
        case .resuelto: "Cierre definitivo"
        }
    }
}

extension CasoJusticia {
    var etapa: Etapa {
        get { Etapa(rawValue: etapaActual) ?? .preliminar }
        set { etapaActual = newValue.rawValue }
    }
    var cerrado: Bool { casoCerradoDefinitivo || etapa == .resuelto }
    var devuelto: Bool { evaluacionAcusacionPJ?.decision == "devolver" }
    var fiscalEdita: Bool { !cerrado && (etapa == .preliminar || etapa == .preparatoria || (etapa == .control && devuelto)) }
    var judicializado: Bool { !fiscalEdita && !cerrado }
    var pendientes: Int { peticionesFiscales.filter { $0.estado == "pendiente" }.count }
    var numeroApelaciones: Int { max(apelacionActualIndex, apelaciones.map(\.numeroApelacion).max() ?? 0) }
    var salaActual: [String] { apelaciones.last(where: { $0.estado == "en_tramite" })?.juecesSalaApelaciones ?? [] }
    var juezIntermedio: String { salaActual.isEmpty ? sujetos.juezInvestigacionPreparatoria : salaActual.joined(separator: ", ") }
    var juezOral: String { salaActual.isEmpty ? sujetos.juezJuicioOral : salaActual.joined(separator: ", ") }

    mutating func registrar(_ titulo: String, _ detalle: String, tipo: String = "resolucion", autor: String = "") {
        lineaTemporal.append(.init(id: nuevoID(), fecha: hoy(), hora: Date.now.formatted(date: .omitted, time: .shortened), titulo: titulo, descripcion: detalle, tipo: tipo, autor: autor))
    }

    mutating func admitirAcusacion(_ motivo: String) {
        evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "aceptar", fundamentacionAceptacion: motivo, juezEvaluador: sujetos.juezInvestigacionPreparatoria)
        subcasos = conductas.enumerated().map { indice, conducta in
            let vinculadas = pruebasRecabadas.filter { conducta.pruebasAsociadasIds.contains($0.id) }
            return SubcasoIntermedio(id: nuevoID(), conductaId: conducta.id,
                titulo: "Subcaso \(indice + 1) · \(conducta.imputadoNombre)", imputadoNombre: conducta.imputadoNombre,
                conductaDescripcion: conducta.descripcionConducta, tipificacionLegal: conducta.tipificacionLegal,
                pruebasAsignadas: vinculadas.isEmpty ? pruebasRecabadas : vinculadas, audiencias: [], estado: "pendiente")
        }
        etapa = .intermedia
        registrar("Acusación admitida", motivo, autor: sujetos.juezInvestigacionPreparatoria)
    }

    mutating func cerrar(_ motivo: String) {
        etapa = .resuelto
        casoCerradoDefinitivo = true
        fechaCierreDefinitivo = hoy()
        registrar("Cierre definitivo", motivo, autor: juezOral)
    }

    mutating func presentarRecurso(parte: String, motivo: String) {
        let numero = numeroApelaciones + 1
        guard etapa == .sentencia, numero <= 3, !cerrado else { return }
        let salas = [sujetos.juecesApelacionInstancia1, sujetos.juecesApelacionInstancia2, sujetos.juecesApelacionInstancia3]
        apelacionActualIndex = numero
        apelaciones.append(.init(numeroApelacion: numero, fechaInterposicion: hoy(), quienApela: parte,
            motivosAgravios: motivo, juecesSalaApelaciones: salas[numero - 1],
            admisibilidadUltima: numero == 3 ? "pendiente" : nil, estado: "en_tramite"))
        registrar("Apelación \(numero)", motivo, tipo: "apelacion", autor: parte)
        if numero < 3 { reabrirSubcasos() }
    }

    mutating func revisarUltimoRecurso(admitir: Bool, motivo: String) {
        guard let i = apelaciones.indices.last, apelaciones[i].admisibilidadUltima == "pendiente" else { return }
        apelaciones[i].admisibilidadUltima = admitir ? "admitida" : "inadmisible"
        apelaciones[i].resolucionSala = motivo
        registrar(admitir ? "Última apelación admitida" : "Última apelación inadmisible", motivo, tipo: "apelacion", autor: juezOral)
        if admitir { reabrirSubcasos() }
        else {
            apelaciones[i].estado = "resuelta"
            apelaciones[i].falloApelacion = "confirma"
            cerrar(motivo)
        }
    }

    private mutating func reabrirSubcasos() {
        etapa = .intermedia
        alegatosApertura = nil
        alegatosClausura = nil
        evaluacionAlegatosJuez = nil
        for i in subcasos.indices {
            subcasos[i].audienciasAntesDeRevision = subcasos[i].audiencias.count
            subcasos[i].estado = "pendiente"
            subcasos[i].motivacionDecision = nil
            subcasos[i].fechaResolucion = nil
            subcasos[i].juezResolutor = nil
            subcasos[i].borrador = nil
            subcasos[i].referenciasResolucion = nil
        }
    }

    mutating func incorporar(_ prueba: PruebaElemento) {
        guard !pruebasRecabadas.contains(where: { $0.id == prueba.id }) else { return }
        pruebasRecabadas.append(prueba)
    }
}

func nuevoID() -> String { UUID().uuidString }
func hoy() -> String { Date.now.formatted(.dateTime.day().month().year().locale(Locale(identifier: "es_PE"))) }

func rotulo(_ clave: String) -> String {
    let nombres = ["prision_preventiva": "Prisión preventiva", "incorporar_prueba": "Incorporar prueba",
                   "medida_cautelar": "Medida cautelar", "debate_probatorio": "Debate probatorio",
                   "procede_juicio": "Procede a juicio", "excluido_ilicitud": "Exclusión por ilicitud",
                   "supuestos": "Supuestos", "resolucion": "Resolución", "inspeccion": "Inspección",
                   "declaracion": "Declaración", "apelacion": "Apelación", "reprogramacion": "Reprogramación",
                   "ambas_partes": "Ambas partes", "fiscalia": "Fiscalía", "muy_grave": "Muy grave",
                   "anula_y_reordena": "Anula y reordena"]
    return nombres[clave] ?? clave.replacingOccurrences(of: "_", with: " ").capitalized
}
