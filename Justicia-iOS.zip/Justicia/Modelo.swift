import Foundation

struct TimelineEvent: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var hora: String?
    var titulo: String
    var descripcion: String
    var tipo: String
    var autor: String?
}

struct PruebaElemento: Codable, Equatable, Identifiable {
    var id: String
    var tipo: String
    var titulo: String
    var descripcion: String
    var fechaRecabada: String
    var origen: String
    var pertinencia: String
    var admitidaPJ: Bool?
}

struct DiligenciaFiscal: Codable, Equatable, Identifiable {
    var id: String
    var titulo: String
    var tipo: String
    var fecha: String
    var detalles: String
    var resultado: String
    var responsable: String
}

struct ConductaImputada: Codable, Equatable, Identifiable {
    var id: String
    var imputadoNombre: String
    var descripcionConducta: String
    var tipificacionLegal: String
    var gravedad: String
    var pruebasAsociadasIds: [String]
}

struct AudienciaSubcaso: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var tipo: String
    var alegatoFiscalia: String
    var alegatoDefensa: String
    var conclusionesJuez: String?
}

struct PreguntaJudicial: Codable, Equatable, Identifiable {
    var id = nuevoID()
    var pregunta: String
    var fiscalia: String?
    var contraparte: String?
    var evaluacion: String?

    var completa: Bool {
        [fiscalia, contraparte, evaluacion].allSatisfy { !($0 ?? "").isEmpty }
    }
}

struct DiligenciaEspecial: Codable, Equatable, Identifiable {
    var id = nuevoID()
    var orden: String
    var resultado: String?
}

struct Afectacion: Codable, Equatable, Identifiable {
    var id = nuevoID()
    var titulo: String
    var desarrollo: String
    var pruebas: [String]
}

enum PreguntaInicial: String, CaseIterable, Identifiable {
    case que, quien, cuando, donde, porque, como
    var id: String { rawValue }
    var titulo: String {
        switch self {
        case .que: "¿Qué ocurrió?"
        case .quien: "¿Quién intervino?"
        case .cuando: "¿Cuándo?"
        case .donde: "¿Dónde?"
        case .porque: "¿Por qué?"
        case .como: "¿Cómo?"
        }
    }

    func respuesta(en caso: CasoJusticia) -> String {
        switch self {
        case .que: caso.queOcurrio
        case .quien: caso.presuntosResponsables.joined(separator: ", ")
        case .cuando: caso.cuando
        case .donde: caso.donde
        case .porque: caso.porQue ?? ""
        case .como: caso.como
        }
    }
}

struct SubcasoIntermedio: Codable, Equatable, Identifiable {
    var id: String
    var conductaId: String
    var titulo: String
    var imputadoNombre: String
    var conductaDescripcion: String
    var tipificacionLegal: String
    var pruebasAsignadas: [PruebaElemento]
    var audiencias: [AudienciaSubcaso]
    var estado: String
    var motivacionDecision: String?
    var fechaResolucion: String?
    var juezResolutor: String?
    var audienciasAntesDeRevision: Int?
    var borrador: BorradorResolucion?
    var referenciasResolucion: [String]?
    var preguntasJudiciales: [PreguntaJudicial]?
    var diligenciasEspeciales: [DiligenciaEspecial]?

    var listoParaResolver: Bool {
        guard let preguntas = preguntasJudiciales, !preguntas.isEmpty,
              preguntas.allSatisfy(\.completa) else { return false }
        return (diligenciasEspeciales ?? []).allSatisfy { !($0.resultado ?? "").isEmpty }
    }
}

struct BorradorResolucion: Codable, Equatable {
    var resultado: String = "acreditada"
    var motivos: String = ""
    var referencias: Set<String> = []
}

struct PeticionFiscal: Codable, Equatable, Identifiable {
    var id: String
    var fecha: String
    var tipo: String
    var titulo: String
    var fundamentacion: String
    var estado: String
    var respuestaJuez: String?
    var nuevaPrueba: PruebaElemento?
}

struct AlegatoJuicio: Codable, Equatable {
    var tipo: String
    var fiscalia: String
    var defensa: String
    var fecha: String
}

struct Pena: Codable, Equatable {
    var imputadoNombre: String
    var penaAnios: Double
    var tipoPena: String
    var inhabilitacionMeses: Double?
}

struct SentenciaData: Codable, Equatable {
    var fecha: String
    var fallo: String
    var penasImputados: [Pena]
    var reparacionCivilMonto: Double
    var reparacionCivilBeneficiario: String
    var fundamentacionJuridica: String
    var juezSentenciador: String
}

struct ApelacionRecord: Codable, Equatable {
    var numeroApelacion: Int
    var fechaInterposicion: String
    var quienApela: String
    var motivosAgravios: String
    var juecesSalaApelaciones: [String]
    var admisibilidadUltima: String?
    var estado: String
    var resolucionSala: String?
    var falloApelacion: String?
    var evaluacionActuados: String?
    var falloImpugnado: String?
}

struct SujetosProcesales: Codable, Equatable {
    var fiscalProvincial: String
    var fiscalAdjunto: String
    var juezInvestigacionPreparatoria: String
    var juezJuicioOral: String
    var juecesApelacionInstancia1: [String]
    var juecesApelacionInstancia2: [String]
    var juecesApelacionInstancia3: [String]
    var abogadoDefensa: String
    var peritoOficial: String
}

struct Acusacion: Codable, Equatable {
    var fecha: String
    var pretensionPunitiva: String
    var reparacionCivilSolicitada: Double
    var fundamentosAcusacion: String
    var fiscalEmisor: String
}

struct ControlAcusacion: Codable, Equatable {
    var fecha: String
    var decision: String
    var motivoDevolucion: String?
    var fundamentacionAceptacion: String?
    var juezEvaluador: String
}

struct CasoJusticia: Codable, Equatable, Identifiable {
    var id: String
    var numeroExpediente: String
    var etapaActual: String
    var queOcurrio: String
    var cuando: String
    var donde: String
    var como: String
    var delitoImputado: String
    var presuntosResponsables: [String]
    var presuntaVictima: String
    var descripcionHechos: String
    var porQue: String?
    var evaluacionesPorPregunta: [String: String]?
    var afectaciones: [Afectacion]?
    var decisionAcusar: String?
    var referenciasAudienciaFinal: [String]?
    var recursoConstitucional: ApelacionRecord?
    var lineaTemporal: [TimelineEvent]
    var sujetos: SujetosProcesales
    var diligenciasPreliminares: [DiligenciaFiscal]
    var pruebasRecabadas: [PruebaElemento]
    var evaluacionPreliminar: String
    var decisionPreliminar: String?
    var fundamentacionPreliminar: String?
    var conductas: [ConductaImputada]
    var diligenciasPreparatorias: [DiligenciaFiscal]
    var acusacionFiscal: Acusacion?
    var evaluacionAcusacionPJ: ControlAcusacion?
    var peticionesFiscales: [PeticionFiscal]
    var subcasos: [SubcasoIntermedio]
    var alegatosApertura: AlegatoJuicio?
    var alegatosClausura: AlegatoJuicio?
    var evaluacionAlegatosJuez: String?
    var sentencia: SentenciaData?
    var sentenciasAnteriores: [SentenciaData]?
    var apelaciones: [ApelacionRecord]
    var apelacionActualIndex: Int
    var casoCerradoDefinitivo: Bool
    var fechaCierreDefinitivo: String?
}

enum Etapa: String, CaseIterable {
    case preliminar = "investigacion_preliminar"
    case preparatoria = "investigacion_preparatoria"
    case control = "acusacion_enviada"
    case intermedia = "etapa_intermedia"
    case juicio = "juicio_oral"
    case sentencia = "sentencia_dictada"
    case resuelto = "caso_resuelto_definitivo"

    var titulo: String {
        switch self {
        case .preliminar: "Investigación preliminar"
        case .preparatoria: "Acusación"
        case .control: "Etapa preparatoria"
        case .intermedia: "Juicio oral"
        case .juicio: "Juicio oral"
        case .sentencia: "Sentencia"
        case .resuelto: "Cierre definitivo"
        }
    }
}

extension CasoJusticia {
    var etapa: Etapa {
        get {
            let guardada = Etapa(rawValue: etapaActual) ?? .preliminar
            return guardada == .intermedia ? .juicio : guardada
        }
        set { etapaActual = newValue.rawValue }
    }
    var cerrado: Bool { casoCerradoDefinitivo || etapa == .resuelto }
    var devuelto: Bool { evaluacionAcusacionPJ?.decision == "devolver" }
    var fiscalEdita: Bool { !cerrado && (etapa == .preliminar || etapa == .preparatoria || (etapa == .control && devuelto)) }
    var judicializado: Bool { !fiscalEdita && !cerrado }
    var etapaFlujograma: Int {
        if etapa == .resuelto, sentencia == nil {
            return decisionPreliminar == "archivar" ? 0 : 1
        }
        switch etapa {
        case .preliminar: return 0
        case .preparatoria: return 1
        case .control: return 2
        case .intermedia, .juicio: return 3
        case .sentencia, .resuelto: return 4
        }
    }
    var conductasResueltas: Bool { !subcasos.isEmpty && subcasos.allSatisfy { $0.estado != "pendiente" } }
    var puedeSentenciar: Bool {
        etapa == .juicio && !cerrado && conductasResueltas && alegatosClausura != nil
            && !(evaluacionAlegatosJuez ?? "").isEmpty
    }
    var recursoPendiente: ApelacionRecord? { apelaciones.last(where: { $0.estado == "en_tramite" }) }
    var puedeRecurrirTC: Bool {
        etapa == .sentencia && !cerrado && numeroApelaciones >= 1 && recursoPendiente == nil && recursoConstitucional == nil
    }
    var pendientes: Int { peticionesFiscales.filter { $0.estado == "pendiente" }.count }
    var numeroApelaciones: Int { max(apelacionActualIndex, apelaciones.map(\.numeroApelacion).max() ?? 0) }
    var salaActual: [String] { apelaciones.last(where: { $0.estado == "en_tramite" })?.juecesSalaApelaciones ?? [] }
    var juezIntermedio: String { salaActual.isEmpty ? sujetos.juezInvestigacionPreparatoria : salaActual.joined(separator: ", ") }
    var juezOral: String { salaActual.isEmpty ? sujetos.juezJuicioOral : salaActual.joined(separator: ", ") }

    mutating func registrar(_ titulo: String, _ detalle: String, tipo: String = "resolucion", autor: String = "") {
        lineaTemporal.append(.init(id: nuevoID(), fecha: hoy(), hora: Date.now.formatted(date: .omitted, time: .shortened), titulo: titulo, descripcion: detalle, tipo: tipo, autor: autor))
    }

    mutating func admitirAcusacion(_ motivo: String) {
        guard etapa == .control, !devuelto, !cerrado, acusacionFiscal != nil, !conductas.isEmpty else { return }
        evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "aceptar", fundamentacionAceptacion: motivo, juezEvaluador: sujetos.juezInvestigacionPreparatoria)
        subcasos = conductas.enumerated().map { indice, conducta in
            let vinculadas = pruebasRecabadas.filter { conducta.pruebasAsociadasIds.contains($0.id) }
            return SubcasoIntermedio(id: nuevoID(), conductaId: conducta.id,
                titulo: "Subcaso \(indice + 1) · \(conducta.imputadoNombre)", imputadoNombre: conducta.imputadoNombre,
                conductaDescripcion: conducta.descripcionConducta, tipificacionLegal: conducta.tipificacionLegal,
                pruebasAsignadas: vinculadas.isEmpty ? pruebasRecabadas : vinculadas, audiencias: [], estado: "pendiente")
        }
        etapa = .juicio
        registrar("Acusación admitida", motivo, autor: sujetos.juezInvestigacionPreparatoria)
        registrar("Juicio oral abierto", "Se abre el examen individual de las conductas.", tipo: "audiencia", autor: juezOral)
    }

    mutating func cerrar(_ motivo: String) {
        etapa = .resuelto
        casoCerradoDefinitivo = true
        fechaCierreDefinitivo = hoy()
        registrar("Cierre definitivo", motivo, autor: sentencia == nil ? sujetos.fiscalProvincial : juezOral)
    }

    mutating func presentarRecurso(parte: String, motivo: String) {
        let numero = numeroApelaciones + 1
        guard etapa == .sentencia, sentencia != nil, numero <= 2, recursoPendiente == nil, recursoConstitucional == nil, !cerrado else { return }
        let sala = numero == 1 ? sujetos.juecesApelacionInstancia1 : sujetos.juecesApelacionInstancia2
        let impugnado = ultimoFallo
        apelacionActualIndex = numero
        apelaciones.append(.init(numeroApelacion: numero, fechaInterposicion: hoy(), quienApela: parte,
            motivosAgravios: motivo, juecesSalaApelaciones: sala, estado: "en_tramite", falloImpugnado: impugnado))
        registrar("Apelación \(numero)", motivo, tipo: "apelacion", autor: parte)
    }

    mutating func resolverRecurso(evaluacion: String, fallo: String, fundamento: String) {
        guard etapa == .sentencia, !cerrado, !evaluacion.isEmpty, !fundamento.isEmpty,
              let indice = apelaciones.lastIndex(where: { $0.estado == "en_tramite" }) else { return }
        let sala = apelaciones[indice].juecesSalaApelaciones.joined(separator: ", ")
        apelaciones[indice].evaluacionActuados = evaluacion
        apelaciones[indice].falloApelacion = fallo
        apelaciones[indice].resolucionSala = fundamento
        apelaciones[indice].estado = "resuelta"
        registrar("Fallo de apelación · " + rotulo(fallo), fundamento, tipo: "apelacion", autor: sala)
    }

    mutating func presentarRecursoTC(parte: String, motivo: String) {
        guard puedeRecurrirTC else { return }
        let impugnado = ultimoFallo
        recursoConstitucional = .init(numeroApelacion: 0, fechaInterposicion: hoy(), quienApela: parte,
            motivosAgravios: motivo, juecesSalaApelaciones: [], estado: "en_tramite", falloImpugnado: impugnado)
        registrar("Recurso al Tribunal Constitucional", motivo, tipo: "apelacion", autor: parte)
    }

    private var ultimoFallo: String {
        if let anterior = apelaciones.last(where: { $0.estado == "resuelta" }) {
            return "Fallo de apelación \(anterior.numeroApelacion) · " + rotulo(anterior.falloApelacion ?? "resuelta")
                + "\n" + (anterior.resolucionSala ?? "")
        }
        guard let sentencia else { return "" }
        return "Sentencia · " + rotulo(sentencia.fallo) + "\n" + sentencia.fundamentacionJuridica
    }

    mutating func resolverRecursoTC(fallo: String, fundamento: String) {
        guard recursoConstitucional?.estado == "en_tramite", !cerrado else { return }
        recursoConstitucional?.falloApelacion = fallo
        recursoConstitucional?.resolucionSala = fundamento
        recursoConstitucional?.estado = "resuelta"
        registrar("Decisión del Tribunal Constitucional · " + rotulo(fallo), fundamento,
                  tipo: "apelacion", autor: "Tribunal Constitucional")
    }

    mutating func incorporar(_ prueba: PruebaElemento) {
        guard !pruebasRecabadas.contains(where: { $0.id == prueba.id }) else { return }
        pruebasRecabadas.append(prueba)
    }
}

func nuevoID() -> String { UUID().uuidString }
func hoy() -> String { Date.now.formatted(.dateTime.day().month().year().locale(Locale(identifier: "es_PE"))) }

func rotulo(_ clave: String) -> String {
    let nombres = ["prision_preventiva": "Prisión preventiva", "incorporar_prueba": "Incorporar prueba",
                   "medida_cautelar": "Medida cautelar", "debate_probatorio": "Debate probatorio",
                   "procede_juicio": "Procede a juicio", "acreditada": "Acreditada", "no_acreditada": "No acreditada", "excluido_ilicitud": "Exclusión por ilicitud",
                   "supuestos": "Supuestos", "resolucion": "Resolución", "inspeccion": "Inspección",
                   "declaracion": "Declaración", "apelacion": "Apelación", "reprogramacion": "Reprogramación",
                   "ambas_partes": "Ambas partes", "fiscalia": "Fiscalía", "muy_grave": "Muy grave",
                   "anula_y_reordena": "Anula y reordena"]
    return nombres[clave] ?? clave.replacingOccurrences(of: "_", with: " ").capitalized
}
