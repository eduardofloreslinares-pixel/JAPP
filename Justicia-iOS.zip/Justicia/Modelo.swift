import Foundation

enum Area: String, Codable, CaseIterable, Identifiable {
    case fiscal, juez
    var id: String { rawValue }
    var titulo: String { self == .fiscal ? "Fiscalía" : "Juez" }
    var icono: String { self == .fiscal ? "person.badge.shield.checkmark" : "building.columns" }
}

enum Etapa: String, Codable, CaseIterable {
    case preliminar, acusacion, preparatoria, juicio, sentencia
    var titulo: String {
        switch self {
        case .preliminar: "Investigación preliminar"
        case .acusacion: "Acusación"
        case .preparatoria: "Etapa preparatoria"
        case .juicio: "Juicio oral"
        case .sentencia: "Sentencia y recursos"
        }
    }
    var breve: String {
        switch self {
        case .preliminar: "Preliminar"
        case .acusacion: "Acusación"
        case .preparatoria: "Preparatoria"
        case .juicio: "Juicio oral"
        case .sentencia: "Sentencia"
        }
    }
}

enum Pregunta: String, Codable, CaseIterable, Identifiable {
    case quien, que, como, cuando, donde, porque
    var id: String { rawValue }
    var titulo: String {
        switch self {
        case .quien: "¿Quién?"
        case .que: "¿Qué?"
        case .como: "¿Cómo?"
        case .cuando: "¿Cuándo?"
        case .donde: "¿Dónde?"
        case .porque: "¿Por qué?"
        }
    }
    var pista: String {
        switch self {
        case .quien: "Identifica a las personas involucradas."
        case .que: "Describe el hecho investigado."
        case .como: "Cuenta cómo habría sucedido."
        case .cuando: "Indica la fecha, la hora o el periodo."
        case .donde: "Identifica el lugar de los hechos."
        case .porque: "Explica el posible motivo o indica si se desconoce."
        }
    }
}

enum TipoActo: String, Codable {
    case hecho, evidencia, evaluacionFiscal, apertura, afectacion, conducta, acusacion, control
    case minijuicio, audienciaFinal, sentencia, recurso, revision, constitucional, falloTC
    case comunicado, objetiva, diligencia, cierre

    var icono: String {
        switch self {
        case .hecho, .objetiva: "questionmark.bubble"
        case .evidencia: "photo.on.rectangle.angled"
        case .evaluacionFiscal, .control, .revision: "checklist"
        case .apertura, .acusacion: "arrow.turn.up.right"
        case .conducta, .afectacion: "person.text.rectangle"
        case .minijuicio, .audienciaFinal: "bubble.left.and.bubble.right"
        case .sentencia, .falloTC: "checkmark.seal"
        case .recurso, .constitucional: "arrow.uturn.up"
        case .comunicado: "megaphone"
        case .diligencia: "list.clipboard"
        case .cierre: "lock"
        }
    }
}

enum Resultado: String, Codable, CaseIterable, Identifiable {
    case si, no, empate, reprogramado, realizado

    var id: String { rawValue }
    var titulo: String {
        switch self {
        case .si: "Sí"
        case .no: "No"
        case .empate: "Empate"
        case .reprogramado: "Reprogramado"
        case .realizado: "Realizado"
        }
    }
}

struct Persona: Codable, Equatable, Identifiable {
    var id = UUID()
    var nombre: String
}

struct Voto: Codable, Equatable, Identifiable {
    var id: UUID
    var juez: String
    var aFavor: Bool
    var fundamento: String
}

struct Evaluacion: Codable, Equatable, Identifiable {
    var id: UUID
    var titulo: String
    var texto: String
}

enum Rol: String, Codable, CaseIterable {
    case fiscal, defensa, juez
    var titulo: String {
        switch self {
        case .fiscal: "Fiscalía"
        case .defensa: "Contraparte"
        case .juez: "Juez"
        }
    }
}

struct Intervencion: Codable, Equatable, Identifiable {
    enum Tipo: String, Codable {
        case mensaje, pregunta, preguntaObjetiva, respuestaObjetiva, cierre
    }
    var id = UUID()
    var fecha = Date()
    var rol: Rol
    var autor: String
    var autorID: String? = nil
    var tipo: Tipo
    var texto: String
    var respuestaA: UUID? = nil
    var resultado: Resultado? = nil
}

struct Acto: Codable, Equatable, Identifiable {
    var id = UUID()
    var numero: Int = 0
    var fecha = Date()
    var area: Area
    var tipo: TipoActo
    var titulo: String
    var texto: String = ""
    var pregunta: Pregunta? = nil
    var resultado: Resultado? = nil
    var decision: String? = nil
    var referencias: [UUID] = []
    var evaluaciones: [Evaluacion] = []
    var votos: [Voto] = []
    var foto: Data? = nil
    var conducta: UUID? = nil
    var mensajes: [Intervencion] = []
    var cerrada = false

    var audiencia: Bool { tipo == .minijuicio || tipo == .audienciaFinal }
    var rotulo: String { tipo == .evidencia ? "Evidencia N.º \(numero)" : titulo }
}

enum Accion: Hashable, Identifiable {
    case hecho(Pregunta), evidencia, evaluacionFiscal, apertura, afectacion, conducta, acusacion, control
    case minijuicio(UUID), audienciaFinal, sentencia, recurso, revision, constitucional, falloTC
    case comunicado, objetiva, diligencia, cierre

    var id: Self { self }

    func titulo(en caso: Caso) -> String {
        switch self {
        case .hecho(let pregunta): pregunta.titulo
        case .evidencia: "Añadir evidencia"
        case .evaluacionFiscal: "Evaluación fiscal"
        case .apertura: "¿Abrir investigación?"
        case .afectacion: "Posible afectación"
        case .conducta: "Registrar conducta"
        case .acusacion: "¿Acusar?"
        case .control: "Evaluar acusación"
        case .minijuicio(let conducta): "Minijuicio · " + (caso.acto(conducta)?.titulo ?? "Conducta")
        case .audienciaFinal: "Audiencia final · Alegatos"
        case .sentencia: "Dictar sentencia"
        case .recurso: caso.apelaciones == 0 ? "Apelar sentencia" : "Apelar el fallo"
        case .revision: "Evaluar actuaciones y fallar"
        case .constitucional: "Recurso constitucional"
        case .falloTC: "Registrar fallo constitucional"
        case .comunicado: "Comunicado o anuncio"
        case .objetiva: "Pregunta objetiva · Sí o no"
        case .diligencia: "Registrar diligencia"
        case .cierre: "Cerrar expediente"
        }
    }

    var icono: String {
        switch self {
        case .hecho, .objetiva: "questionmark.bubble"
        case .evidencia: "photo"
        case .evaluacionFiscal, .control, .revision: "checklist"
        case .apertura, .acusacion: "arrow.turn.up.right"
        case .afectacion, .conducta: "person.text.rectangle"
        case .minijuicio, .audienciaFinal: "bubble.left.and.bubble.right"
        case .sentencia, .falloTC: "checkmark.seal"
        case .recurso, .constitucional: "arrow.uturn.up"
        case .comunicado: "megaphone"
        case .diligencia: "list.clipboard"
        case .cierre: "lock"
        }
    }
}

struct Caso: Codable, Equatable, Identifiable {
    var id = UUID()
    var nombre: String
    var etapa: Etapa = .preliminar
    var cerrado = false
    var fiscales: [Persona] = [.init(nombre: "Fiscal titular")]
    var jueces: [Persona] = [.init(nombre: "Juez titular")]
    var actos: [Acto] = []

    var hechos: [Acto] { actos.filter { $0.tipo == .hecho } }
    var evidencias: [Acto] { actos.filter { $0.tipo == .evidencia } }
    var conductas: [Acto] { actos.filter { $0.tipo == .conducta } }
    var apelaciones: Int { actos.filter { $0.tipo == .recurso }.count }
    var recursoPendiente: Bool { apelaciones > actos.filter { $0.tipo == .revision && $0.resultado != .empate }.count }
    var constitucionalPresentado: Bool { actos.contains { $0.tipo == .constitucional } }
    var constitucionalPendiente: Bool { constitucionalPresentado && !actos.contains { $0.tipo == .falloTC && $0.resultado != .empate } }

    func acto(_ id: UUID) -> Acto? { actos.first { $0.id == id } }
    func resuelta(_ conducta: UUID) -> Bool {
        actos.contains { $0.tipo == .minijuicio && $0.conducta == conducta && $0.cerrada && [.si, .no].contains($0.resultado) }
    }

    func visibles(_ area: Area) -> [Acto] {
        actos.filter { $0.area == area || $0.tipo == .evidencia || $0.tipo == .acusacion || $0.tipo == .control }
    }

    func acciones(_ area: Area) -> [Accion] {
        guard !cerrado else { return [] }
        var lista: [Accion] = []
        if area == .fiscal {
            switch etapa {
            case .preliminar:
                lista = Pregunta.allCases.filter { pregunta in !hechos.contains { $0.pregunta == pregunta } }.map { .hecho($0) }
                if lista.isEmpty && !evidencias.isEmpty {
                    lista.append(actos.contains { $0.tipo == .evaluacionFiscal } ? .apertura : .evaluacionFiscal)
                }
                lista += [.evidencia, .diligencia]
            case .acusacion:
                lista = [.afectacion, .conducta, .evidencia, .diligencia, .acusacion]
            case .preparatoria, .juicio:
                lista = [.evidencia]
            case .sentencia:
                if !recursoPendiente && !constitucionalPresentado && apelaciones < 2 { lista.append(.recurso) }
                if apelaciones > 0 && !recursoPendiente && !constitucionalPresentado { lista.append(.constitucional) }
            }
        } else {
            switch etapa {
            case .preliminar, .acusacion: break
            case .preparatoria: lista = [.control, .evidencia]
            case .juicio:
                lista = conductas.filter { conducta in
                    !resuelta(conducta.id) && !actos.contains { $0.tipo == .minijuicio && $0.conducta == conducta.id && !$0.cerrada }
                }.map { .minijuicio($0.id) }
                if !conductas.isEmpty && conductas.allSatisfy({ resuelta($0.id) }) {
                    let final = actos.last { $0.tipo == .audienciaFinal }
                    if final == nil { lista.append(.audienciaFinal) }
                    else if final?.cerrada == true { lista.append(.sentencia) }
                }
                lista += [.evidencia, .diligencia]
            case .sentencia:
                if recursoPendiente { lista = [.revision] }
                else if constitucionalPendiente { lista = [.falloTC] }
                else { lista = [.cierre] }
            }
        }
        if !lista.contains(.evidencia) { lista.append(.evidencia) }
        return lista + [.comunicado, .objetiva]
    }

    func bloqueo(_ accion: Accion) -> String? {
        if accion == .acusacion && (conductas.isEmpty || evidencias.isEmpty) {
            return "Para acusar, registra al menos una conducta y una evidencia. También puedes decidir no acusar."
        }
        return nil
    }

    mutating func registrar(_ acto: Acto) -> UUID {
        var nuevo = acto
        let usados = Set(actos.map(\.numero))
        var numero = Int.random(in: 100000...999999)
        while usados.contains(numero) { numero = numero == 999999 ? 100000 : numero + 1 }
        nuevo.numero = numero
        actos.append(nuevo)
        return nuevo.id
    }

    mutating func aplicar(_ accion: Accion, acto: Acto) -> UUID? {
        guard acciones(acto.area).contains(accion) else { return nil }
        switch accion {
        case .apertura:
            guard acto.resultado == .si || acto.resultado == .no else { return nil }
            if acto.resultado == .si { etapa = .acusacion } else { cerrado = true }
        case .acusacion:
            guard acto.resultado == .si || acto.resultado == .no else { return nil }
            if acto.resultado == .si {
                guard bloqueo(accion) == nil else { return nil }
                etapa = .preparatoria
            } else { cerrado = true }
        case .control:
            guard [.si, .no, .empate].contains(acto.resultado) else { return nil }
            if acto.resultado == .si { etapa = .juicio }
            else if acto.resultado == .no { etapa = .acusacion }
        case .sentencia:
            guard [.si, .no, .empate].contains(acto.resultado) else { return nil }
            if acto.resultado != .empate { etapa = .sentencia }
        case .cierre: cerrado = true
        default: break
        }
        return registrar(acto)
    }

    mutating func intervencion(_ mensaje: Intervencion, en id: UUID) {
        guard !cerrado, let i = actos.firstIndex(where: { $0.id == id && $0.audiencia && !$0.cerrada }) else { return }
        if mensaje.tipo == .pregunta || mensaje.tipo == .preguntaObjetiva {
            guard mensaje.rol == .juez else { return }
        }
        if mensaje.tipo == .respuestaObjetiva {
            guard mensaje.rol != .juez, let autor = mensaje.autorID, let origen = mensaje.respuestaA,
                  actos[i].mensajes.contains(where: { $0.id == origen && $0.tipo == .preguntaObjetiva }),
                  !actos[i].mensajes.contains(where: { $0.autorID == autor && $0.respuestaA == origen }),
                  mensaje.resultado == .si || mensaje.resultado == .no else { return }
        }
        actos[i].mensajes.append(mensaje)
    }

    mutating func terminarAudiencia(_ id: UUID, votos: [Voto], resultado: Resultado, texto: String, decision: String, autor: String) -> Bool {
        guard !cerrado, etapa == .juicio,
              let i = actos.firstIndex(where: { $0.id == id && $0.audiencia && !$0.cerrada }) else { return false }
        if actos[i].tipo == .minijuicio {
            guard resultado == .reprogramado || (votos.count == jueces.count && mayoria(votos) == resultado && (resultado == .si || resultado == .no)) else { return false }
        } else if resultado != .realizado { return false }
        actos[i].votos = votos
        actos[i].resultado = resultado
        actos[i].texto = texto
        actos[i].decision = decision
        actos[i].cerrada = true
        actos[i].mensajes.append(.init(rol: .juez, autor: autor, tipo: .cierre, texto: decision + "\n" + texto, resultado: resultado))
        return true
    }
}

func mayoria(_ votos: [Voto]) -> Resultado? {
    guard !votos.isEmpty else { return nil }
    let si = votos.filter(\.aFavor).count
    let no = votos.count - si
    if si == no { return .empate }
    return si > no ? .si : .no
}
