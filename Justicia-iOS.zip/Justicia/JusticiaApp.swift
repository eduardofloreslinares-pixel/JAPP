import SwiftUI
import UniformTypeIdentifiers

@main
struct JusticiaApp: App {
    @StateObject private var archivo = Archivo()

    var body: some Scene {
        WindowGroup { Inicio().environmentObject(archivo) }
    }
}

enum Pestaña: Hashable { case fiscalia, judicial, expediente }

struct Inicio: View {
    @EnvironmentObject private var archivo: Archivo
    @State private var pestaña: Pestaña = .fiscalia
    @State private var bandeja = false
    @State private var consulta = false
    @State private var exportar = false
    @State private var documento = Documento()

    var body: some View {
        Group {
            if let caso = archivo.caso {
                TabView(selection: $pestaña) {
                    Tab("Fiscalía", systemImage: "shield.lefthalf.filled", value: .fiscalia) {
                        pagina("Fiscalía", caso: caso, color: .pink) { Fiscal(caso: caso, navegar: navegar) }
                    }
                    Tab("Poder Judicial", systemImage: "building.columns.fill", value: .judicial) {
                        pagina("Poder Judicial", caso: caso, color: .orange) { Judicial(caso: caso, navegar: navegar) }
                    }
                    .badge(caso.pendientes)
                    Tab("Expediente", systemImage: "doc.text", value: .expediente) {
                        pagina("Expediente", caso: caso, color: .indigo) { Expediente(caso: caso) }
                    }
                }
                .id(caso.id)
                .tint(pestaña == .fiscalia ? .pink : pestaña == .judicial ? .orange : .indigo)
            } else {
                Bandeja(cerrar: nil, abrir: { navegar(.fiscalia) })
            }
        }
        .sheet(isPresented: $bandeja) {
            Bandeja(cerrar: { bandeja = false }, abrir: {
                bandeja = false
                navegar(.fiscalia)
            })
        }
        .sheet(isPresented: $consulta) {
            if let caso = archivo.caso { ConsultaRapida(caso: caso) }
        }
        .fileExporter(isPresented: $exportar, document: documento, contentType: .json,
                      defaultFilename: "Expediente-Justicia") { resultado in
            if case .failure(let error) = resultado { archivo.error = error.localizedDescription }
        }
        .alert("Justicia", isPresented: Binding(get: { archivo.error != nil },
                                                set: { if !$0 { archivo.error = nil } })) {
            Button("Aceptar", role: .cancel) { archivo.error = nil }
        } message: { Text(archivo.error ?? "") }
    }

    private func navegar(_ destino: Pestaña) { pestaña = destino }

    private func pagina<Contenido: View>(_ titulo: String, caso: CasoJusticia, color: Color,
                                          @ViewBuilder contenido: () -> Contenido) -> some View {
        NavigationStack {
            contenido()
                .navigationTitle(titulo)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Expedientes", systemImage: "folder", action: { bandeja = true })
                            .labelStyle(.iconOnly)
                    }
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button("Buscar en el expediente", systemImage: "doc.text.magnifyingglass") { consulta = true }
                            .labelStyle(.iconOnly)
                        Button("Exportar expediente", systemImage: "square.and.arrow.up") {
                            do {
                                let encoder = JSONEncoder()
                                encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
                                documento = Documento(data: try encoder.encode(caso))
                                exportar = true
                            } catch {
                                archivo.error = "No se pudo exportar el expediente."
                            }
                        }
                        .labelStyle(.iconOnly)
                    }
                }
        }
        .tint(color)
    }
}

struct Documento: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data = Data()
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct Bandeja: View {
    @EnvironmentObject private var archivo: Archivo
    let cerrar: (() -> Void)?
    let abrir: () -> Void
    @State private var texto = ""
    @State private var formulario: Formulario?
    @State private var eliminar: CasoJusticia?

    private var filtrados: [CasoJusticia] {
        guard !texto.isEmpty else { return archivo.expedientes }
        return archivo.expedientes.filter {
            [$0.numeroExpediente, $0.delitoImputado, $0.queOcurrio, $0.presuntosResponsables.joined(separator: " ")]
                .contains { $0.localizedStandardContains(texto) }
        }
    }

    var body: some View {
        NavigationStack {
            List {
                if filtrados.isEmpty {
                    ContentUnavailableView(texto.isEmpty ? "Todavía no hay expedientes" : "Sin resultados",
                                           systemImage: "folder", description: Text(texto.isEmpty ? "Crea un expediente para comenzar." : "Prueba con otro término."))
                }
                ForEach(filtrados) { caso in
                    Button {
                        archivo.abrir(caso.id)
                        abrir()
                    } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(caso.numeroExpediente).font(.headline)
                            if !caso.delitoImputado.isEmpty {
                                Text(caso.delitoImputado).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                            }
                            HStack {
                                Etiqueta(texto: caso.etapa.titulo, color: .orange)
                                if caso.id == archivo.activo {
                                    Etiqueta(texto: "Abierto", color: .indigo)
                                }
                            }
                            RutaProcesal(avance: caso.etapaFlujograma, color: .orange)
                            Text("\(caso.pruebasRecabadas.count) pruebas · \(caso.subcasos.count) subcasos · \(caso.numeroApelaciones) recursos")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                    .contextMenu {
                        Button("Duplicar", systemImage: "plus.square.on.square") { nombrar(copia: caso) }
                        Button(role: .destructive) { eliminar = caso } label: { Label("Eliminar", systemImage: "trash") }
                    }
                }
            }
            .navigationTitle("Expedientes")
            .searchable(text: $texto, prompt: "Número, delito o imputado")
            .toolbar {
                if let cerrar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cerrar", action: cerrar) }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu("Añadir expediente", systemImage: "plus") {
                        Button("Nuevo expediente", systemImage: "doc.badge.plus") { nombrar() }
                        Button("Cargar ejemplo", systemImage: "sparkles") { nombrar(demo: true) }
                    }
                }
            }
            .sheet(item: $formulario) { Editor(formulario: $0) }
            .alert("¿Eliminar expediente?", isPresented: Binding(get: { eliminar != nil }, set: { if !$0 { eliminar = nil } })) {
                Button("Cancelar", role: .cancel) { eliminar = nil }
                Button("Eliminar", role: .destructive) {
                    if let eliminar { archivo.eliminar(eliminar.id) }
                    eliminar = nil
                }
            } message: { Text(eliminar?.numeroExpediente ?? "") }
        }
    }

    private func nombrar(copia: CasoJusticia? = nil, demo: Bool = false) {
        formulario = Formulario(titulo: copia != nil ? "Duplicar expediente" : demo ? "Cargar ejemplo" : "Nuevo expediente",
            campos: [.texto("numero", "Número o nombre", inicial: copia.map { $0.numeroExpediente + " · Copia" } ?? (demo ? "Caso de demostración" : ""))]) { valores in
            if let copia { archivo.duplicar(copia, como: valores["numero"]) }
            else { archivo.crear(valores["numero"], demo: demo) }
            abrir()
        }
    }
}
