import Combine
import SwiftUI
import UniformTypeIdentifiers

@main
struct JusticiaApp: App {
    var body: some Scene {
        WindowGroup { JusticiaScreen() }
    }
}

private enum Section: Int, CaseIterable {
    case fiscalia, judicial, expediente

    var title: String {
        switch self {
        case .fiscalia: "Fiscalía"
        case .judicial: "Poder Judicial"
        case .expediente: "Expediente"
        }
    }

    var icon: String {
        switch self {
        case .fiscalia: "shield.lefthalf.filled"
        case .judicial: "building.columns.fill"
        case .expediente: "doc.text.fill"
        }
    }

    var tint: Color {
        switch self {
        case .fiscalia: .pink
        case .judicial: .orange
        case .expediente: .indigo
        }
    }
}

private struct JusticiaScreen: View {
    @StateObject private var portal = JusticiaPortal()
    @State private var exporting = false
    @State private var document = CaseDocument()
    @State private var exportError: String?
    @Environment(\.colorScheme) private var theme

    private var canvas: Color {
        theme == .dark ? Color(red: 0.08, green: 0.08, blue: 0.13)
                       : Color(red: 0.95, green: 0.95, blue: 0.97)
    }

    var body: some View {
        VStack(spacing: 0) {
            header
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            ZStack {
                JusticiaWebView(portal: portal)
                if !portal.ready {
                    ProgressView("Abriendo Justicia")
                        .padding(20)
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22))
                }
            }
            tabBar
                .padding(.horizontal, 16)
                .padding(.top, 6)
                .padding(.bottom, 3)
        }
        .background(canvas.ignoresSafeArea())
        .onReceive(portal.exportEvents) { data in
            document = CaseDocument(data: data)
            exporting = true
        }
        .fileExporter(isPresented: $exporting, document: document, contentType: .json,
                      defaultFilename: "Expediente-Justicia") { result in
            if case .failure(let error) = result {
                exportError = error.localizedDescription
            }
        }
        .alert("No se pudo guardar el expediente", isPresented: Binding(
            get: { exportError != nil },
            set: { if !$0 { exportError = nil } }
        )) {
            Button("Aceptar", role: .cancel) { exportError = nil }
        } message: {
            Text(exportError ?? "")
        }
    }

    private var header: some View {
        GlassEffectContainer(spacing: 10) {
            HStack(spacing: 10) {
                Button { portal.openCases() } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "folder.fill")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Justicia").font(.headline.weight(.bold))
                            if !portal.title.isEmpty {
                                Text(portal.title)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(2)
                            }
                        }
                        Image(systemName: "chevron.down")
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 13)
                    .frame(minHeight: 48)
                    .padding(.vertical, 3)
                    .contentShape(Capsule())
                }
                .accessibilityHint("Abre la bandeja de expedientes")
                .buttonStyle(.plain)
                .glassEffect(.regular.interactive(), in: .capsule)

                Spacer(minLength: 0)

                Button { portal.exportCase() } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 17, weight: .semibold))
                        .frame(width: 48, height: 48)
                        .contentShape(Circle())
                }
                .accessibilityLabel("Exportar expediente")
                .buttonStyle(.plain)
                .glassEffect(.regular.interactive(), in: .circle)
            }
        }
        .disabled(!portal.ready)
    }

    private var tabBar: some View {
        HStack(spacing: 3) {
            ForEach(Section.allCases, id: \.rawValue) { section in
                let selected = portal.selected == section.rawValue
                let badge = portal.badges.indices.contains(section.rawValue) ? portal.badges[section.rawValue] : ""
                Button { portal.showTab(section.rawValue) } label: {
                    VStack(spacing: 3) {
                        Image(systemName: section.icon)
                            .font(.system(size: 19, weight: .medium))
                            .overlay(alignment: .topTrailing) {
                                if !badge.isEmpty {
                                    Text(badge)
                                        .font(.system(size: 8, weight: .bold))
                                        .foregroundStyle(.white)
                                        .padding(3)
                                        .background(.red, in: Circle())
                                        .offset(x: 10, y: -4)
                                }
                            }
                        Text(section.title)
                            .font(.caption2.weight(selected ? .semibold : .medium))
                            .multilineTextAlignment(.center)
                            .minimumScaleFactor(0.85)
                    }
                    .foregroundStyle(selected ? section.tint : Color.primary)
                    .padding(.vertical, 6)
                    .frame(maxWidth: .infinity, minHeight: 49)
                    .background(selected ? section.tint.opacity(0.14) : Color.clear, in: Capsule())
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(selected ? .isSelected : [])
                .accessibilityValue(badge)
            }
        }
        .padding(4)
        .frame(maxWidth: 490)
        .glassEffect(.regular.interactive(), in: .capsule)
        .disabled(!portal.ready)
    }
}

private struct CaseDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data = Data()

    init(data: Data = Data()) { self.data = data }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.data = data
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}
