import SwiftUI
import UIKit

@main
struct JusticiaApp: App {
    @StateObject private var archivo = Archivo()
    var body: some Scene {
        WindowGroup {
            Inicio().environmentObject(archivo)
        }
    }
}

enum Hoja: Identifiable {
    case casos, personas(Area), acciones, editor(Accion), detalle(UUID)
    var id: String {
        switch self {
        case .casos: "casos"
        case .personas(let area): "personas-" + area.rawValue
        case .acciones: "acciones"
        case .editor(let accion): "editor-" + String(describing: accion)
        case .detalle(let id): id.uuidString
        }
    }
}

struct Inicio: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.colorScheme) private var modo
    @State private var area: Area = .fiscal
    @State private var hoja: Hoja?
    @State private var borradorAccion: Accion?

    var body: some View {
        Group {
            if let caso = archivo.caso {
                tablero(caso)
            } else {
                Casos(inicial: true) { area = .fiscal; hoja = nil }
            }
        }
        .tint(Oro.acento)
        .sheet(item: $hoja, onDismiss: {
            if let accion = borradorAccion {
                borradorAccion = nil
                abrir(accion)
            }
        }) { destino in
            switch destino {
            case .casos:
                Casos { area = .fiscal; hoja = nil }
            case .personas(let rol):
                if let caso = archivo.caso { Personas(casoID: caso.id, area: rol) }
            case .acciones:
                if let caso = archivo.caso {
                    MenuActuaciones(caso: caso, area: area) { accion in
                        borradorAccion = accion
                        hoja = nil
                    }
                    .presentationDetents([.medium, .large])
                }
            case .editor(let accion):
                if let caso = archivo.caso {
                    Editor(casoID: caso.id, area: area, accion: accion) { _ in
                        hoja = nil
                        if accion == .acusacion, archivo.caso?.etapa == .preparatoria { area = .juez }
                        if accion == .control, archivo.caso?.etapa == .acusacion { area = .fiscal }
                    }
                }
            case .detalle(let id):
                if let caso = archivo.caso, let acto = caso.acto(id) {
                    if acto.audiencia { Chat(casoID: caso.id, actoID: id) }
                    else { ActoDetalle(caso: caso, acto: acto) }
                }
            }
        }
        .alert("Justicia", isPresented: Binding(get: { archivo.error != nil }, set: { if !$0 { archivo.error = nil } })) {
            Button("Aceptar", role: .cancel) { archivo.error = nil }
        } message: { Text(archivo.error ?? "") }
    }

    private func tablero(_ caso: Caso) -> some View {
        VStack(spacing: 0) {
            cabecera(caso)
                .padding(.horizontal, 19)
                .padding(.top, 6)
                .padding(.bottom, 9)
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 0) {
                        Button {
                            hoja = .personas(area)
                        } label: {
                            Label(area.titulo, systemImage: area.icono)
                                .font(.title3.bold()).fontDesign(.serif)
                                .padding(.horizontal, 24).padding(.vertical, 14)
                                .glassEffect(.regular.tint(Oro.color(area).opacity(0.24)).interactive(), in: .capsule)
                        }
                        .buttonStyle(.plain)
                        .accessibilityHint("Abre la lista de integrantes")
                        .id("inicio")

                        let visibles = caso.visibles(area)
                        if visibles.isEmpty {
                            conector
                            burbujaVacia(caso)
                        }
                        ForEach(visibles) { acto in
                            conector
                            Button {
                                hoja = .detalle(acto.id)
                            } label: {
                                ResumenActo(acto: acto, caso: caso)
                                    .contentShape(RoundedRectangle(cornerRadius: 23))
                            }
                            .buttonStyle(.plain)
                            .id(acto.id)
                        }
                        Color.clear.frame(height: 24).id("fin")
                    }
                    .padding(.horizontal, 25)
                    .padding(.top, 13)
                    .frame(maxWidth: 650)
                    .frame(maxWidth: .infinity)
                }
                .defaultScrollAnchor(.top)
                .onChange(of: caso.actos.last?.id) { _, nuevo in
                    if let nuevo, caso.visibles(area).contains(where: { $0.id == nuevo }) {
                        withAnimation(.easeOut(duration: 0.26)) { proxy.scrollTo(nuevo, anchor: .bottom) }
                    }
                }
                .onChange(of: area) { _, _ in
                    proxy.scrollTo("inicio", anchor: .top)
                }
            }
        }
        .background {
            LinearGradient(colors: [Oro.color(area).opacity(modo == .dark ? 0.19 : 0.13),
                                    Color(uiColor: .systemBackground), Oro.acento.opacity(0.06)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { controles(caso) }
    }

    private var conector: some View {
        Capsule().fill(Oro.color(area).opacity(0.32)).frame(width: 2, height: 20).accessibilityHidden(true)
    }

    private func cabecera(_ caso: Caso) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Button {
                hoja = .casos
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "folder.fill").foregroundStyle(Oro.acento)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Caso").font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        Text(caso.nombre).font(.headline).lineLimit(2)
                    }
                    Spacer(minLength: 4)
                    Image(systemName: "chevron.down").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                }
                .padding(.horizontal, 14).padding(.vertical, 9)
                .glassEffect(.regular.interactive(), in: .rect(cornerRadius: 18))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            HStack(spacing: 8) {
                Text(caso.etapa.titulo)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                Spacer()
                Text(caso.cerrado ? "Cerrado" : "\((Etapa.allCases.firstIndex(of: caso.etapa) ?? 0) + 1)/5")
                    .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
            HStack(spacing: 4) {
                ForEach(Array(Etapa.allCases.enumerated()), id: \.element) { fila in
                    Capsule().fill(fila.offset <= (Etapa.allCases.firstIndex(of: caso.etapa) ?? 0)
                                   ? Oro.color(area) : Color.secondary.opacity(0.19))
                        .frame(height: 3)
                }
            }
            .accessibilityHidden(true)
        }
    }

    private func burbujaVacia(_ caso: Caso) -> some View {
        Text(caso.cerrado ? "El caso está cerrado." :
                area == .fiscal ? "Toca + y responde las preguntas en el orden que prefieras." :
                    "Aquí se registrarán tus actuaciones. La acusación llegará desde Fiscalía.")
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .padding(18)
            .glassEffect(.regular, in: .rect(cornerRadius: 22))
    }

    private func controles(_ caso: Caso) -> some View {
        VStack(alignment: .trailing, spacing: 9) {
            if !caso.acciones(area).isEmpty {
                Button {
                    hoja = .acciones
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 55, height: 55)
                        .glassEffect(.regular.tint(Oro.color(area).opacity(0.28)).interactive(), in: .circle)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Añadir actuación")
            }
            HStack(spacing: 4) {
                ForEach(Area.allCases) { destino in
                    Button {
                        withAnimation(.easeInOut(duration: 0.22)) { area = destino }
                    } label: {
                        Label(destino.titulo, systemImage: destino.icono)
                            .font(.subheadline.weight(area == destino ? .bold : .medium))
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .background(area == destino ? Oro.color(destino).opacity(0.23) : .clear, in: Capsule())
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(area == destino ? .isSelected : [])
                }
            }
            .padding(4)
            .glassEffect(.regular, in: .capsule)
        }
        .frame(maxWidth: 550)
        .padding(.horizontal, 18)
        .padding(.bottom, 3)
        .frame(maxWidth: .infinity)
    }

    private func abrir(_ accion: Accion) {
        guard let caso = archivo.caso, caso.acciones(area).contains(accion) else { return }
        let acto: Acto
        switch accion {
        case .minijuicio(let conducta):
            let pruebas = caso.acto(conducta)?.referencias ?? []
            acto = Acto(area: .juez, tipo: .minijuicio, titulo: "Minijuicio por conducta", referencias: [conducta] + pruebas, conducta: conducta)
        case .audienciaFinal:
            let referencias = caso.actos.filter { $0.tipo == .minijuicio && $0.cerrada && $0.resultado != .reprogramado }.map(\.id)
            acto = Acto(area: .juez, tipo: .audienciaFinal, titulo: "Audiencia final · Alegatos", referencias: referencias)
        default:
            hoja = .editor(accion)
            return
        }
        var id: UUID?
        if archivo.editar(caso.id, { id = $0.aplicar(accion, acto: acto) }), let id {
            hoja = .detalle(id)
        }
    }
}

enum Oro {
    static let acento = Color(red: 0.67, green: 0.44, blue: 0.17)
    static func color(_ area: Area) -> Color { area == .fiscal ? Color(red: 0.72, green: 0.28, blue: 0.31) : Color(red: 0.25, green: 0.40, blue: 0.67) }
    static func resultado(_ valor: Resultado?) -> Color? {
        switch valor {
        case .si: .green
        case .no: .red
        case .empate, .reprogramado: .orange
        default: nil
        }
    }
}

struct ResumenActo: View {
    let acto: Acto
    let caso: Caso

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: acto.tipo.icono)
                    .foregroundStyle(Oro.resultado(acto.resultado) ?? Oro.color(acto.area))
                    .frame(width: 22)
                Text(acto.rotulo).font(.headline)
                Spacer(minLength: 6)
                if acto.tipo != .evidencia {
                    Text("#\(acto.numero)").font(.caption2.monospacedDigit()).foregroundStyle(.secondary)
                }
            }
            if let id = acto.conducta, let conducta = caso.acto(id) {
                Text(conducta.titulo).font(.footnote.weight(.medium)).foregroundStyle(.secondary)
            }
            if let foto = acto.foto, let imagen = UIImage(data: foto) {
                Image(uiImage: imagen).resizable().scaledToFit()
                    .frame(maxHeight: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .accessibilityLabel("Foto de evidencia")
            }
            if let decision = acto.decision {
                Text(decision).font(.subheadline.bold())
            } else if acto.audiencia && !acto.cerrada {
                Text("Conversación abierta · \(acto.mensajes.count) intervenciones").font(.footnote).foregroundStyle(.secondary)
            }
            if !acto.texto.isEmpty {
                Text(acto.texto).font(.subheadline).lineLimit(4)
            }
            if !acto.votos.isEmpty { ResumenVotos(votos: acto.votos, resultado: acto.resultado, compacto: true) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .glassEffect(.regular.tint((Oro.resultado(acto.resultado) ?? Oro.color(acto.area))
            .opacity(acto.resultado == .si || acto.resultado == .no ? 0.28 : 0.11)).interactive(), in: .rect(cornerRadius: 23))
    }
}

struct Casos: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var cerrar
    var inicial = false
    let seleccionar: () -> Void
    @State private var nombre = ""

    var body: some View {
        NavigationStack {
            Form {
                if !archivo.casos.isEmpty {
                    Section("Mis casos") {
                        ForEach(archivo.casos) { caso in
                            Button {
                                archivo.abrir(caso.id)
                                seleccionar()
                            } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(caso.nombre).font(.headline).foregroundStyle(.primary)
                                    Text(caso.cerrado ? "Cerrado" : caso.etapa.titulo).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
                Section("Nuevo caso") {
                    TextField("Número o nombre del caso", text: $nombre)
                    Button("Crear caso", systemImage: "plus") {
                        archivo.crear(nombre.limpio)
                        if archivo.error == nil { seleccionar() }
                    }
                    .disabled(nombre.limpio.isEmpty)
                }
            }
            .navigationTitle(inicial ? "Justicia" : "Casos")
            .toolbar {
                if !inicial { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } } }
            }
        }
    }
}

struct Personas: View {
    @EnvironmentObject private var archivo: Archivo
    @Environment(\.dismiss) private var cerrar
    let casoID: UUID
    let area: Area
    @State private var nombre = ""

    var body: some View {
        NavigationStack {
            Form {
                if let caso = archivo.caso(casoID) {
                    Section(area == .fiscal ? "Fiscales" : "Integrantes del tribunal") {
                        ForEach(area == .fiscal ? caso.fiscales : caso.jueces) { persona in
                            Label(persona.nombre, systemImage: "person")
                        }
                    }
                    if !caso.cerrado {
                        Section {
                            TextField("Nombre", text: $nombre)
                            Button(area == .fiscal ? "Añadir fiscal" : "Añadir juez", systemImage: "person.badge.plus") {
                                let persona = Persona(nombre: nombre.limpio)
                                if archivo.editar(casoID, { expediente in
                                    if area == .fiscal { expediente.fiscales.append(persona) }
                                    else { expediente.jueces.append(persona) }
                                }) { nombre = "" }
                            }
                            .disabled(nombre.limpio.isEmpty)
                        }
                    }
                }
            }
            .navigationTitle(area == .fiscal ? "Fiscalía" : "Jueces")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { cerrar() } } }
        }
    }
}

struct MenuActuaciones: View {
    let caso: Caso
    let area: Area
    let seleccionar: (Accion) -> Void

    var body: some View {
        NavigationStack {
            List {
                if area == .fiscal && caso.etapa == .preliminar && caso.hechos.count == Pregunta.allCases.count && caso.evidencias.isEmpty {
                    Text("Añade al menos una evidencia para habilitar la evaluación fiscal.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                ForEach(caso.acciones(area)) { accion in
                    Button {
                        seleccionar(accion)
                    } label: {
                        Label(accion.titulo(en: caso), systemImage: accion.icono)
                            .foregroundStyle(.primary)
                    }
                }
            }
            .navigationTitle("Añadir actuación")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

extension String {
    var limpio: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
