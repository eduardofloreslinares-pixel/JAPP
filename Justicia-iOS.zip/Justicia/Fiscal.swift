import SwiftUI

struct Fiscal: View {
    @EnvironmentObject private var archivo: Archivo
    let caso: CasoJusticia
    let navegar: (Pestaña) -> Void
    @State private var formulario: Formulario?
    @State private var seccion = 0
    @State private var borrarConducta: ConductaImputada?

    private var preliminar: Bool { caso.etapa == .preliminar }
    private var tituloEtapa: String {
        if caso.devuelto { return "Subsanación de la acusación" }
        if caso.judicializado { return "Sede judicializada" }
        return caso.etapa.titulo
    }

    var body: some View {
        Contenedor {
            Cabecera(caso: caso, icono: "shield.lefthalf.filled", color: .pink, persona: caso.sujetos.fiscalProvincial)
            Accesos(nombre: "Secciones de Fiscalía", destinos: [
                .init(id: 0, titulo: "Actuación", icono: "point.topleft.down.to.point.bottomright.curvepath"),
                .init(id: 1, titulo: "Pruebas", icono: "tray.full", valor: String(caso.pruebasRecabadas.count)),
                .init(id: 2, titulo: "Conductas", icono: "person.text.rectangle", valor: String(caso.conductas.count)),
                .init(id: 3, titulo: "Peticiones", icono: "paperplane", valor: String(caso.pendientes))
            ], seleccion: $seccion, color: .pink)
            switch seccion {
            case 1: pruebas
            case 2: conductas
            case 3: peticiones
            default: etapa
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if seccion == 0 && !caso.cerrado {
                BarraActuacion {
                    if caso.fiscalEdita && preliminar {
                        Accion(titulo: "Decidir investigación", icono: "arrow.right.circle", principal: true) { evaluar(decidir: true) }
                    } else if caso.fiscalEdita {
                        Accion(titulo: caso.devuelto ? "Subsanar y remitir" : "Formular acusación",
                               icono: "paperplane", principal: true) { acusar() }
                    } else {
                        Accion(titulo: "Presentar petición", icono: "paperplane", principal: true) { pedir() }
                    }
                }
            }
        }
        .sheet(item: $formulario) { Editor(formulario: $0, caso: caso).tint(.pink) }
        .alert("¿Eliminar conducta?", isPresented: Binding(get: { borrarConducta != nil }, set: { if !$0 { borrarConducta = nil } })) {
            Button("Cancelar", role: .cancel) { borrarConducta = nil }
            Button("Eliminar", role: .destructive) {
                if let id = borrarConducta?.id { actualizar { $0.conductas.removeAll { $0.id == id } } }
                borrarConducta = nil
            }
        } message: { Text(borrarConducta?.imputadoNombre ?? "") }
    }

    @ViewBuilder private var etapa: some View {
        Tarjeta(titulo: tituloEtapa, icono: "point.topleft.down.to.point.bottomright.curvepath", color: .pink) {
            Dato("Hecho investigado", caso.queOcurrio)
            Accion(titulo: "Ver expediente", icono: "doc.text") { navegar(.expediente) }
        }
        if caso.devuelto && !caso.cerrado {
            Tarjeta(titulo: "Acusación devuelta", icono: "arrow.uturn.backward.circle.fill", color: .orange) {
                Dato("Observaciones del juzgado", caso.evaluacionAcusacionPJ?.motivoDevolucion ?? "")
                Text("Revisa las conductas y subsana la acusación antes de volver a remitirla.").font(.subheadline)
            }
        }
        if caso.fiscalEdita {
            if preliminar {
                Tarjeta(titulo: "Evaluación preliminar", icono: "checklist", color: .pink) {
                    ForEach(PreguntaInicial.allCases) { pregunta in
                        DisclosureGroup(pregunta.titulo) {
                            let respuesta = pregunta.respuesta(en: caso)
                            Dato("Información del expediente", respuesta.isEmpty ? "Por esclarecer" : respuesta)
                            Dato("Evaluación fiscal", caso.evaluacionesPorPregunta?[pregunta.rawValue] ?? "Pendiente")
                        }
                    }
                    Dato("Valoración conjunta", caso.evaluacionPreliminar)
                    Accion(titulo: "Registrar evaluación", icono: "square.and.pencil") { evaluar() }
                }
            } else {
                afectaciones
                Tarjeta(titulo: "Requerimiento acusatorio", icono: "doc.text.fill", color: .pink) {
                    Text("\(caso.conductas.count) conductas individualizadas").font(.subheadline)
                    Accion(titulo: "Identificar conducta", icono: "plus") { editarConducta() }
                    Accion(titulo: "Decidir no acusar", icono: "archivebox") { noAcusar() }
                    if caso.conductas.isEmpty {
                        Text("Individualiza al menos una conducta para poder remitir la acusación.").font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(caso.conductas) { conducta in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(conducta.imputadoNombre).font(.subheadline.bold())
                            Text(conducta.descripcionConducta).font(.footnote).lineLimit(2)
                            Text("\(conducta.pruebasAsociadasIds.count) pruebas vinculadas").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            diligencias
        } else {
            Tarjeta(titulo: caso.cerrado ? "Expediente cerrado" : "En sede judicial", icono: "lock.fill", color: .orange) {
                if let acusacion = caso.acusacionFiscal {
                    Dato("Pretensión fiscal", acusacion.pretensionPunitiva)
                    Dato("Fundamentos", acusacion.fundamentosAcusacion)
                }
                Accion(titulo: "Ver en Poder Judicial", icono: "building.columns") { navegar(.judicial) }
                if caso.judicializado {
                    Accion(titulo: "Solicitar nueva prueba", icono: "doc.badge.plus") { pedir(prueba: true) }
                }
            }
            if !caso.diligenciasPreliminares.isEmpty || !caso.diligenciasPreparatorias.isEmpty { diligencias }
        }
    }

    private var afectaciones: some View {
        Tarjeta(titulo: "Posibles afectaciones", icono: "exclamationmark.magnifyingglass", color: .pink) {
            ForEach(caso.afectaciones ?? []) { item in
                DisclosureGroup(item.titulo) {
                    Dato("Desarrollo", item.desarrollo)
                    ForEach(caso.pruebasRecabadas.filter { item.pruebas.contains($0.id) }) { prueba in
                        PruebaFila(prueba: prueba)
                    }
                    Accion(titulo: "Editar afectación", icono: "pencil") { editarAfectacion(item) }
                }
            }
            Accion(titulo: "Registrar afectación", icono: "plus") { editarAfectacion() }
            Accion(titulo: "Ver pruebas", icono: "tray.full") { seccion = 1 }
        }
    }

    private func editarAfectacion(_ item: Afectacion? = nil) {
        formulario = Formulario(titulo: item == nil ? "Posible afectación" : "Editar afectación", campos: [
            .texto("titulo", "Afectación", inicial: item?.titulo ?? ""),
            .largo("desarrollo", "Desarrollo", inicial: item?.desarrollo ?? "")
        ], pruebas: caso.pruebasRecabadas, seleccion: Set(item?.pruebas ?? [])) { v in
            actualizar { c in
                var items = c.afectaciones ?? []
                let nueva = Afectacion(id: item?.id ?? nuevoID(), titulo: v["titulo"], desarrollo: v["desarrollo"], pruebas: v.pruebas.sorted())
                if let i = items.firstIndex(where: { $0.id == nueva.id }) { items[i] = nueva }
                else { items.append(nueva) }
                c.afectaciones = items
            }
        }
    }

    private var diligencias: some View {
        Tarjeta(titulo: "Diligencias", icono: "list.clipboard", color: .pink) {
            ForEach(caso.diligenciasPreliminares + caso.diligenciasPreparatorias) { item in
                DisclosureGroup(item.titulo) {
                    Dato("\(rotulo(item.tipo)) · \(item.fecha)", item.detalles)
                    Dato("Resultado", item.resultado)
                    Dato("Responsable", item.responsable)
                }
            }
            if caso.fiscalEdita {
                Accion(titulo: "Registrar diligencia", icono: "plus") { agregarDiligencia() }
            }
        }
    }

    private var pruebas: some View {
        Tarjeta(titulo: "Elementos de prueba · \(caso.pruebasRecabadas.count)", icono: "tray.full", color: .pink) {
            if caso.pruebasRecabadas.isEmpty { Text("Todavía no hay pruebas.").foregroundStyle(.secondary) }
            ForEach(caso.pruebasRecabadas) { PruebaFila(prueba: $0) }
            if caso.fiscalEdita {
                Accion(titulo: "Añadir prueba", icono: "plus") {
                    formulario = Formulario(titulo: "Nueva prueba", campos: camposPrueba) { v in
                        let prueba = crearPrueba(v)
                        actualizar { c in
                            c.incorporar(prueba)
                            c.registrar("Prueba recabada", prueba.titulo, tipo: "diligencia", autor: c.sujetos.fiscalProvincial)
                        }
                    }
                }
            } else if caso.judicializado {
                Accion(titulo: "Solicitar nueva prueba", icono: "plus") { pedir(prueba: true) }
            }
        }
    }

    private var conductas: some View {
        Tarjeta(titulo: "Conductas imputadas · \(caso.conductas.count)", icono: "person.text.rectangle", color: .pink) {
            ForEach(caso.conductas) { conducta in
                DisclosureGroup(conducta.imputadoNombre) {
                    Dato("Conducta", conducta.descripcionConducta)
                    Dato(rotulo(conducta.gravedad), conducta.tipificacionLegal)
                    Dato("Pruebas asociadas", "\(conducta.pruebasAsociadasIds.count)")
                    if caso.fiscalEdita && !preliminar {
                        Button("Editar conducta", systemImage: "square.and.pencil") { editarConducta(conducta) }
                        Button(role: .destructive) { borrarConducta = conducta } label: { Label("Eliminar conducta", systemImage: "trash") }
                    }
                }
            }
            if caso.fiscalEdita && !preliminar {
                Accion(titulo: "Identificar conducta", icono: "plus") { editarConducta() }
            } else if caso.conductas.isEmpty {
                Text("Las conductas se individualizan durante la investigación preparatoria.").foregroundStyle(.secondary)
            }
        }
    }

    private var peticiones: some View {
        Tarjeta(titulo: "Peticiones fiscales", icono: "paperplane", color: .pink) {
            ForEach(caso.peticionesFiscales) { PeticionFila(peticion: $0) }
            if caso.peticionesFiscales.isEmpty { Text("No hay peticiones registradas.").foregroundStyle(.secondary) }
            if caso.judicializado {
                Accion(titulo: "Presentar petición", icono: "plus") { pedir() }
                Accion(titulo: "Solicitar nueva prueba", icono: "doc.badge.plus") { pedir(prueba: true) }
            }
        }
    }

    private func actualizar(_ modificar: (inout CasoJusticia) -> Void) {
        archivo.actualizar(caso.id, modificar)
    }

    private func agregarDiligencia() {
        formulario = Formulario(titulo: "Nueva diligencia", campos: [
            .texto("titulo", "Título"), .opciones("tipo", "Tipo", ["inspeccion", "declaracion", "peritaje", "allanamiento", "informe", "diligencia", "otro"]),
            .texto("fecha", "Fecha", inicial: hoy()), .texto("responsable", "Responsable", inicial: caso.sujetos.fiscalProvincial),
            .largo("detalle", "Detalles"), .largo("resultado", "Resultado", requerido: false)
        ]) { v in
            actualizar { c in
                let item = DiligenciaFiscal(id: nuevoID(), titulo: v["titulo"], tipo: v["tipo"], fecha: v["fecha"],
                                            detalles: v["detalle"], resultado: v["resultado"], responsable: v["responsable"])
                if preliminar { c.diligenciasPreliminares.append(item) } else { c.diligenciasPreparatorias.append(item) }
                c.lineaTemporal.append(.init(id: nuevoID(), fecha: item.fecha, titulo: item.titulo, descripcion: item.detalles, tipo: "diligencia", autor: item.responsable))
            }
        }
    }

    private func evaluar(decidir: Bool = false) {
        var campos: [Campo] = PreguntaInicial.allCases.map { pregunta in
            .largo(pregunta.rawValue, "Evaluar " + pregunta.titulo, inicial: caso.evaluacionesPorPregunta?[pregunta.rawValue] ?? "", requerido: decidir)
        }
        campos.append(.largo("valoracion", "Valoración conjunta de las pruebas", inicial: caso.evaluacionPreliminar))
        if decidir {
            campos += [.opciones("decision", "Decisión", ["abrir_investigacion", "no_abrir"]), .largo("motivo", "Fundamentación")]
        }
        formulario = Formulario(titulo: decidir ? "Decisión preliminar" : "Evaluación preliminar", campos: campos) { v in
            actualizar { c in
                c.evaluacionesPorPregunta = Dictionary(uniqueKeysWithValues: PreguntaInicial.allCases.map { ($0.rawValue, v[$0.rawValue]) })
                c.evaluacionPreliminar = v["valoracion"]
                if decidir {
                    c.fundamentacionPreliminar = v["motivo"]
                    if v["decision"] == "no_abrir" {
                        c.decisionPreliminar = "archivar"
                        c.cerrar(v["motivo"])
                    } else {
                        c.decisionPreliminar = "abrir_preparatoria"
                        c.etapa = .preparatoria
                        c.registrar("Investigación abierta", v["motivo"], autor: c.sujetos.fiscalProvincial)
                    }
                }
            }
        }
    }

    private func editarConducta(_ actual: ConductaImputada? = nil) {
        formulario = Formulario(titulo: actual == nil ? "Identificar conducta" : "Editar conducta", campos: [
            .texto("imputado", "Imputado", inicial: actual?.imputadoNombre ?? (caso.presuntosResponsables.count == 1 ? caso.presuntosResponsables[0] : "")),
            .largo("conducta", "Descripción", inicial: actual?.descripcionConducta ?? ""),
            .texto("tipo", "Tipificación jurídica", inicial: actual?.tipificacionLegal ?? ""),
            .opciones("gravedad", "Gravedad", ["leve", "grave", "muy_grave"], inicial: actual?.gravedad ?? "grave")
        ], pruebas: caso.pruebasRecabadas, seleccion: Set(actual?.pruebasAsociadasIds ?? [])) { v in
            actualizar { c in
                let item = ConductaImputada(id: actual?.id ?? nuevoID(), imputadoNombre: v["imputado"], descripcionConducta: v["conducta"],
                                            tipificacionLegal: v["tipo"], gravedad: v["gravedad"], pruebasAsociadasIds: v.pruebas.sorted())
                if let i = c.conductas.firstIndex(where: { $0.id == item.id }) { c.conductas[i] = item }
                else { c.conductas.append(item) }
                if !c.presuntosResponsables.contains(item.imputadoNombre) { c.presuntosResponsables.append(item.imputadoNombre) }
            }
        }
    }

    private func noAcusar() {
        formulario = Formulario(titulo: "Decidir no acusar", accion: "Registrar", campos: [
            .largo("motivo", "Fundamentación de la decisión fiscal")
        ]) { v in
            actualizar { c in
                c.decisionAcusar = "no_acusar"
                c.registrar("Fiscalía decide no acusar", v["motivo"], autor: c.sujetos.fiscalProvincial)
                c.cerrar(v["motivo"])
            }
        }
    }

    private func acusar() {
        guard !caso.conductas.isEmpty else {
            seccion = 2
            archivo.error = "Identifica al menos una conducta antes de remitir la acusación."
            return
        }
        let anterior = caso.acusacionFiscal
        formulario = Formulario(titulo: "Acusación fiscal", accion: "Remitir", campos: [
            .largo("pena", "Pretensión punitiva", inicial: anterior?.pretensionPunitiva ?? ""),
            .decimal("civil", "Reparación civil (S/)", inicial: String(anterior?.reparacionCivilSolicitada ?? 0)),
            .largo("motivo", "Fundamentos de la acusación", inicial: anterior?.fundamentosAcusacion ?? "")
        ]) { v in
            actualizar { c in
                c.acusacionFiscal = .init(fecha: hoy(), pretensionPunitiva: v["pena"], reparacionCivilSolicitada: v.numero("civil") ?? 0,
                                         fundamentosAcusacion: v["motivo"], fiscalEmisor: c.sujetos.fiscalProvincial)
                c.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "pendiente", juezEvaluador: c.sujetos.juezInvestigacionPreparatoria)
                c.decisionAcusar = "acusar"
                c.etapa = .control
                c.registrar("Acusación remitida al Poder Judicial", v["motivo"], autor: c.sujetos.fiscalProvincial)
            }
            navegar(.judicial)
        }
    }

    private func pedir(prueba: Bool = false) {
        let campos: [Campo] = [
            .texto("titulo", "Título de la petición"), .largo("motivo", "Fundamentación")
        ]
        let opcion: [Campo] = [.opciones("tipo", "Tipo", ["prision_preventiva", "apercibimiento", "reprogramacion", "medida_cautelar", "otra"])]
        formulario = Formulario(titulo: prueba ? "Solicitar incorporación" : "Petición fiscal", accion: "Enviar",
                                campos: (prueba ? [] : opcion) + campos + (prueba ? camposPrueba : [])) { v in
            actualizar { c in
                c.peticionesFiscales.append(.init(id: nuevoID(), fecha: hoy(), tipo: prueba ? "incorporar_prueba" : v["tipo"],
                                                titulo: v["titulo"], fundamentacion: v["motivo"], estado: "pendiente", nuevaPrueba: prueba ? crearPrueba(v) : nil))
                c.registrar("Petición fiscal · " + v["titulo"], v["motivo"], tipo: "diligencia", autor: c.sujetos.fiscalProvincial)
            }
        }
    }
}

var camposPrueba: [Campo] {
    [.texto("prTitulo", "Título de la prueba"), .opciones("prTipo", "Tipo de prueba", ["documental", "testimonial", "pericial", "material", "digital"]),
     .texto("prFecha", "Fecha de obtención", inicial: hoy()), .texto("prOrigen", "Origen", requerido: false),
     .largo("prDescripcion", "Descripción"), .largo("prPertinencia", "Pertinencia", requerido: false)]
}

func crearPrueba(_ v: Valores) -> PruebaElemento {
    .init(id: nuevoID(), tipo: v["prTipo"], titulo: v["prTitulo"], descripcion: v["prDescripcion"],
          fechaRecabada: v["prFecha"], origen: v["prOrigen"], pertinencia: v["prPertinencia"])
}

struct PruebaFila: View {
    let prueba: PruebaElemento
    var body: some View {
        DisclosureGroup(prueba.titulo) {
            Dato(rotulo(prueba.tipo) + " · " + prueba.fechaRecabada, prueba.descripcion)
            Dato("Origen", prueba.origen)
            Dato("Pertinencia", prueba.pertinencia)
            if let admitida = prueba.admitidaPJ {
                Dato("Valoración judicial", admitida ? "Admitida" : "Excluida")
            }
        }
    }
}

struct PeticionFila: View {
    let peticion: PeticionFiscal
    var body: some View {
        DisclosureGroup(peticion.titulo) {
            Dato(rotulo(peticion.tipo) + " · " + rotulo(peticion.estado), peticion.fundamentacion)
            Dato("Respuesta judicial", peticion.respuestaJuez ?? "")
            if let prueba = peticion.nuevaPrueba { PruebaFila(prueba: prueba) }
        }
    }
}
