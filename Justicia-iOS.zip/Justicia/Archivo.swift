import Foundation
import Combine

@MainActor
final class Archivo: ObservableObject {
    @Published private(set) var casos: [Caso] = []
    @Published private(set) var activo: UUID?
    @Published var error: String?

    private struct Datos: Codable {
        var casos: [Caso]
        var activo: UUID?
    }

    private let carpeta = URL.applicationSupportDirectory.appending(path: "Justicia")
    private var destino: URL { carpeta.appending(path: "actuaciones-v5.json") }
    private var bloqueado = false

    var caso: Caso? { casos.first { $0.id == activo } }
    func caso(_ id: UUID) -> Caso? { casos.first { $0.id == id } }

    init() {
        guard FileManager.default.fileExists(atPath: destino.path) else { return }
        do {
            let datos = try JSONDecoder().decode(Datos.self, from: Data(contentsOf: destino))
            var normalizados = datos.casos
            try normalizar(&normalizados)
            casos = normalizados
            activo = datos.activo
            if normalizados != datos.casos { transaccion { _ in } }
        } catch {
            bloqueado = true
            self.error = "No se pudo leer el expediente guardado. El archivo sigue en el dispositivo."
        }
    }

    func crear(_ nombre: String) {
        guard !bloqueado else { return }
        guard let numero = Numeracion.disponible(excluyendo: Set(casos.compactMap(\.numero))) else {
            error = "Se agotaron los números disponibles para casos."
            return
        }
        let nuevo = Caso(nombre: nombre, numero: numero)
        transaccion { datos in
            datos.casos.insert(nuevo, at: 0)
            datos.activo = nuevo.id
        }
    }

    private func normalizar(_ casos: inout [Caso]) throws {
        var usados: Set<Int> = []
        var pendientes: [Int] = []
        for indice in casos.indices {
            try casos[indice].normalizarNumerosDeActos()
            if let numero = casos[indice].numero, Numeracion.rango.contains(numero), usados.insert(numero).inserted {
                continue
            }
            pendientes.append(indice)
        }
        for indice in pendientes {
            guard let numero = Numeracion.disponible(excluyendo: usados) else { throw Numeracion.Agotada() }
            casos[indice].numero = numero
            usados.insert(numero)
        }
    }

    func abrir(_ id: UUID) {
        guard caso(id) != nil else { return }
        transaccion { $0.activo = id }
    }

    @discardableResult
    func editar(_ id: UUID, _ cambio: (inout Caso) -> Void) -> Bool {
        transaccion { datos in
            if let indice = datos.casos.firstIndex(where: { $0.id == id }) {
                cambio(&datos.casos[indice])
            }
        }
    }

    @discardableResult
    private func transaccion(_ cambio: (inout Datos) -> Void) -> Bool {
        guard !bloqueado else { return false }
        var datos = Datos(casos: casos, activo: activo)
        cambio(&datos)
        do {
            try FileManager.default.createDirectory(at: carpeta, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(datos)
            try data.write(to: destino, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            casos = datos.casos
            activo = datos.activo
            return true
        } catch {
            self.error = "No se guardó el cambio. Revisa el espacio disponible e inténtalo de nuevo."
            return false
        }
    }
}
