import Foundation
import Combine

@MainActor
final class Archivo: ObservableObject {
    @Published private(set) var expedientes: [CasoJusticia] = []
    @Published private(set) var activo: String?
    @Published var error: String?

    private struct Datos: Codable {
        var expedientes: [CasoJusticia]
        var activo: String?
    }

    private let directorio = URL.applicationSupportDirectory.appending(path: "Justicia")
    private var destino: URL { directorio.appending(path: "archivo-nativo.json") }
    private let decoder = JSONDecoder()
    private var lecturaBloqueada = false

    var caso: CasoJusticia? { expedientes.first { $0.id == activo } }

    init() {
        if FileManager.default.fileExists(atPath: destino.path) {
            do {
                let datos = try decoder.decode(Datos.self, from: Data(contentsOf: destino))
                expedientes = datos.expedientes
                activo = datos.activo
            } catch {
                lecturaBloqueada = true
                self.error = "No se pudo leer el archivo de expedientes. Se conservó el archivo original."
            }
            return
        }
        let anterior = directorio.appending(path: "expedientes.json")
        if FileManager.default.fileExists(atPath: anterior.path) {
            do {
                let copia = try decoder.decode([String: String].self, from: Data(contentsOf: anterior))
                if let lista = copia["justicia_expedientes_v2"] {
                    expedientes = try decoder.decode([CasoJusticia].self, from: Data(lista.utf8))
                }
                if let actual = copia["justicia_expediente_v1"] {
                    let expediente = try decoder.decode(CasoJusticia.self, from: Data(actual.utf8))
                    expedientes.removeAll { $0.id == expediente.id }
                    expedientes.insert(expediente, at: 0)
                    activo = expediente.id
                } else {
                    activo = expedientes.first?.id
                }
                guardar()
            } catch {
                lecturaBloqueada = true
                self.error = "No se pudo migrar el archivo anterior. Se conservó la copia original."
            }
        } else if let demo = plantilla("Demo") {
            expedientes = [demo]
            activo = demo.id
            guardar()
        }
    }

    func abrir(_ id: String) {
        guard expedientes.contains(where: { $0.id == id }) else { return }
        activo = id
        guardar()
    }

    func crear(_ numero: String, demo: Bool = false) {
        guard var nuevo = plantilla(demo ? "Demo" : "Blank") else { return }
        nuevo.id = nuevoID()
        nuevo.numeroExpediente = numero
        expedientes.insert(nuevo, at: 0)
        abrir(nuevo.id)
    }

    func duplicar(_ expediente: CasoJusticia, como numero: String) {
        var copia = expediente
        copia.id = nuevoID()
        copia.numeroExpediente = numero
        expedientes.insert(copia, at: 0)
        abrir(copia.id)
    }

    func eliminar(_ id: String) {
        expedientes.removeAll { $0.id == id }
        if activo == id { activo = expedientes.first?.id }
        guardar()
    }

    func actualizar(_ id: String, _ modificar: (inout CasoJusticia) -> Void) {
        guard let indice = expedientes.firstIndex(where: { $0.id == id }), !expedientes[indice].cerrado else { return }
        modificar(&expedientes[indice])
        guardar()
    }

    private func plantilla(_ nombre: String) -> CasoJusticia? {
        guard let url = Bundle.main.url(forResource: nombre, withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let caso = try? decoder.decode(CasoJusticia.self, from: data) else {
            error = "No se pudo abrir la plantilla del expediente."
            return nil
        }
        return caso
    }

    private func guardar() {
        guard !lecturaBloqueada else {
            error = "El archivo original está protegido porque no pudo leerse."
            return
        }
        do {
            try FileManager.default.createDirectory(at: directorio, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(Datos(expedientes: expedientes, activo: activo))
            try data.write(to: destino, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        } catch {
            self.error = "No se pudieron guardar los expedientes en el dispositivo."
        }
    }
}
