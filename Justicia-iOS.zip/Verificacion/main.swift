import Foundation

let decoder = JSONDecoder()
func fixture(_ name: String) throws -> CasoJusticia {
    try decoder.decode(CasoJusticia.self, from: Data(contentsOf: URL(fileURLWithPath: "Justicia/\(name).json")))
}

let blank = try fixture("Blank")
precondition(blank.etapa == .preliminar && blank.fiscalEdita)
var caso = try fixture("Demo")
precondition(caso.etapa == .preparatoria && caso.fiscalEdita)
let pruebas = caso.pruebasRecabadas
caso.etapa = .control
caso.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "devolver", motivoDevolucion: "Completar", juezEvaluador: "Juzgado")
precondition(caso.fiscalEdita)
caso.admitirAcusacion("Procede")
precondition(caso.etapa == .intermedia && !caso.fiscalEdita && caso.subcasos.count == caso.conductas.count)
precondition(caso.pruebasRecabadas == pruebas)
let primeraSala = caso.sujetos.juecesApelacionInstancia1
for numero in 1...3 {
    caso.etapa = .sentencia
    caso.presentarRecurso(parte: "defensa", motivo: "Motivación")
    precondition(caso.numeroApelaciones == numero)
    if numero == 1 { precondition(caso.salaActual == primeraSala) }
    if numero < 3 {
        precondition(caso.etapa == .intermedia)
        precondition(caso.subcasos.allSatisfy { $0.estado == "pendiente" })
        caso.apelaciones[numero - 1].estado = "resuelta"
    }
}
precondition(caso.etapa == .sentencia && caso.apelaciones.last?.admisibilidadUltima == "pendiente")
var admitido = caso
admitido.revisarUltimoRecurso(admitir: true, motivo: "Admitido")
precondition(admitido.etapa == .intermedia && !admitido.cerrado)
caso.revisarUltimoRecurso(admitir: false, motivo: "Inadmisible")
precondition(caso.cerrado && caso.apelaciones.last?.estado == "resuelta")
let roundTrip = try decoder.decode(CasoJusticia.self, from: JSONEncoder().encode(caso))
precondition(roundTrip == caso)
print("Flujo de expedientes verificado.")
