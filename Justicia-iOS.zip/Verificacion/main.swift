import Foundation

var caso = Caso(nombre: "Caso de prueba")
func agregar(_ accion: Accion, _ acto: Acto, a caso: inout Caso) -> UUID {
    guard let id = caso.aplicar(accion, acto: acto) else { fatalError("Acción no habilitada") }
    return id
}

precondition(!caso.acciones(.fiscal).contains(.evaluacionFiscal))
for pregunta in Pregunta.allCases.reversed() {
    precondition(caso.acciones(.fiscal).contains(.hecho(pregunta)))
    _ = agregar(.hecho(pregunta), Acto(area: .fiscal, tipo: .hecho, titulo: pregunta.titulo, texto: "Respuesta", pregunta: pregunta), a: &caso)
    precondition(!caso.acciones(.fiscal).contains(.hecho(pregunta)))
}
precondition(!caso.acciones(.fiscal).contains(.evaluacionFiscal))
_ = agregar(.evidencia, Acto(area: .fiscal, tipo: .evidencia, titulo: "Evidencia", texto: "Descripción", foto: Data([1, 2, 3])), a: &caso)
_ = agregar(.evaluacionFiscal, Acto(area: .fiscal, tipo: .evaluacionFiscal, titulo: "Evaluación"), a: &caso)
_ = agregar(.apertura, Acto(area: .fiscal, tipo: .apertura, titulo: "Apertura", resultado: .si), a: &caso)
precondition(caso.etapa == .acusacion)
let acusacion = Acto(area: .fiscal, tipo: .acusacion, titulo: "Acusación", resultado: .si)
precondition(caso.aplicar(.acusacion, acto: acusacion) == nil)
let conducta = agregar(.conducta, Acto(area: .fiscal, tipo: .conducta, titulo: "Conducta"), a: &caso)
_ = agregar(.acusacion, acusacion, a: &caso)
_ = agregar(.control, Acto(area: .juez, tipo: .control, titulo: "Control", resultado: .no), a: &caso)
precondition(caso.etapa == .acusacion)
var nuevaAcusacion = acusacion
nuevaAcusacion.id = UUID()
_ = agregar(.acusacion, nuevaAcusacion, a: &caso)
_ = agregar(.control, Acto(area: .juez, tipo: .control, titulo: "Control", resultado: .si), a: &caso)
precondition(caso.etapa == .juicio && !caso.acciones(.juez).contains(.audienciaFinal))
let mini = Acto(area: .juez, tipo: .minijuicio, titulo: "Minijuicio", conducta: conducta)
let primero = agregar(.minijuicio(conducta), mini, a: &caso)
precondition(!caso.acciones(.juez).contains(.minijuicio(conducta)))
let reprogramado = caso.terminarAudiencia(primero, votos: [], resultado: .reprogramado, texto: "Nueva fecha", decision: "Reprogramado", autor: "Juez")
precondition(reprogramado && caso.acciones(.juez).contains(.minijuicio(conducta)))
var segundoMini = mini
segundoMini.id = UUID()
let segundo = agregar(.minijuicio(conducta), segundoMini, a: &caso)
let pregunta = Intervencion(rol: .juez, autor: "Juez", tipo: .preguntaObjetiva, texto: "¿Consta el hecho?")
caso.intervencion(pregunta, en: segundo)
let respuesta = Intervencion(rol: .fiscal, autor: "Fiscal", autorID: "fiscal", tipo: .respuestaObjetiva, texto: "Sí", respuestaA: pregunta.id, resultado: .si)
caso.intervencion(respuesta, en: segundo)
caso.intervencion(respuesta, en: segundo)
precondition(caso.acto(segundo)?.mensajes.count == 2)
caso.jueces += [Persona(nombre: "Juez 2"), Persona(nombre: "Juez 3")]
let votos = caso.jueces.enumerated().map { i, juez in Voto(id: juez.id, juez: juez.nombre, aFavor: i != 2, fundamento: "Motivos") }
precondition(mayoria(votos) == .si && mayoria(Array(votos.suffix(2))) == .empate)
let emitido = caso.terminarAudiencia(segundo, votos: votos, resultado: .si, texto: "Acreditada", decision: "Acreditada", autor: "Juez")
precondition(emitido && caso.resuelta(conducta))
caso.intervencion(pregunta, en: segundo)
precondition(caso.acto(segundo)?.mensajes.count == 3)
let final = agregar(.audienciaFinal, Acto(area: .juez, tipo: .audienciaFinal, titulo: "Alegatos"), a: &caso)
precondition(!caso.acciones(.juez).contains(.sentencia))
let terminada = caso.terminarAudiencia(final, votos: [], resultado: .realizado, texto: "Alegatos completos", decision: "Cerrada", autor: "Juez")
precondition(terminada && caso.acciones(.juez).contains(.sentencia))
_ = agregar(.sentencia, Acto(area: .juez, tipo: .sentencia, titulo: "Sentencia", resultado: .si), a: &caso)
_ = agregar(.recurso, Acto(area: .fiscal, tipo: .recurso, titulo: "Apelación"), a: &caso)
_ = agregar(.revision, Acto(area: .juez, tipo: .revision, titulo: "Fallo", resultado: .no), a: &caso)
precondition(caso.acciones(.fiscal).contains(.constitucional))
precondition(Set(caso.actos.map(\.codigo)).count == caso.actos.count)
precondition(caso.actos.allSatisfy { Numeracion.rango.contains($0.numero) && $0.codigo.count == 7 })
precondition(Numeracion.codigo(8, area: .fiscal) == "0008-MP")
precondition(Numeracion.codigo(8, area: .juez) == "0008-PJ")
precondition(Numeracion.disponible(excluyendo: Set(Numeracion.rango)) == nil)

var anterior = Caso(nombre: "5.0")
anterior.actos = [
    Acto(numero: 234123, fecha: Date(timeIntervalSince1970: 100), area: .fiscal, tipo: .comunicado, titulo: "Anterior"),
    Acto(numero: 784123, fecha: Date(timeIntervalSince1970: 200), area: .fiscal, tipo: .comunicado, titulo: "Nuevo"),
    Acto(numero: 4123, fecha: Date(timeIntervalSince1970: 150), area: .fiscal, tipo: .comunicado, titulo: "Válido")
]
let ids = anterior.actos.map(\.id)
try anterior.normalizarNumerosDeActos()
precondition(anterior.actos.map(\.id) == ids)
precondition(anterior.actos[2].codigo == "4123-MP")
precondition(Set(anterior.actos.map(\.codigo)).count == 3)
precondition(anterior.visibles(.fiscal).map(\.titulo) == ["Nuevo", "Válido", "Anterior"])
let normalizado = anterior
try anterior.normalizarNumerosDeActos()
precondition(anterior == normalizado)
let conNumero = Caso(nombre: "Caso numerado", numero: 36)
precondition(conNumero.codigo == "0036-MP")
let recuperado = try JSONDecoder().decode(Caso.self, from: JSONEncoder().encode(caso))
precondition(recuperado == caso)
print("Flujo, numeración, conversaciones, mayoría y persistencia verificados.")
