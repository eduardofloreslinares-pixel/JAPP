import Foundation

let decoder = JSONDecoder()
func fixture(_ name: String) throws -> CasoJusticia {
    try decoder.decode(CasoJusticia.self, from: Data(contentsOf: URL(fileURLWithPath: "Justicia/\(name).json")))
}

var preliminar = try fixture("Blank")
precondition(preliminar.etapaFlujograma == 0 && preliminar.fiscalEdita)
preliminar.decisionPreliminar = "archivar"
preliminar.cerrar("No se abre investigación")
precondition(preliminar.cerrado && preliminar.etapaFlujograma == 0)
var caso = try fixture("Demo")
precondition(caso.etapaFlujograma == 1 && caso.fiscalEdita)
let pruebas = caso.pruebasRecabadas
caso.acusacionFiscal = .init(fecha: hoy(), pretensionPunitiva: "Pretensión", reparacionCivilSolicitada: 0,
                              fundamentosAcusacion: "Fundamentos", fiscalEmisor: "Fiscalía")
caso.etapa = .control
caso.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "devolver", motivoDevolucion: "Subsanar", juezEvaluador: "Juzgado")
precondition(caso.fiscalEdita && caso.etapaFlujograma == 2)
caso.admitirAcusacion("No procede mientras esté devuelta")
precondition(caso.etapa == .control && caso.subcasos.isEmpty)
caso.evaluacionAcusacionPJ = .init(fecha: hoy(), decision: "pendiente", juezEvaluador: "Juzgado")
caso.admitirAcusacion("Procede")
precondition(caso.etapa == .juicio && caso.etapaFlujograma == 3 && !caso.fiscalEdita)
precondition(!caso.subcasos.isEmpty && caso.subcasos.count == caso.conductas.count)
precondition(caso.pruebasRecabadas == pruebas && !caso.puedeSentenciar)
for i in caso.subcasos.indices {
    precondition(!caso.subcasos[i].listoParaResolver)
    caso.subcasos[i].preguntasJudiciales = [.init(pregunta: "Pregunta", fiscalia: "Respuesta fiscal", contraparte: "Respuesta de parte")]
    precondition(!caso.subcasos[i].listoParaResolver)
    caso.subcasos[i].preguntasJudiciales?[0].evaluacion = "Evaluación"
    caso.subcasos[i].diligenciasEspeciales = [.init(orden: "Actuación pendiente")]
    precondition(!caso.subcasos[i].listoParaResolver)
    caso.subcasos[i].diligenciasEspeciales?[0].resultado = "Actuación completada"
    precondition(caso.subcasos[i].listoParaResolver)
    caso.subcasos[i].estado = "acreditada"
}
precondition(caso.conductasResueltas && !caso.puedeSentenciar)
caso.alegatosClausura = .init(tipo: "clausura", fiscalia: "Fiscalía", defensa: "Contraparte", fecha: hoy())
caso.evaluacionAlegatosJuez = "Valoración conjunta"
precondition(caso.puedeSentenciar)
caso.sentencia = .init(fecha: hoy(), fallo: "condenatoria", penasImputados: [], reparacionCivilMonto: 0,
                       reparacionCivilBeneficiario: "", fundamentacionJuridica: "Sentencia", juezSentenciador: "Juzgado")
caso.etapa = .sentencia
let conductas = caso.subcasos
caso.presentarRecurso(parte: "defensa", motivo: "Agravios")
caso.presentarRecurso(parte: "fiscalia", motivo: "Agravios")
precondition(caso.numeroApelaciones == 1 && !caso.puedeRecurrirTC)
caso.resolverRecurso(evaluacion: "Revisión", fallo: "confirma", fundamento: "Motivación")
precondition(caso.puedeRecurrirTC && caso.etapaFlujograma == 4 && caso.subcasos == conductas)
caso.presentarRecurso(parte: "fiscalia", motivo: "Impugnación de fallo")
caso.resolverRecurso(evaluacion: "Revisión", fallo: "modifica", fundamento: "Motivación del segundo fallo")
caso.presentarRecursoTC(parte: "defensa", motivo: "Motivo constitucional")
caso.resolverRecursoTC(fallo: "infundado", fundamento: "Motivación constitucional")
precondition(caso.recursoConstitucional?.estado == "resuelta")
let roundTrip = try decoder.decode(CasoJusticia.self, from: JSONEncoder().encode(caso))
precondition(roundTrip == caso)
print("Flujograma verificado.")
