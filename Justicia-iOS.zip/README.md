# Justicia 5.0

Simulador nativo en SwiftUI para iOS 26 o posterior. Crea un caso y toca **+** en Fiscalía. Las preguntas iniciales se pueden contestar en cualquier orden. Con todas las respuestas y al menos una evidencia aparece la evaluación fiscal. Toca la burbuja superior **Fiscalía** o **Juez** para añadir integrantes.

En juicio, elige un rol en el chat. El juez puede hacer preguntas abiertas u objetivas, reprogramar o resolver. Cambia al fiscal o a la contraparte para responder. Las decisiones colegiadas registran fundamento por integrante y muestran mayoría y minoría. Un empate no hace avanzar la etapa. Al terminar la conversación puedes abrir el acta desde su burbuja. El recurso constitucional forma parte de la simulación.

Justicia 5.0 comienza con un archivo nuevo. Conserva en el dispositivo el archivo de datos de la versión anterior, pero sus casos no aparecen en el esquema nuevo.

## GitHub Actions

1. Reemplaza `Justicia-iOS.zip` en el repositorio.
2. Reemplaza el contenido de `.github/workflows/build-ipa.yml` con `workflow-para-github.txt` del ZIP. El workflow anterior espera archivos de ejemplo que ya no se usan.
3. Ejecuta **Compilar IPA de Justicia** y descarga el artefacto. Contiene `Justicia.ipa` sin firmar.
