# Justicia para iPhone

Justicia 2.9 para iOS 26 o posterior. Incluye un proyecto de Xcode con el icono de balanza, navegación y controles Liquid Glass de SwiftUI, y el flujo de expedientes de Justicia ejecutado localmente en WebKit. El modo claro u oscuro sigue al sistema.

Toca **Justicia** para abrir la bandeja, crear o cambiar de expediente. La barra inferior da acceso a **Fiscalía**, **Poder Judicial** y **Expediente**. En Expediente encontrarás los hechos, la cronología y los sujetos procesales. El botón superior de compartir permite guardar el expediente actual en Archivos como JSON. Los datos se guardan en el iPhone, separados de la instalación Android.

## Compilar en GitHub subiendo el ZIP

1. Sube `Justicia-iOS.zip` a la raíz de tu repositorio, con ese mismo nombre.
2. Abre `workflow-para-github.txt` dentro del ZIP y copia su contenido a un archivo nuevo llamado `.github/workflows/build-ipa.yml` en GitHub. GitHub lee los workflows del repositorio directamente.
3. En **Actions**, abre **Compilar IPA de Justicia** y pulsa **Run workflow**.
4. Al terminar, descarga el artefacto **Justicia-iOS**. Dentro tendrás `Justicia.ipa`, que debes firmar antes de instalarla.

También puedes descomprimir el ZIP y subir todos sus archivos directamente a la raíz, incluyendo la carpeta oculta `.github`. El mismo workflow detecta el proyecto descomprimido.

## Abrir en Xcode

Abre `Justicia.xcodeproj` con Xcode 26 o posterior. Para instalar desde Xcode, selecciona tu equipo en **Signing & Capabilities** y usa un identificador de aplicación disponible para tu cuenta. El identificador del proyecto es `org.justicia.penal.ios`.

Los recursos web ya compilados están en `Justicia/Web`. El código React de referencia está en `FuenteWeb/src`. Para regenerar el JavaScript después de editar React, ejecuta `npm install && npm run build` dentro de `FuenteWeb`. Xcode usa los recursos empaquetados directamente.
