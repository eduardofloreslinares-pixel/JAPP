# Justicia 4.0 para iPhone

Interfaz completa en SwiftUI con navegación Liquid Glass en iOS 26 o posterior. Incluye Fiscalía, Poder Judicial, Hechos, Cronología, Sujetos, la bandeja de expedientes y la exportación JSON a Archivos. El modo claro y oscuro sigue al sistema.

La lupa abre una consulta buscable del expediente desde las tres áreas. Poder Judicial permite contrastar alegatos por audiencia, consultar fichas de prueba y guardar borradores de resolución con sus referencias.

La aplicación guarda los casos localmente e intenta migrar el respaldo de la versión 2.9.1 en la primera apertura si existe. El identificador de la app sigue siendo `org.justicia.penal.ios`. Para conservar el contenedor al instalar, usa la misma configuración de firmado y conserva instalada la versión anterior.

## Actualizar el proyecto en GitHub

1. Reemplaza el ZIP en la raíz del repositorio por este `Justicia-iOS.zip`.
2. Si todavía usas el workflow de la versión 2.9, abre `workflow-para-github.txt` dentro del ZIP y pega su contenido en el archivo existente `.github/workflows/build-ipa.yml` de GitHub. El workflow de Justicia 3.0 ya sirve para este ZIP.
3. Ve a **Actions**, abre **Compilar IPA de Justicia** y elige la ejecución más reciente. Si no se inició automáticamente, pulsa **Run workflow**.
4. Descarga el artefacto **Justicia-iOS** y utiliza la nueva `Justicia.ipa` para firmar e instalar.

El ZIP contiene también el workflow en `.github/workflows/build-ipa.yml` para quien suba el proyecto descomprimido.

## Recorrido de Justicia 4.0

Investigación preliminar → Acusación → Etapa preparatoria → Juicio oral → Sentencia.

Cada conducta tiene un minijuicio con preguntas del juez, respuestas consecutivas de Fiscalía y contraparte, evaluación, diligencias y pruebas. La audiencia final queda habilitada cuando se resuelven todas las conductas. Los recursos revisan lo actuado y conservan las decisiones previas. El Tribunal Constitucional aparece como vía separada dentro de la simulación tras un fallo de apelación.
