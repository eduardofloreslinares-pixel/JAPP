# Justicia 3.0 para iPhone

Interfaz completa en SwiftUI con navegación Liquid Glass en iOS 26 o posterior. Incluye Fiscalía, Poder Judicial, Hechos, Cronología, Sujetos, la bandeja de expedientes y la exportación JSON a Archivos. El modo claro y oscuro sigue al sistema.

La aplicación guarda los casos localmente e intenta migrar el respaldo de la versión 2.9.1 en la primera apertura si existe. El identificador de la app sigue siendo `org.justicia.penal.ios`. Para conservar el contenedor al instalar, usa la misma configuración de firmado y conserva instalada la versión anterior.

## Actualizar el proyecto en GitHub

1. Reemplaza el ZIP en la raíz del repositorio por este `Justicia-iOS.zip`.
2. Abre `workflow-para-github.txt` dentro del ZIP y pega su contenido en el archivo existente `.github/workflows/build-ipa.yml` de GitHub. El workflow anterior espera recursos del prototipo web.
3. Ve a **Actions**, abre **Compilar IPA de Justicia** y elige la ejecución más reciente. Si no se inició automáticamente, pulsa **Run workflow**.
4. Descarga el artefacto **Justicia-iOS** y utiliza la nueva `Justicia.ipa` para firmar e instalar.

El ZIP contiene también el workflow en `.github/workflows/build-ipa.yml` para quien suba el proyecto descomprimido.
